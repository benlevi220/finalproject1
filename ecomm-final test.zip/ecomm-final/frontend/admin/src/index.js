import { createRoot } from 'react-dom/client';
import { Provider as ReduxProvider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';

import { store } from 'store';
import App from './App';

import 'assets/third-party/apex-chart.css';
import 'react-toastify/dist/ReactToastify.css';
import 'simplebar/src/simplebar.css';

const container = document.getElementById('root');
const root = createRoot(container);
root.render(
    <ReduxProvider store={store}>
        <BrowserRouter basename="/">
            <App />
            <ToastContainer
                position="top-right"
                autoClose={2000}
                hideProgressBar
                newestOnTop
                closeOnClick
                rtl={false}
                pauseOnFocusLoss={false}
                draggable
                pauseOnHover={false}
                theme="light"
            />
        </BrowserRouter>
    </ReduxProvider>
);
