import { Icon } from '@iconify/react';
import { useFormik } from 'formik';
import React from 'react';
import { useDispatch } from 'react-redux';
import { ReactSVG } from 'react-svg';
import { toast } from 'react-toastify';
import * as yup from 'yup';

import { Box, CircularProgress, IconButton, Stack, TextField, Typography, useTheme } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import { remoteUrl } from 'api';
import { IconRoot } from 'components/IconRoot';
import { addCategory, updateCategory } from 'store/reducers/category/extraReducers';

import closeCircleOutline from '@iconify/icons-mdi/close-circle-outline';
import uploadIcon from '@iconify/icons-mdi/upload';

export default function CategoryForm({ open, handleClose, update, category, slug }) {
    const initialValues = {
        name: '',
        description: '',
        image: ''
    };
    const [file, setFile] = React.useState(null);
    const theme = useTheme();
    const dispatch = useDispatch();
    const loading = false;
    React.useEffect(() => {
        if (!update || !category) return;

        formik.setValues({
            name: category.name,
            description: category.description,
            image: category.image.includes('/uploads') ? `${remoteUrl}${category.image}` : category.image,
            imageName: category.image.split('/').pop()
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [category, update]);

    const validationSchema = yup.object({
        name: yup.string().required('Enter category name').min(3, 'Name should be atleast 3 characters long'),
        image: yup.string().required('Upload Category Image')
    });

    const formik = useFormik({
        initialValues,
        validationSchema,
        validateOnBlur: false,
        validateOnChange: true,
        onSubmit: (values) => {
            handleClose('edit');
            if (formik.values.image) {
                const formData = new FormData();
                formData.append('name', values.name);
                formData.append('description', values.description);
                file && formData.append('image', file);
                if (update) {
                    formData.append('id', category.id);
                    dispatch(updateCategory({ id: category.id, formData })).then((res) => {
                        if (res.meta.requestStatus === 'fulfilled') {
                            formik.resetForm();
                            toast.success('Category updated successfully');
                            handleClose();
                        }
                    });
                } else
                    dispatch(addCategory(formData)).then((res) => {
                        if (res.meta.requestStatus === 'fulfilled') {
                            formik.resetForm();
                            toast.success('Category created successfully');
                            handleClose();
                        }
                    });
            } else toast.error('Please select image of category');
        }
    });

    const handleImageUpload = async (e) => {
        const selectedFile = await e.target.files[0];
        if (selectedFile) {
            setFile(selectedFile);
            formik.setFieldValue('image', URL.createObjectURL(selectedFile));
            formik.setFieldValue('imageName', selectedFile.name);
        }
    };

    return (
        <Dialog open={open} onClose={() => handleClose('edit')} fullWidth={false}>
            <DialogTitle align="center" sx={{ fontWeight: 700 }}>
                {slug} Category
            </DialogTitle>
            <DialogContent sx={{ marginTop: '1.25rem' }}>
                <Stack spacing={0.5} mb={2}>
                    <Typography variant="subtitle1">Category Name</Typography>
                    <TextField
                        name="name"
                        value={formik.values.name}
                        onChange={formik.handleChange}
                        error={formik.touched.name && Boolean(formik.errors.name)}
                        helperText={formik.touched.name && formik.errors.name}
                        placeholder="Enter Title"
                        variant="outlined"
                        color="secondary"
                        className="textField"
                        fullWidth
                        size="medium"
                        sx={{ marginBottom: '1rem' }}
                    />
                </Stack>
                <Stack spacing={0.5} mb={3}>
                    <Typography variant="subtitle1">Category Description</Typography>
                    <TextField
                        name="description"
                        value={formik.values.description}
                        onChange={formik.handleChange}
                        error={formik.touched.description && Boolean(formik.errors.description)}
                        helperText={formik.touched.description && formik.errors.description}
                        placeholder="category description"
                        variant="outlined"
                        color="secondary"
                        className="textField"
                        fullWidth
                        size="medium"
                        sx={{ marginBottom: '1rem' }}
                    />
                </Stack>
                <Box
                    sx={{
                        backgroundColor: (theme) => theme.palette.divider,
                        width: 'fit-content',
                        padding: '0.35rem 0.75rem',
                        borderRadius: '10px',
                        mx: 'auto'
                    }}
                >
                    <IconButton aria-label="upload picture" component="label" disableRipple sx={{ width: 'unset', height: 'unset' }}>
                        {formik.values.image ? (
                            <Box
                                width="30px"
                                height="30px"
                                sx={{
                                    backgroundImage: `url(${formik.values.image})`,
                                    backgroundSize: 'contain',
                                    backgroundPosition: 'center',
                                    backgroundRepeat: 'no-repeat'
                                }}
                            />
                        ) : (
                            <Icon icon={uploadIcon} width="40px" height="40px" />
                        )}
                        <Typography variant="subtitle1" sx={{ marginLeft: '10px' }}>
                            {formik.values.image ? formik.values.imageName : 'Upload'}
                        </Typography>
                        <input hidden accept="image/*" type="file" onChange={handleImageUpload} />
                    </IconButton>
                </Box>

                <Box display="flex" gap={1} justifyContent="center" alignItems="stretch">
                    <IconButton aria-label="upload picture" disableRipple sx={{ width: 'unset', height: 'unset' }}>
                        {formik.values.image && (
                            <IconRoot width="16px" height="16px" color={theme.palette.primary.main}>
                                <ReactSVG src="/static/icons/upload.svg" />
                            </IconRoot>
                        )}
                        <Typography variant="caption" color="error">
                            {formik.values.image ? 'Upload New' : 'Upload Icon of size 50x50'}
                        </Typography>
                    </IconButton>
                </Box>
            </DialogContent>
            <DialogActions align="center">
                <Button variant="contained" color="error" onClick={() => handleClose('edit')} sx={{ width: '100px' }}>
                    Cancel
                </Button>
                <Button variant="contained" color="primary" sx={{ width: '100px' }} onClick={formik.handleSubmit} disabled={loading}>
                    {loading ? <CircularProgress size="1.5rem" color="secondary" /> : slug === 'Creating' ? 'Create' : 'Update'}
                </Button>
            </DialogActions>
            <Box position="absolute" top="0" right="0">
                <IconButton onClick={() => handleClose('edit')} color="inherit" disableRipple>
                    <Icon icon={closeCircleOutline} width="inherit" height="inherit" />
                </IconButton>
            </Box>
        </Dialog>
    );
}
