import { useFormik } from 'formik';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import * as yup from 'yup';

import { Box, IconButton, MenuItem, Select, Stack, Typography } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import closeCircleOutline from '@iconify/icons-mdi/close-circle-outline';
import { Icon } from '@iconify/react';

const FilterProductDialog = ({ open, handleDialog, dialogSubmit }) => {
    const [selectedFilterItems, setSelectedFilterItems] = useState(null);
    const { brands } = useSelector((st) => st.brand);
    const { categories } = useSelector((st) => st.category);

    const initialValues = {
        filterBy: 'brand',
        selectedFilterItem: brands?.[0]?.id
    };

    const validationSchema = yup.object({
        filterBy: yup.mixed().required('select filter by option'),
        selectedFilterItem: yup.mixed().required('select item to filter product')
    });

    const formik = useFormik({
        initialValues,
        validationSchema,
        validateOnBlur: false,
        validateOnChange: true,
        onSubmit: (values) => {
            handleDialog();
            dialogSubmit(values);
        }
    });

    useEffect(() => {
        if (formik.values.filterBy === 'brand') {
            if (!brands) formik.setFieldValue('selectedFilterItem', brands?.[0]?.id);
            setSelectedFilterItems(brands);
        } else if (formik.values.filterBy === 'category') {
            formik.setFieldValue('selectedFilterItem', categories?.[0]?.id);
            setSelectedFilterItems(categories);
        }
    }, [formik.values.filterBy]);

    return (
        <Dialog open={open} onClose={handleDialog} fullWidth={false}>
            <DialogTitle align="center">Filter Products By</DialogTitle>
            <DialogContent sx={{ marginTop: '1.5rem' }}>
                <Stack spacing={0.5} mb={2}>
                    <Typography variant="subtitle1">Filter By</Typography>
                    <Select id="filterBy" name="filterBy" value={formik.values.filterBy} onChange={formik.handleChange} sx={{ flex: 1 }}>
                        <MenuItem value="brand">Brand</MenuItem>
                        <MenuItem value="category">Category</MenuItem>
                        <MenuItem value="sub_category">Sub-Category</MenuItem>
                    </Select>
                </Stack>
                {selectedFilterItems && (
                    <Stack spacing={0.5}>
                        <Typography variant="subtitle1">Filter Item</Typography>
                        <Select
                            id="selectedFilterItem"
                            name="selectedFilterItem"
                            value={formik.values.selectedFilterItem}
                            onChange={formik.handleChange}
                            sx={{ flex: 1 }}
                            defaultValue={formik.values.filterBy === 'brand' ? brands?.[0]?.id : categories?.[0]?.id}
                        >
                            {selectedFilterItems?.map((el) => (
                                <MenuItem key={el.id} value={el.id}>
                                    {el.label}
                                </MenuItem>
                            ))}
                        </Select>
                    </Stack>
                )}
            </DialogContent>
            <DialogActions align="center">
                <Button variant="contained" color="error" onClick={handleDialog} sx={{ width: '100px' }}>
                    Cancel
                </Button>
                <Button variant="contained" color="primary" onClick={formik.handleSubmit} sx={{ width: '100px' }}>
                    Filter
                </Button>
            </DialogActions>
            <Box position="absolute" top="0" right="0">
                <IconButton onClick={handleDialog} color="inherit" disableRipple>
                    <Icon icon={closeCircleOutline} width="inherit" height="inherit" />
                </IconButton>
            </Box>
        </Dialog>
    );
};

export default FilterProductDialog;
