import { Icon } from '@iconify/react';
import { useFormik } from 'formik';
import React, { useState } from 'react';
import { toast } from 'react-toastify';
import * as yup from 'yup';

import { Box, CircularProgress, IconButton, Stack, TextField, Typography } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import { Chip } from 'components/Chip';

import closeCircleOutline from '@iconify/icons-mdi/close-circle-outline';
import { useParams } from 'react-router';

export default function ColourForm({ open, handleClose, slug, updColours }) {
    const [colours, setColours] = useState(null);
    const [loading, setLoading] = useState(false);

    const { id } = useParams();

    const initialValues = {
        label: '',
        value: ''
    };

    const validationSchema = yup.object({
        label: yup.string().required('Enter colour label').min(3, 'label should be atleast 3 characters long'),
        value: yup.string().required('Enter colour value')
    });

    const formik = useFormik({
        initialValues,
        validationSchema,
        validateOnBlur: false,
        validateOnChange: true,
        onSubmit: (values) => {
            if (colours?.length > 0) setColours((st) => [...st, { ...values }]);
            else setColours([{ ...values }]);
            formik.resetForm();
        }
    });

    const handleDelete = (value) => {
        setColours(colours.filter((el) => el.value !== value));
    };

    const handleSaveColours = () => {
        // setLoading(true);
        // addColoursToSub(id, { colours: colours })
        //     .then((res) => {
        //         if (res.status === 200) {
        //             toast.success('New colours added successfully');
        //             formik.resetForm();
        //             handleClose();
        //             let getResColours = res.data.map(({ subCategory, ...rest }) => rest);
        //             updColours((st) => ({ ...st, colours: [...st.colours, ...getResColours] }));
        //         }
        //     })
        //     .catch((er) => toast.error(er))
        //     .finally(() => setLoading(false));
    };

    return (
        <Dialog open={open} onClose={handleClose} fullWidth={false}>
            <DialogTitle align="center" sx={{ fontWeight: 700 }}>
                {slug} Colours
            </DialogTitle>
            <DialogContent sx={{ marginTop: '1.25rem' }}>
                <Stack direction="row" spacing={2} mb={3}>
                    <Stack spacing={0.5}>
                        <Typography variant="subtitle1">Colour label</Typography>
                        <TextField
                            name="label"
                            value={formik.values.label}
                            onChange={formik.handleChange}
                            error={formik.touched.label && Boolean(formik.errors.label)}
                            helperText={formik.touched.label && formik.errors.label}
                            placeholder="colour label"
                            variant="outlined"
                            color="secondary"
                            className="textField"
                            fullWidth
                            size="medium"
                            sx={{ marginBottom: '1rem' }}
                        />
                    </Stack>
                    <Stack spacing={0.5}>
                        <Typography variant="subtitle1">Colour Value</Typography>
                        <TextField
                            name="value"
                            value={formik.values.value}
                            onChange={formik.handleChange}
                            error={formik.touched.value && Boolean(formik.errors.value)}
                            helperText={formik.touched.value && formik.errors.value}
                            placeholder="colour value"
                            variant="outlined"
                            color="secondary"
                            className="textField"
                            fullWidth
                            size="medium"
                            sx={{ marginBottom: '1rem' }}
                        />
                    </Stack>
                    <Stack justifyContent="end">
                        <Button variant="contained" type="submit" onClick={formik.handleSubmit} size="large">
                            Add
                        </Button>
                    </Stack>
                </Stack>
                {colours?.length > 0 &&
                    colours.map((el) => <Chip label={el.label} onDelete={() => handleDelete(el.value)} color="primary" />)}
            </DialogContent>
            <DialogActions align="center">
                <Button variant="contained" color="error" onClick={handleClose} sx={{ width: '100px' }}>
                    Cancel
                </Button>
                <Button
                    variant="contained"
                    color="primary"
                    sx={{ width: '100px' }}
                    onClick={handleSaveColours}
                    disabled={loading || colours === null || colours?.length === 0}
                >
                    {loading ? <CircularProgress size="1.5rem" color="secondary" /> : 'Update'}
                </Button>
            </DialogActions>
            <Box position="absolute" top="0" right="0">
                <IconButton onClick={handleClose} color="inherit" disableRipple>
                    <Icon icon={closeCircleOutline} width="inherit" height="inherit" />
                </IconButton>
            </Box>
        </Dialog>
    );
}
