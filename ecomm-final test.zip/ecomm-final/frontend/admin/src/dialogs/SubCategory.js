/* eslint-disable react-hooks/exhaustive-deps */
import { Icon } from '@iconify/react';
import { useFormik } from 'formik';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ReactSVG } from 'react-svg';
import { toast } from 'react-toastify';
import * as yup from 'yup';

import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import {
    Box,
    Checkbox,
    CircularProgress,
    FormControlLabel,
    IconButton,
    MenuItem,
    Select,
    Stack,
    TextField,
    Typography,
    useTheme
} from '@mui/material';

import closeCircleOutline from '@iconify/icons-mdi/close-circle-outline';
import uploadIcon from '@iconify/icons-mdi/upload';

import { remoteUrl } from 'api';
import { getSubCatOfCat } from 'api/category';
import { IconRoot } from 'components/IconRoot';
import { addNewSubCate, updateSubCateInfo, updateSubCatePic } from 'store/reducers/subCategory/extraReducers';

export const colors = [
    { label: 'black', value: 'black' },
    { label: 'Grey', value: 'grey' },
    { label: 'White', value: 'white' },
    { label: 'Beige', value: 'beige' },
    { label: 'Red', value: 'Red' },
    { label: 'Pink', value: 'Pink' },
    { label: 'Purple', value: 'Purple' },
    { label: 'Blue', value: 'Blue' },
    { label: 'Green', value: 'Green' },
    { label: 'Yellow', value: 'Yellow' },
    { label: 'Orange', value: 'Orange' },
    { label: 'Brown', value: 'Brown' },
    { label: 'Gold', value: 'Gold' },
    { label: 'Silver', value: 'Silver' },
    { label: 'Olive', value: 'olive' }
];

export default function SubCategoryForm({ open, handleClose, update = false, rowInfo, slug }) {
    const { categories } = useSelector((st) => st.category);
    const [subCategories, setSubCategories] = useState({ fetching: true, subCats: null });
    const [loading, setLoading] = useState(false);

    const [file, setFile] = React.useState(null);
    const theme = useTheme();
    const dispatch = useDispatch();

    React.useEffect(() => {
        if (!update || !rowInfo) return;

        formik.setValues({
            label: rowInfo.label,
            description: rowInfo.description,
            image: rowInfo?.picture?.includes('/uploads') ? `${remoteUrl}${rowInfo.picture}` : rowInfo.picture,
            logoName: rowInfo?.picture?.split('/')?.pop(),
            update: update
        });
        setFile(rowInfo.picture);
    }, [rowInfo, update]);

    const initialValues = {
        category: categories?.[0]?.id || '',
        isNestedSubCat: true,
        subCategory: null,
        image: '',
        label: '',
        description: '',
        colors: colors[0].value,
        update: false
    };

    const validationSchema = yup.object({
        label: yup.string().required('specify sub category label').min(3, 'Label should be atleast 3 characters long'),
        description: yup.string().min(3, 'Description should be atleast 3 characters long'),
        category: yup.mixed().when('update', (update, schema) => {
            if (update) return schema;
            else return schema.required('specify category');
        }),
        isNestedSubCat: yup.boolean(),
        subCategory: yup.mixed().when('isNestedSubCat', (isNestedSubCat, schema) => {
            if (update) return schema;
            if (isNestedSubCat === false) return schema;
            else return schema.required('specify sub category');
        })
    });

    const formik = useFormik({
        initialValues,
        validationSchema,
        validateOnBlur: false,
        validateOnChange: true,
        onSubmit: (values) => {
            if (formik.values.image) {
                const formData = new FormData();
                formData.append('picture', file);
                formData.append('label', values.label);
                formData.append('description', values.description);
                formData.append('category_id', values.category);
                values.isNestedSubCat && formData.append('parent_subcategory_id', values.subCategory);

                if (update) {
                    setLoading(true);
                    dispatch(updateSubCateInfo({ subCatId: rowInfo.id, info: { label: values.label, description: values.description } }))
                        .then((res) => {
                            if (res.meta.requestStatus === 'fulfilled')
                                toast.success('Sub category info updated successfully');
                            handleClose('edit');
                        })
                        .catch((er) => toast.error(er))
                        .finally(() => setLoading(false));
                } else {
                    let parentInfo = values.isNestedSubCat && {
                        value: values.subCategory,
                        label: subCategories.subCats?.filter((el) => el.id === values.subCategory)[0].label
                    };
                    setLoading(true);
                    dispatch(addNewSubCate({ info: formData, parentInfo }))
                        .then((res) => {
                            console.log('res', res)
                            toast.success('Sub Category created successfully');
                            handleClose();
                        })
                        .catch((er) => {
                            console.log('er', er)
                            toast.error(er)
                        })
                        .finally(() => setLoading(false));
                }
            } else toast.error('Please select image of category');
        }
    });

    useEffect(() => {
        if (update) return;
        if (formik.values.category !== '' && open) setSubCategories({ fetching: true, subCats: null });
        getSubCatOfCat(formik.values.category).then((res) => {
            setSubCategories({ fetching: false, subCats: res.data.data.filter((ele) => ele.parent_subcategory === null) });
            formik.setFieldValue('subCategory', res.data.data?.filter((ele) => ele.parent_subcategory === null)[0]?.id);
            // formik.setFieldValue('subCategory', res.data.subCategories[0]?.id);
        });
    }, [formik.values.category]);

    const handleImageUpload = async (e) => {
        const selectedFile = await e.target.files[0];

        if (selectedFile) {
            if (update) {
                const formData = new FormData();
                formData.append('picture', selectedFile);
                dispatch(updateSubCatePic({ subCatId: rowInfo.id, image: formData })).then((res) => {
                    setFile(selectedFile);
                    formik.setFieldValue('image', URL.createObjectURL(selectedFile));
                    formik.setFieldValue('logoName', selectedFile.name);
                    toast.success('Sub category image updated successfully');
                });
            } else {
                setFile(selectedFile);
                formik.setFieldValue('image', URL.createObjectURL(selectedFile));
                formik.setFieldValue('logoName', selectedFile.name);
            }
        }
    };

    return (
        <Dialog maxWidth="md" open={open} onClose={() => handleClose('edit')} fullWidth={true}>
            <DialogTitle align="center" sx={{ fontWeight: 700 }}>
                {slug} Sub-Category
            </DialogTitle>
            <DialogContent sx={{ marginTop: '1.25rem' }}>
                {!update && (
                    <>
                        <Stack spacing={0.5} mb={2}>
                            <Typography variant="subtitle1">Category</Typography>
                            <Select
                                id="category"
                                name="category"
                                value={formik.values.category}
                                onChange={formik.handleChange}
                                sx={{ flex: 1 }}
                                defaultValue={categories?.[0]?.id}
                            >
                                {categories?.map((el) => (
                                    <MenuItem key={el.id} value={el.id}>
                                        {el.label}
                                    </MenuItem>
                                ))}
                            </Select>
                        </Stack>
                        <Stack spacing={2} mb={2} direction="row" alignItems="end">
                            {formik.values.isNestedSubCat && (
                                <Stack spacing={0.5} sx={{ flexBasis: '55%' }}>
                                    <Typography variant="subtitle1">Sub Category</Typography>
                                    {subCategories.subCats ? <Select
                                        id="subCategory"
                                        name="subCategory"
                                        value={formik.values.subCategory}
                                        onChange={formik.handleChange}
                                        sx={{ flex: 1 }}
                                    >
                                        {subCategories.subCats?.map((el) => (
                                            <MenuItem key={el.id} value={el.id}>
                                                {el.label}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                        :
                                        <Select
                                            id="subCategory"
                                            name="subCategory"
                                            value={[
                                                { id: 0, label: 'loading...' }
                                            ][0].id}
                                            onChange={(e) => console.log(e)}
                                            sx={{ flex: 1 }}
                                        >
                                            <MenuItem style={{
                                                display: 'flex',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                gap: '0.5rem'
                                            }} key={0} value={0}>
                                                Loading <CircularProgress size="1rem" color="secondary" />
                                            </MenuItem>
                                        </Select>}
                                </Stack>
                            )}
                            <Stack spacing={0.5} sx={{ flexBasis: '45%' }}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={formik.values.isNestedSubCat}
                                            onChange={formik.handleChange}
                                            name="isNestedSubCat"
                                            color="primary"
                                            size="small"
                                        />
                                    }
                                    label={<Typography variant="body2">Nested SubCategory</Typography>}
                                />
                            </Stack>
                        </Stack>
                    </>
                )}
                <Stack spacing={0.5} mb={2}>
                    <Typography variant="subtitle1">Name</Typography>
                    <TextField
                        name="label"
                        value={formik.values.label}
                        onChange={formik.handleChange}
                        error={formik.touched.label && Boolean(formik.errors.label)}
                        helperText={formik.touched.label && formik.errors.label}
                        placeholder="new sub category name"
                        variant="outlined"
                        color="secondary"
                        className="textField"
                        fullWidth
                        size="medium"
                        sx={{ marginBottom: '1rem' }}
                    />
                </Stack>
                <Stack spacing={0.5} mb={3}>
                    <Typography variant="subtitle1">Description</Typography>
                    <TextField
                        name="description"
                        value={formik.values.description}
                        onChange={formik.handleChange}
                        error={formik.touched.description && Boolean(formik.errors.description)}
                        helperText={formik.touched.description && formik.errors.description}
                        placeholder="new sub category description"
                        variant="outlined"
                        color="secondary"
                        className="textField"
                        fullWidth
                        size="medium"
                        sx={{ marginBottom: '1rem' }}
                    />
                </Stack>

                <Box
                    sx={{
                        backgroundColor: (theme) => theme.palette.divider,
                        width: 'fit-content',
                        padding: '0.35rem 0.75rem',
                        borderRadius: '10px',
                        marginInline: 'auto'
                    }}
                >
                    <IconButton aria-label="upload picture" component="label" disableRipple sx={{ width: 'unset', height: 'unset' }}>
                        {formik.values.image ? (
                            <Box
                                width="30px"
                                height="30px"
                                sx={{
                                    backgroundImage: `url(${formik.values.image})`,
                                    backgroundSize: 'contain',
                                    backgroundPosition: 'center',
                                    backgroundRepeat: 'no-repeat'
                                }}
                            />
                        ) : (
                            <Icon icon={uploadIcon} width="40px" height="40px" />
                        )}
                        <Typography variant="subtitle1" sx={{ marginLeft: '10px' }}>
                            {formik.values.image ? formik.values.logoName : 'Upload'}
                        </Typography>

                        <input hidden accept="image/*" type="file" onChange={handleImageUpload} />
                    </IconButton>
                </Box>

                <Box display="flex" gap={1} justifyContent="center" alignItems="stretch">
                    <IconButton aria-label="upload picture" disableRipple sx={{ width: 'unset', height: 'unset' }}>
                        {formik.values.image && (
                            <IconRoot width="16px" height="16px" color={theme.palette.primary.main}>
                                <ReactSVG src="/static/icons/upload.svg" />
                            </IconRoot>
                        )}
                        <Typography variant="caption" color="error">
                            {formik.values.image ? 'Upload New' : 'Upload Icon of size 50x50'}
                        </Typography>
                    </IconButton>
                </Box>
            </DialogContent>
            <DialogActions align="center">
                <Button variant="contained" color="error" onClick={() => handleClose('edit')} sx={{ width: '100px' }}>
                    Cancel
                </Button>
                <Button variant="contained" color="primary" onClick={formik.handleSubmit} disabled={loading}>
                    {loading ? <CircularProgress size="1.5rem" color="secondary" /> : slug === 'Creating' ? 'Create' : 'Update Info'}
                </Button>
            </DialogActions>
            <Box position="absolute" top="0" right="0">
                <IconButton onClick={() => handleClose('edit')} color="inherit" disableRipple>
                    <Icon icon={closeCircleOutline} width="inherit" height="inherit" />
                </IconButton>
            </Box>
        </Dialog>
    );
}
