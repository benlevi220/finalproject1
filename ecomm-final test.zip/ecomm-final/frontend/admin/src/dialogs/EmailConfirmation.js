import * as React from 'react';

import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { Box, IconButton, Typography } from '@mui/material';

import HighlightOffOutlinedIcon from '@mui/icons-material/HighlightOffOutlined';

export default function EmailConfirmation({ open, toggleDialog, mail, emailFor }) {
    return (
        <Dialog open={open} onClose={toggleDialog} fullWidth={false}>
            <DialogTitle align="center">Confirmation</DialogTitle>
            <DialogContent align="center">
                <Typography variant="subtitle1" sx={{ maxWidth: 300 }}>
                    A Confirmation email has been sent on {mail}. Open your email and confirm that its you trying to change {emailFor}.
                </Typography>
            </DialogContent>
            <Box position="absolute" top="0" right="0">
                <IconButton onClick={toggleDialog} color="inherit" disableRipple>
                    <HighlightOffOutlinedIcon sx={{ fontSize: '1.75rem' }} />
                </IconButton>
            </Box>
        </Dialog>
    );
}
