import React from 'react';
import { Icon } from '@iconify/react';

import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { Box, Button, CircularProgress, DialogActions, IconButton, Typography } from '@mui/material';

import closeCircleOutline from '@iconify/icons-mdi/close-circle-outline';

export default function ActionConfirmation({ open, handleClose, submit, loading }) {
    return (
        <Dialog open={open} onClose={() => handleClose('del')} fullWidth={false}>
            <DialogTitle align="center">Confirmation</DialogTitle>
            <DialogContent align="center">
                <Typography variant="subtitle1" sx={{ maxWidth: 340 }}>
                    Are you sure you want to delete selected item?
                </Typography>
            </DialogContent>
            <DialogActions align="center">
                <Button variant="contained" onClick={() => handleClose('del')} sx={{ width: '100px' }}>
                    Cancel
                </Button>
                <Button variant="contained" color="error" onClick={submit} sx={{ width: '100px' }} disabled={loading}>
                    {loading ? <CircularProgress size="1.5rem" color="secondary" /> : 'Delete'}
                </Button>
            </DialogActions>
            <Box position="absolute" top="0" right="0">
                <IconButton onClick={() => handleClose('del')} color="inherit" disableRipple>
                    <Icon icon={closeCircleOutline} width="30px" height="30px" />
                </IconButton>
            </Box>
        </Dialog>
    );
}
