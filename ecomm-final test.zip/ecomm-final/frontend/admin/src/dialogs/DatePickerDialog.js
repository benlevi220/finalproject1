import { Icon } from '@iconify/react';
import React, { useState } from 'react';

import { Box, IconButton, Stack, Typography } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import closeCircleOutline from '@iconify/icons-mdi/close-circle-outline';
import CustomDatePicker from 'components/DatePircker';
import { format } from 'date-fns';

export default function DatePickerDialog({ open, handleToggle, handleSubmit }) {
    const [dateFrom, setDateFrom] = useState(format(new Date(), 'MM/dd/yyyy'));
    const [dateTo, setDateTo] = useState(format(new Date(), 'MM/dd/yyyy'));

    return (
        <Dialog open={open} onClose={handleToggle} fullWidth={false}>
            <DialogTitle align="center" sx={{ fontWeight: 700 }}>
                Filter By Date
            </DialogTitle>
            <DialogContent sx={{ marginTop: '1.25rem' }}>
                <Stack direction="row" spacing={3}>
                    <Stack spacing={1}>
                        <Typography variant="subtitle1">From</Typography>
                        <CustomDatePicker
                            value={dateFrom}
                            onDateChange={(newValue) => setDateFrom(format(new Date(newValue), 'MM/dd/yyyy'))}
                            disablePast={false}
                        />
                    </Stack>
                    <Stack spacing={1}>
                        <Typography variant="subtitle1">To</Typography>
                        <CustomDatePicker
                            value={dateTo}
                            onDateChange={(newValue) => setDateTo(format(new Date(newValue), 'MM/dd/yyyy'))}
                            disablePast={false}
                        />
                    </Stack>
                </Stack>
            </DialogContent>
            <DialogActions align="center">
                <Stack mt={3} spacing={2} direction={'row'} alignItems={'center'}>
                    <Button variant="outlined" onClick={handleToggle} fullWidth>
                        Cancel
                    </Button>
                    <Button variant="contained" onClick={() => handleSubmit(dateFrom, dateTo)} fullWidth>
                        Submit
                    </Button>
                </Stack>
            </DialogActions>
            <Box position="absolute" top="0" right="0">
                <IconButton onClick={handleToggle} color="inherit" disableRipple>
                    <Icon icon={closeCircleOutline} width="inherit" height="inherit" />
                </IconButton>
            </Box>
        </Dialog>
    );
}
