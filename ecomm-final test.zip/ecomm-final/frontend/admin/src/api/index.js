import axios from 'axios';

export const productionURL = process.env.REACT_APP_API;
export const developmentURL = 'http://localhost:5000/api/v1';

export const baseURL = process.env.REACT_APP_API === 'development' ? developmentURL : productionURL;

export const remoteUrl = process.env.REACT_APP_ORIGIN;
const axiosInstance = axios.create({
    baseURL
});

// List of endpoints where "Authorization" header should be excluded
const excludeAuthHeaderEndpoints = ['/auth/login', '/validateOtp'];

// Add an interceptor to set the "Authorization" header for requests, excluding specific endpoints
axiosInstance.interceptors.request.use(
    (config) => {
        const authToken = localStorage.getItem('shopNow-token');
        if (authToken && config.url) {
            console.log('Request URL:', config.url); // Debugging log
            if (!excludeAuthHeaderEndpoints.some((endpoint) => config.url.endsWith(endpoint))) {
                config.headers['Authorization'] = `Bearer ${authToken}`;
            }
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

export const errorResponse = ({ response: res }) => ({
    message: res?.data?.msg || 'Something Went Wrong'
});

export default axiosInstance;
