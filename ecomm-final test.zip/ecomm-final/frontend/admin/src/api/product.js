import axiosInstance from './index';

export const getAllProducts = () => axiosInstance.get(`/products`);
export const getAllProductById = (prodId) => axiosInstance.get(`/products/${prodId}`);
export const addNewProduct = (values) =>
    axiosInstance.post('/products', values, {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    });
export const delProduct = (prodId) => axiosInstance.delete(`/products/${prodId}`);
export const updateProduct = (prodId, values) =>
    axiosInstance.patch(`/products/${prodId}`, values, {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    });
export const filterProdBy = (filterName, filterItemId) => axiosInstance.get(`/product/${filterName}/${filterItemId}`);
