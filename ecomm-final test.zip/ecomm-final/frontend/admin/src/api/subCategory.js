import axiosInstance from './index';

export const getAllSubCategories = () => axiosInstance.get(`/subcategory/?limit=1000`);
export const addNewSubCategory = (values) => axiosInstance.post('/subcategory', values);
export const deleteSubCategory = (subCatId) => axiosInstance.delete(`/subcategory/${subCatId}`);
export const addSubCategoryColor = (subCatId, values) => axiosInstance.post(`/subcategory/${subCatId}/colours`, values);
export const addSubCategorySize = (subCatId, values) => axiosInstance.post(`/subcategory/${subCatId}/sizes`, values);
export const updateSubCatePic = (subCatId, image) => axiosInstance.post(`/subcategory/${subCatId}/picture`, image);
export const updateSubCateInfo = (subCatId, values) => axiosInstance.put(`/subcategory/${subCatId}`, values);
export const getSubCatbyId = (subCatId) => axiosInstance.get(`/subcategory/${subCatId}`);
