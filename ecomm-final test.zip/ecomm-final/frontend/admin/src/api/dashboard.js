import axiosInstance from './index';

export const getBasicDashboardInfo = () => axiosInstance.get('/admin/dashboard');
