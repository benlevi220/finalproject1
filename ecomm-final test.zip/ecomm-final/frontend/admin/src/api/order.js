import buildUrlWithQueryParams from 'utils/buildQueryParams';
import axiosInstance from './index';

export const getAllOrders = (params) => axiosInstance.get(buildUrlWithQueryParams('/orders', params));
