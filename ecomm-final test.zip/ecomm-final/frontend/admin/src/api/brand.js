import axiosInstance from './index';

export const getAllBrands = () => axiosInstance.get('/brand');
export const addNewBrand = (values) => axiosInstance.post('/brand', values);
export const deleteBrand = (id) => axiosInstance.delete(`/brand/${id}`);
