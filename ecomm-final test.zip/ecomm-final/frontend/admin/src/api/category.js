import axiosInstance from './index';

export const getAllCategories = () => axiosInstance.get('/categories');
export const addNewCategory = (values) =>
    axiosInstance.post('/categories', values, {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    });
export const delCategory = (catId) => axiosInstance.delete(`/categories/${catId}`);
export const updateCategory = (catId, values) =>
    axiosInstance.patch(`/categories/${catId}`, values, {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    });
export const getSubCatOfCat = (catId) => axiosInstance.get(`/category/${catId}`);
