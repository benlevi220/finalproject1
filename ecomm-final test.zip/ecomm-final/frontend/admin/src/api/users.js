import axiosInstance from './index';

export const getMe = () => axiosInstance.get('/auth/me');
export const logIn = (values) => axiosInstance.post('/auth/login', values);
export const createUser = (values) => axiosInstance.post('/admin/users', values);
export const blockUser = ({ userId, block }) => axiosInstance.post(`/admin/users/${userId}/block`, { block });
export const getAllUsers = () => axiosInstance.get('/admin/users');
