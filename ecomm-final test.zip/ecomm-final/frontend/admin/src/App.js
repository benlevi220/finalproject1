import ThemeCustomization from 'themes';
import ScrollTop from 'components/ScrollTop';
import Router from 'routes';

const App = () => (
    <ThemeCustomization>
        <ScrollTop>
            <Router />
        </ScrollTop>
    </ThemeCustomization>
);

export default App;
