// assets
import accountGroup from '@iconify/icons-mdi/account-group';
import ansibleIcon from '@iconify/icons-mdi/ansible';
import graphIcon from '@iconify/icons-mdi/graph';
import phoneLog from '@iconify/icons-mdi/phone-log';
import saleIcon from '@iconify/icons-mdi/sale';
import shapeIcon from '@iconify/icons-mdi/shape';
import shoppingSearch from '@iconify/icons-mdi/shopping-search';
import storeCog from '@iconify/icons-mdi/store-cog';
import viewDashboard from '@iconify/icons-mdi/view-dashboard';

import cartVariant from '@iconify/icons-mdi/cart-variant';
import creditCardOutline from '@iconify/icons-mdi/credit-card-outline';
import giftIcon from '@iconify/icons-mdi/gift';

// ==============================|| MENU ITEMS - DASHBOARD ||============================== //

const dashboard = {
    id: 'group-dashboard',
    type: 'group',
    children: [
        // {
        //     id: 'dashboard',
        //     title: 'Dashboard',
        //     type: 'item',
        //     url: '/dashboard',
        //     icon: viewDashboard,
        //     breadcrumbs: false
        // },
        {
            id: 'users',
            title: 'Users',
            type: 'item',
            url: '/users',
            icon: accountGroup
        },
        {
            id: 'categories',
            title: 'Categories',
            type: 'item',
            url: '/categories',
            icon: shapeIcon
        },
        {
            id: 'products',
            title: 'Products',
            type: 'item',
            url: '/products',
            icon: shoppingSearch
        },
        {
            id: 'orders',
            title: 'Orders',
            type: 'item',
            url: '/orders',
            icon: cartVariant
        }
        // {
        //     id: 'sales',
        //     title: 'Sales',
        //     type: 'item',
        //     url: '/sales',
        //     icon: saleIcon
        // }

        // {
        //     id: 'contact',
        //     title: 'Contact Us',
        //     type: 'item',
        //     url: '/contactus',
        //     icon: phoneLog
        // }
    ]
};

export default dashboard;
