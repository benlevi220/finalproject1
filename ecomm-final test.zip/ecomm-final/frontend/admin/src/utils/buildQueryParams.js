import { baseURL } from '../api';

// Create a function to build the URL with query parameters
export default function buildUrlWithQueryParams(endpointUrl, queryParams) {
  let url = `${baseURL}${endpointUrl}`;
  const queryParamArray = [];
  if (!queryParams || Object.keys(queryParams).length === 0) return url;
  for (const [key, value] of Object.entries(queryParams))
    if (value !== undefined) queryParamArray.push(`${key}=${value.toString()}`);
  if (queryParamArray.length > 0) url += `?${queryParamArray.join('&')}`;

  return url;
}
