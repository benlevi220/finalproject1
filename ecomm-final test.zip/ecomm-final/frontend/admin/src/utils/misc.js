export const getFormatDate = (d) => {
    let date = new Date(d);
    const yyyy = date.getFullYear();
    let mm = date.getMonth();
    let dd = date.getDate();

    return `${dd} ${months[mm]}, ${yyyy}`;
};

const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export default function compareDates(firstDate, secondDate) {
    if (firstDate > secondDate) {
        return true;
    } else {
        return false;
    }
}

export const getTotalOfOrder = (arr) => {
    let total = 0;
    if (arr?.length > 0) {
        arr.forEach((el) => (total += Number(el.quantity) * +el.product.details.offered_price));
    }
    return total;
};

export const calcEarning = (offeredPrice, discount) => {
    if (discount === 'stdrd_no_discount') return offeredPrice - 0.15 * offeredPrice;
    if (discount === 'stdrd_25_discount') return offeredPrice - 0.15 * offeredPrice - 20 / 4;
    if (discount === 'stdrd_50_discount') return offeredPrice - 0.15 * offeredPrice - 20 / 2;
    if (discount === 'stdrd_free') return offeredPrice - 0.15 * offeredPrice - 20;
};

export const PaymentRequestStatus = ['pending', 'approved', 'rejected'];
