import { createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance, { errorResponse } from 'api/index';
import { toast } from 'react-toastify';

export const getMe = createAsyncThunk('/auth/verifyMe', async (_, { rejectWithValue }) => {
    return axiosInstance
        .get('/auth/me')
        .then(({ data }) => ({
            user: data.user
        }))
        .catch((err) => rejectWithValue(errorResponse(err)));
});

export const login = createAsyncThunk('/auth/login', async (values, { rejectWithValue }) => {
    return axiosInstance
        .post('/auth/login', values)
        .then((res) => {
            console.log('res', res);
            return { user: res.data.user, token: res.data.token };
        })
        .catch((err) => {
            console.log('err', err);
            toast.error(errorResponse(err).message);
            return rejectWithValue(errorResponse(err));
        });
});
