import { createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from 'api/index';
import * as userApi from 'api/users.js';
import { toast } from 'react-toastify';

export const getUsers = createAsyncThunk('/users', async (_, { rejectWithValue }) => {
    return axiosInstance
        .get('/users')
        .then((res) => ({ users: res.data.user, totalUsers: res.data.total_users }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const addUser = createAsyncThunk('/users/new', async (values, { rejectWithValue }) => {
    return userApi
        .createUser(values)
        .then((res) => ({ user: res.data }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});
export const blockUser = createAsyncThunk('/users/block', async (values, { rejectWithValue }) => {
    return userApi
        .blockUser(values)
        .then((res) => ({ user: res.data }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});
