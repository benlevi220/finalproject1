import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import { addUser, blockUser, getUsers } from './extraReducers';

const initialState = {
    users: null,
    totalUsers: 0,
    loading: false,
    fetching: true
};

const userSlice = createSlice({
    name: 'users',
    initialState,
    extraReducers: (builder) => {
        builder
            .addCase(getUsers.pending, (state) => {
                state.fetching = true;
            })
            .addCase(getUsers.fulfilled, (state, { payload }) => {
                state.users = payload.users;
                state.totalUsers = payload.totalUsers;
                state.fetching = false;
            })
            .addCase(getUsers.rejected, (state) => {
                state.fetching = false;
            });
        builder
            .addCase(addUser.pending, (state) => {
                state.loading = true;
            })
            .addCase(addUser.fulfilled, (state, { payload }) => {
                toast.success('User created successfully');
                state.users = state.users ? [payload.user, ...state.users] : [payload.user];
                state.loading = false;
            })
            .addCase(addUser.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(blockUser.pending, (state) => {
                state.loading = true;
            })
            .addCase(blockUser.fulfilled, (state, { payload }) => {
                state.users = state.users.map((el) => (el.id === payload.user.id ? payload.user : el));
                state.loading = false;
            })
            .addCase(blockUser.rejected, (state) => {
                state.loading = false;
            });
    }
});

export default userSlice.reducer;
