import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import {
    updateSubCateInfo,
    getSubCategoryList,
    addNewSubCate,
    updateSubCatePic,
    getSubCategoryByCat,
    deleteSubCate
} from './extraReducers';

const initialState = {
    subCategories: null,
    loading: false,
    fetching: true
};

const subCategorySlice = createSlice({
    name: 'sub-category',
    initialState,
    extraReducers: (builder) => {
        builder
            .addCase(getSubCategoryList.pending, (state) => {
                state.fetching = true;
            })
            .addCase(getSubCategoryList.fulfilled, (state, { payload }) => {
                state.subCategories = payload.subCategories;
                state.fetching = false;
            })
            .addCase(getSubCategoryList.rejected, (state) => {
                state.fetching = false;
            });
        builder
            .addCase(getSubCategoryByCat.pending, (state) => {
                state.fetching = true;
            })
            .addCase(getSubCategoryByCat.fulfilled, (state, { payload }) => {
                state.subCategories = payload.subCategories;
                state.fetching = false;
            })
            .addCase(getSubCategoryByCat.rejected, (state) => {
                state.fetching = false;
            });
        builder
            .addCase(updateSubCateInfo.pending, (state) => {
                state.loading = true;
            })
            .addCase(updateSubCateInfo.fulfilled, (state, { payload }) => {
                state.subCategories = state.subCategories.map((el) =>
                    el.id === payload.newSubCategory.id ? { ...el, ...payload.newSubCategory } : el
                );
                state.loading = false;
            })
            .addCase(updateSubCateInfo.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(updateSubCatePic.pending, (state) => {
                state.loading = true;
            })
            .addCase(updateSubCatePic.fulfilled, (state, { payload }) => {
                state.subCategories = state.subCategories
                    ? state.subCategories.map((el) => (el.id === payload.newSubCategory.id ? { ...el, ...payload.newSubCategory } : el))
                    : [payload.newSubCategory];
                state.loading = false;
            })
            .addCase(updateSubCatePic.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(addNewSubCate.pending, (state) => {
                state.loading = true;
            })
            .addCase(addNewSubCate.fulfilled, (state, { payload }) => {
                state.subCategories = state.subCategories ? [payload.subCategory, ...state.subCategories] : [payload.subCategory];
                state.loading = false;
            })
            .addCase(addNewSubCate.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(deleteSubCate.pending, (state) => {
                state.loading = true;
            })
            .addCase(deleteSubCate.fulfilled, (state, { payload }) => {
                state.subCategories = state.subCategories.filter((el) => el.id !== +payload.subCategory);
                state.loading = false;
                toast.success('Sub-category deleted successfully');
            })
            .addCase(deleteSubCate.rejected, (state) => {
                state.loading = false;
            });
    }
});

export default subCategorySlice.reducer;
