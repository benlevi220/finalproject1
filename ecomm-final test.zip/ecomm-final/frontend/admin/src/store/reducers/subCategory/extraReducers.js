import { createAsyncThunk } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import * as subCategoryApi from 'api/subCategory';
import * as categoryApi from 'api/category';

export const getSubCategoryList = createAsyncThunk('/getSubCategories', async (_, { rejectWithValue }) => {
    return subCategoryApi
        .getAllSubCategories()
        .then((res) => {
            return { subCategories: res.data };
        })
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const getSubCategoryByCat = createAsyncThunk('/getSubCategoriesByCat', async (catId, { rejectWithValue }) => {
    return categoryApi
        .getSubCatOfCat(catId)
        .then((res) => {
            return { subCategories: res.data.data };
        })
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const updateSubCateInfo = createAsyncThunk('/updateSubCateInfo', async (values, { rejectWithValue }) => {
    return subCategoryApi
        .updateSubCateInfo(values.subCatId, values.info)
        .then((res) => ({ newSubCategory: res.data }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const updateSubCatePic = createAsyncThunk('/updateSubCatePic', async (values, { rejectWithValue }) => {
    return subCategoryApi
        .updateSubCatePic(values.subCatId, values.image)
        .then((res) => ({ newSubCategory: res.data }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const addNewSubCate = createAsyncThunk('/addNewSubCate', async (values, { rejectWithValue }) => {
    return subCategoryApi
        .addNewSubCategory(values.info)
        .then((res) => ({ subCategory: { ...res.data, parent_subcategory: { ...values.parentInfo } } }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const deleteSubCate = createAsyncThunk('/delSubCate', async (values, { rejectWithValue }) => {
    return subCategoryApi
        .deleteSubCategory(values)
        .then((res) => ({ subCategory: values }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});
