import { createSlice } from '@reduxjs/toolkit';
import { getOrders } from './extraReducers';

const initialState = {
    orders: null,
    loading: false,
    fetching: true,
    totalResults: 0
};

const orderSlice = createSlice({
    name: 'orders',
    initialState,
    extraReducers: (builder) => {
        builder
            .addCase(getOrders.pending, (state) => {
                state.fetching = true;
            })
            .addCase(getOrders.fulfilled, (state, { payload }) => {
                state.orders = payload.orders;
                state.totalResults = payload.total_orders;
                state.fetching = false;
            })
            .addCase(getOrders.rejected, (state) => {
                state.fetching = false;
            });
    }
});

export default orderSlice.reducer;
