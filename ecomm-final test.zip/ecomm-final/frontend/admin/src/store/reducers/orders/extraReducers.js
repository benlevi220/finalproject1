import { createAsyncThunk } from '@reduxjs/toolkit';
import * as orderApi from 'api/order';
import { toast } from 'react-toastify';

export const getOrders = createAsyncThunk('/orders', async (params, { rejectWithValue }) => {
    return orderApi
        .getAllOrders(params)
        .then((res) => ({ orders: res.data.orders, total_orders: res.data.total_orders }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});
