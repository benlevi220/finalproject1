import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import { addCategory, deleteCategory, getCategoryList, updateCategory } from './extraReducers';

const initialState = {
    categories: null,
    total_categories: 0,
    loading: false,
    fetching: true
};

const categorySlice = createSlice({
    name: 'category',
    initialState,
    extraReducers: (builder) => {
        builder
            .addCase(getCategoryList.pending, (state) => {
                state.fetching = true;
            })
            .addCase(getCategoryList.fulfilled, (state, { payload }) => {
                state.categories = payload.categories;
                state.total_categories = payload.total_categories;
                state.fetching = false;
            })
            .addCase(getCategoryList.rejected, (state) => {
                state.fetching = false;
            });
        builder
            .addCase(addCategory.pending, (state) => {
                state.loading = true;
            })
            .addCase(addCategory.fulfilled, (state, { payload }) => {
                state.categories = state.categories ? [payload.category, ...state.categories] : [payload.category];
                state.loading = false;
            })
            .addCase(addCategory.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(updateCategory.pending, (state) => {
                state.loading = true;
            })
            .addCase(updateCategory.fulfilled, (state, { payload }) => {
                state.categories = state.categories
                    ? state.categories.map((el) => (el.id === payload.category.id ? { ...payload.category } : el))
                    : [payload.category];
                state.loading = false;
            })
            .addCase(updateCategory.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(deleteCategory.pending, (state) => {
                state.loading = true;
            })
            .addCase(deleteCategory.fulfilled, (state, { payload }) => {
                state.categories = state.categories.filter((el) => el.id !== payload.category);
                state.loading = false;
                toast.success('Category deleted successfully');
            })
            .addCase(deleteCategory.rejected, (state) => {
                state.loading = false;
            });
    }
});

export default categorySlice.reducer;
