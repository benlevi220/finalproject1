import { createAsyncThunk } from '@reduxjs/toolkit';
import * as categoryApi from 'api/category';
import { toast } from 'react-toastify';

export const getCategoryList = createAsyncThunk('/getCategories', async (_, { rejectWithValue }) => {
    return categoryApi
        .getAllCategories()
        .then((res) => ({ categories: res.data.category, total_categories: res.data.total_categories }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const addCategory = createAsyncThunk('/newCategory', async (values, { rejectWithValue }) => {
    return categoryApi
        .addNewCategory(values)
        .then((res) => ({ category: res.data.category }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const deleteCategory = createAsyncThunk('/delCategory', async (values, { rejectWithValue }) => {
    return categoryApi
        .delCategory(values)
        .then(() => ({ category: values }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const updateCategory = createAsyncThunk('/updateCategory', async (values, { rejectWithValue }) => {
    console.log('values', values);
    return categoryApi
        .updateCategory(values.id, values.formData)
        .then((res) => ({ category: res.data.category }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});
