// third-party
import { combineReducers } from 'redux';

// project import
import auth from './auth';
import categories from './category';
import menu from './menu';
import orders from './orders';
import products from './product';
import subCategories from './subCategory';
import users from './users';

// ==============================|| COMBINE REDUCERS ||============================== //

const reducers = combineReducers({
    menu,
    auth: auth,
    users: users,
    category: categories,
    subCategory: subCategories,
    product: products,
    order: orders
});

export default reducers;
