import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import { addProduct, deleteProduct, filterProductBy, getProducts, updateProd } from './extraReducers';

const initialState = {
    products: null,
    loading: false,
    total_products: 0,
    fetching: true
};

const prodSlice = createSlice({
    name: 'products',
    initialState,
    extraReducers: (builder) => {
        builder
            .addCase(getProducts.pending, (state) => {
                state.fetching = true;
            })
            .addCase(getProducts.fulfilled, (state, { payload }) => {
                state.products = payload.products;
                state.total_products = payload.total_products;
                state.fetching = false;
            })
            .addCase(getProducts.rejected, (state) => {
                state.fetching = false;
            });
        builder
            .addCase(addProduct.pending, (state) => {
                state.loading = true;
            })
            .addCase(addProduct.fulfilled, (state, { payload }) => {
                state.products = state.products ? [payload.product, ...state.products] : [payload.product];
                state.total_products += 1;
                state.loading = false;
            })
            .addCase(addProduct.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(updateProd.pending, (state) => {
                state.loading = true;
            })
            .addCase(updateProd.fulfilled, (state, { payload }) => {
                state.products = state.products
                    ? state.products.map((el) => (el.id === payload.product.id ? { ...payload.product } : el))
                    : [payload.product];
                state.loading = false;
            })
            .addCase(updateProd.rejected, (state) => {
                state.loading = false;
            });
        builder
            .addCase(deleteProduct.pending, (state) => {
                state.loading = true;
            })
            .addCase(deleteProduct.fulfilled, (state, { payload }) => {
                state.products = state.products.filter((el) => el.id !== payload.product);
                state.loading = false;
                state.total_products -= 1;
                toast.success('Product deleted successfully');
            })
            .addCase(deleteProduct.rejected, (state) => {
                state.loading = false;
            });
        // builder
        //     .addCase(filterProductBy.pending, (state) => {
        //         state.loading = true;
        //     })
        //     .addCase(filterProductBy.fulfilled, (state, { payload }) => {
        //         state.products = payload.products;
        //         state.loading = false;
        //     })
        //     .addCase(filterProductBy.rejected, (state) => {
        //         state.loading = false;
        //     });
    }
});

export default prodSlice.reducer;
