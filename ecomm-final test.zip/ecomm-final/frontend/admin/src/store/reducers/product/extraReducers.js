import { createAsyncThunk } from '@reduxjs/toolkit';
import * as productApi from 'api/product';
import { toast } from 'react-toastify';
import buildUrlWithQueryParams from 'utils/buildQueryParams';

export const getProducts = createAsyncThunk('/products', async (params, { rejectWithValue }) => {
    return productApi
        .getAllProducts(buildUrlWithQueryParams('/products', params))
        .then((res) => ({ products: res.data.products, total_products: res.data.total_products }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const addProduct = createAsyncThunk('/newProd', async (values, { rejectWithValue }) => {
    return productApi
        .addNewProduct(values)
        .then((res) => ({ product: res.data.product }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const deleteProduct = createAsyncThunk('/delProd', async (values, { rejectWithValue }) => {
    return productApi
        .delProduct(values)
        .then(() => ({ product: values }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const updateProd = createAsyncThunk('/updateProd', async (values, { rejectWithValue }) => {
    return productApi
        .updateProduct(values.id, values.formData)
        .then((res) => ({ product: res.data.product }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});

export const filterProductBy = createAsyncThunk('/product/filterProd', async (values, { rejectWithValue }) => {
    return productApi
        .filterProdBy(values.filterBy, values.selectedFilterItem)
        .then((res) => ({ products: res.data?.products || res.data }))
        .catch((err) => {
            toast.error(err);
            return rejectWithValue(err);
        });
});
