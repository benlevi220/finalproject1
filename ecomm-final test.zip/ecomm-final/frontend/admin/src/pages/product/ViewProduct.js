import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

import { Grid } from '@mui/material';
import { Box } from '@mui/material';
import { Typography } from '@mui/material';

import ChipLabel from 'components/ChipLabel';
import MainCard from 'components/MainCard';
import Loader from 'components/Loader';
import ProdImagesSlider from './ProductCarousel';

import { getAllProductById } from 'api/product';

const ViewProduct = () => {
    const navigate = useNavigate();
    const { id } = useParams();

    const [product, setProduct] = useState(null);
    const [loading, setLoading] = useState(true);

    const { products } = useSelector((st) => st.product);

    useEffect(() => {
        if (products) {
            setProduct(products.filter((el) => el.id === +id)[0]);
            setLoading(false);
        } else {
            getAllProductById(+id)
                .then((res) => {
                    setProduct(res.data);
                    setLoading(false);
                })
                .catch((er) => {
                    toast.error(`Could not fetch product ${er.message}`);
                    navigate('/products');
                });
        }
    }, [id]);

    if (loading) return <Loader />;

    return (
        <MainCard sx={{ mt: 2, padding: '30px' }} content={false}>
            <Grid container spacing={5}>
                <Grid item xs={12} sm={6}>
                    <ProdImagesSlider prodImages={product.pictures} />
                </Grid>
                <Grid item xs={12} sm={6}>
                    <Box height="100%" py={1} display="flex" gap={3} flexDirection="column">
                        <ChipLabel
                            color={product.stock !== 0 ? 'success' : 'error'}
                            sx={{ fontSize: '1rem', padding: '0.75rem !important', width: 'fit-content' }}
                        >
                            {product.stock !== 0 ? 'In Stock' : 'Out Of Stock'}
                        </ChipLabel>
                        <Typography variant="h4" sx={{ textTransform: 'uppercase' }}>
                            {product.label}
                        </Typography>
                        <Box display="flex" gap={2}>
                            <Typography variant="h3">${product.details.offered_price}</Typography>
                            <Typography variant="h3" color="secondary" sx={{ textDecoration: 'line-through' }}>
                                ${product.details.price}
                            </Typography>
                        </Box>

                        <Box display="flex" flexDirection="column" gap={0.5} width="100%" maxWidth="270px" mb={1}>
                            <Typography variant="h5">Product Description</Typography>
                            <Typography variant="body1">{product.description}</Typography>
                        </Box>
                        <Box display="flex" flexDirection="column" gap={0.5} width="100%" maxWidth="270px">
                            <Typography variant="h5">Details</Typography>
                            <Box display="flex" gap={2} justifyContent="space-between">
                                <Typography variant="body1">Condition</Typography>
                                <Typography variant="body1">{product.details.condition}</Typography>
                            </Box>
                            <Box display="flex" gap={2} justifyContent="space-between">
                                <Typography variant="body1">Size</Typography>
                                {product.sizes.map((ele, ind) => (
                                    <React.Fragment key={ele.id}>
                                        <Typography variant="body1">
                                            {ele.label}
                                            {ind < product.sizes.length - 1 && ', '}
                                        </Typography>
                                    </React.Fragment>
                                ))}
                            </Box>
                            <Box display="flex" gap={2} justifyContent="space-between">
                                <Typography variant="body1">Colors</Typography>
                                {product.colours.map((ele, ind) => (
                                    <React.Fragment key={ele.id}>
                                        <Typography variant="body1">
                                            {ele.label}
                                            {ind < product.colours.length - 1 && ', '}
                                        </Typography>
                                    </React.Fragment>
                                ))}
                            </Box>
                            <Box display="flex" gap={2} justifyContent="space-between">
                                <Typography variant="body1">Style</Typography>
                                <Typography variant="body1">{product.details.style}</Typography>
                            </Box>
                        </Box>
                    </Box>
                </Grid>
            </Grid>
        </MainCard>
    );
};

export default ViewProduct;
