import { faker } from '@faker-js/faker';

export const Comments = [...Array(6)].map((_, index) => ({
    _id: faker.datatype.uuid(),
    user: { name: faker.name.fullName(), image: 'https://www.dropbox.com/s/iv3vsr5k6ib2pqx/avatar_default.jpg?dl=1' },
    description: faker.lorem.paragraph(4),
    date: faker.date.recent(10),
    rating: faker.datatype.number({
        min: 1,
        max: 5
    })
}));

export const Products = [
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Nike Air Force 1 NDESTRUKT',
        code: '38BEE270',
        sku: 'WW75K5210YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 16.19,
        priceSale: 16.19,
        totalRating: 2.5,
        totalReview: 9042,
        ratings: [
            {
                name: '1 Star',
                starCount: 7460,
                reviewCount: 461
            },
            {
                name: '2 Star',
                starCount: 4624,
                reviewCount: 1174
            },
            {
                name: '3 Star',
                starCount: 456,
                reviewCount: 8168
            },
            {
                name: '4 Star',
                starCount: 8498,
                reviewCount: 3604
            },
            {
                name: '5 Star',
                starCount: 570,
                reviewCount: 5164
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 4972,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 3612,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 2925,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 3540,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 3833,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 6698,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 5215,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 5781,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'out_of_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 29,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 121,
        createdAt: '2023-03-02T18:32:55.718Z',
        category: 'Apparel',
        gender: 'Kids',
        colors: ['#00AB55', '#000000']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Foundations Matte Flip Flop',
        code: '38BEE271',
        sku: 'WW75K5211YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 35.71,
        priceSale: null,
        totalRating: 2,
        totalReview: 4273,
        ratings: [
            {
                name: '1 Star',
                starCount: 5472,
                reviewCount: 5255
            },
            {
                name: '2 Star',
                starCount: 9844,
                reviewCount: 667
            },
            {
                name: '3 Star',
                starCount: 6607,
                reviewCount: 3179
            },
            {
                name: '4 Star',
                starCount: 2454,
                reviewCount: 564
            },
            {
                name: '5 Star',
                starCount: 6183,
                reviewCount: 8773
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 4816,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 9568,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 9883,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 747,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 4475,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 7030,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 7031,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 3570,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'out_of_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 585,
        createdAt: '2023-03-01T17:32:55.718Z',
        category: 'Accessories',
        gender: 'Kids',
        colors: ['#000000', '#FFFFFF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Nike Air Zoom Pegasus 37 A.I.R. Chaz Bear',
        code: '38BEE272',
        sku: 'WW75K5212YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 34.3,
        priceSale: null,
        totalRating: 4.9,
        totalReview: 1321,
        ratings: [
            {
                name: '1 Star',
                starCount: 3209,
                reviewCount: 6760
            },
            {
                name: '2 Star',
                starCount: 5272,
                reviewCount: 2307
            },
            {
                name: '3 Star',
                starCount: 544,
                reviewCount: 4275
            },
            {
                name: '4 Star',
                starCount: 2688,
                reviewCount: 9559
            },
            {
                name: '5 Star',
                starCount: 1191,
                reviewCount: 89
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 5829,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 8096,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 8283,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 7555,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 8383,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 6360,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 8560,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 1431,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'low_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 132,
        createdAt: '2023-02-28T16:32:55.718Z',
        category: 'Apparel',
        gender: 'Men',
        colors: ['#FFFFFF', '#FFC0CB']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Arizona Soft Footbed Sandal',
        code: '38BEE273',
        sku: 'WW75K5213YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 93.1,
        priceSale: 93.1,
        totalRating: 2,
        totalReview: 1123,
        ratings: [
            {
                name: '1 Star',
                starCount: 5496,
                reviewCount: 7988
            },
            {
                name: '2 Star',
                starCount: 6037,
                reviewCount: 585
            },
            {
                name: '3 Star',
                starCount: 4816,
                reviewCount: 9789
            },
            {
                name: '4 Star',
                starCount: 5386,
                reviewCount: 5219
            },
            {
                name: '5 Star',
                starCount: 1302,
                reviewCount: 8278
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 8141,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 4328,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 1921,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 7520,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 9986,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 1122,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 2243,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 1929,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 97,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 412,
        createdAt: '2023-02-27T15:32:55.718Z',
        category: 'Apparel',
        gender: 'Women',
        colors: ['#FFC0CB', '#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Boston Soft Footbed Sandal',
        code: '38BEE274',
        sku: 'WW75K5214YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 55.47,
        priceSale: null,
        totalRating: 4,
        totalReview: 6217,
        ratings: [
            {
                name: '1 Star',
                starCount: 2647,
                reviewCount: 1649
            },
            {
                name: '2 Star',
                starCount: 9047,
                reviewCount: 8932
            },
            {
                name: '3 Star',
                starCount: 2248,
                reviewCount: 4825
            },
            {
                name: '4 Star',
                starCount: 3808,
                reviewCount: 4071
            },
            {
                name: '5 Star',
                starCount: 760,
                reviewCount: 4465
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 2808,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 8652,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 95,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 9108,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 3082,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 9352,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 7611,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 5420,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'low_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 98,
        createdAt: '2023-02-26T14:32:55.718Z',
        category: 'Accessories',
        gender: 'Men',
        colors: ['#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Zoom Freak 2',
        code: '38BEE275',
        sku: 'WW75K5215YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 89.09,
        priceSale: null,
        totalRating: 5,
        totalReview: 5887,
        ratings: [
            {
                name: '1 Star',
                starCount: 6996,
                reviewCount: 199
            },
            {
                name: '2 Star',
                starCount: 1466,
                reviewCount: 3305
            },
            {
                name: '3 Star',
                starCount: 6160,
                reviewCount: 1239
            },
            {
                name: '4 Star',
                starCount: 1452,
                reviewCount: 8692
            },
            {
                name: '5 Star',
                starCount: 1582,
                reviewCount: 4978
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 9555,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 6645,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 1904,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 6575,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 2909,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 7879,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 3429,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 2884,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'out_of_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 419,
        createdAt: '2023-02-25T13:32:55.718Z',
        category: 'Shose',
        gender: 'Women',
        colors: ['#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Gazelle Vintage low-top sneakers',
        code: '38BEE276',
        sku: 'WW75K5216YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 44.39,
        priceSale: 44.39,
        totalRating: 4.9,
        totalReview: 2952,
        ratings: [
            {
                name: '1 Star',
                starCount: 831,
                reviewCount: 3885
            },
            {
                name: '2 Star',
                starCount: 6132,
                reviewCount: 794
            },
            {
                name: '3 Star',
                starCount: 8217,
                reviewCount: 5362
            },
            {
                name: '4 Star',
                starCount: 2879,
                reviewCount: 7312
            },
            {
                name: '5 Star',
                starCount: 9780,
                reviewCount: 7962
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 7140,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 3391,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 5700,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 8805,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 5051,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 9008,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 9098,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 5521,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'low_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 21,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 964,
        createdAt: '2023-02-24T12:32:55.718Z',
        category: 'Apparel',
        gender: 'Women',
        colors: ['#00AB55', '#000000']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Jordan Delta',
        code: '38BEE277',
        sku: 'WW75K5217YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 26.92,
        priceSale: null,
        totalRating: 5,
        totalReview: 5044,
        ratings: [
            {
                name: '1 Star',
                starCount: 1181,
                reviewCount: 9125
            },
            {
                name: '2 Star',
                starCount: 6773,
                reviewCount: 677
            },
            {
                name: '3 Star',
                starCount: 239,
                reviewCount: 6980
            },
            {
                name: '4 Star',
                starCount: 4397,
                reviewCount: 7547
            },
            {
                name: '5 Star',
                starCount: 830,
                reviewCount: 1182
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 7815,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 2809,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 527,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 2106,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 3402,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 7987,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 7039,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 3673,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'low_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 262,
        createdAt: '2023-02-23T11:32:55.718Z',
        category: 'Apparel',
        gender: 'Men',
        colors: ['#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b9',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_9.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Air Jordan XXXV PF',
        code: '38BEE278',
        sku: 'WW75K5218YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 45.35,
        priceSale: null,
        totalRating: 3.7,
        totalReview: 7849,
        ratings: [
            {
                name: '1 Star',
                starCount: 6141,
                reviewCount: 6627
            },
            {
                name: '2 Star',
                starCount: 5290,
                reviewCount: 585
            },
            {
                name: '3 Star',
                starCount: 441,
                reviewCount: 7743
            },
            {
                name: '4 Star',
                starCount: 3994,
                reviewCount: 9384
            },
            {
                name: '5 Star',
                starCount: 5781,
                reviewCount: 7975
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 8492,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 322,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 7796,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 9409,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 4945,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 3934,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 1470,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 36,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'out_of_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 811,
        createdAt: '2023-02-22T10:32:55.718Z',
        category: 'Accessories',
        gender: 'Men',
        colors: ['#FFFFFF', '#FFC0CB']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b10',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_10.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Rod Laver low-top sneakers',
        code: '38BEE279',
        sku: 'WW75K5219YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 26.96,
        priceSale: 26.96,
        totalRating: 2.5,
        totalReview: 8992,
        ratings: [
            {
                name: '1 Star',
                starCount: 2377,
                reviewCount: 6120
            },
            {
                name: '2 Star',
                starCount: 4495,
                reviewCount: 4389
            },
            {
                name: '3 Star',
                starCount: 5776,
                reviewCount: 8672
            },
            {
                name: '4 Star',
                starCount: 6827,
                reviewCount: 3527
            },
            {
                name: '5 Star',
                starCount: 3549,
                reviewCount: 5196
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 561,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 7640,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 5367,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 2908,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 5730,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 5598,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 6123,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 5538,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 65,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 535,
        createdAt: '2023-02-21T09:32:55.718Z',
        category: 'Apparel',
        gender: 'Women',
        colors: ['#FFFFFF', '#FFC0CB', '#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b11',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_11.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Kyrie 7 EP Sisterhood',
        code: '38BEE2710',
        sku: 'WW75K52110YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 78.22,
        priceSale: null,
        totalRating: 2,
        totalReview: 4351,
        ratings: [
            {
                name: '1 Star',
                starCount: 9291,
                reviewCount: 7764
            },
            {
                name: '2 Star',
                starCount: 6430,
                reviewCount: 7467
            },
            {
                name: '3 Star',
                starCount: 185,
                reviewCount: 9389
            },
            {
                name: '4 Star',
                starCount: 7967,
                reviewCount: 3314
            },
            {
                name: '5 Star',
                starCount: 3599,
                reviewCount: 6026
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 5181,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 7294,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 4952,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 5427,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 9540,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 1106,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 9931,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 7443,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'out_of_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 301,
        createdAt: '2023-02-20T08:32:55.718Z',
        category: 'Shose',
        gender: 'Women',
        colors: ['#FFC0CB', '#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b12',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_12.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Pharrell Williams Human Race NMD sneakers',
        code: '38BEE2711',
        sku: 'WW75K52111YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 35.54,
        priceSale: null,
        totalRating: 4.9,
        totalReview: 1044,
        ratings: [
            {
                name: '1 Star',
                starCount: 8587,
                reviewCount: 4293
            },
            {
                name: '2 Star',
                starCount: 1188,
                reviewCount: 378
            },
            {
                name: '3 Star',
                starCount: 9013,
                reviewCount: 6836
            },
            {
                name: '4 Star',
                starCount: 9455,
                reviewCount: 2124
            },
            {
                name: '5 Star',
                starCount: 5881,
                reviewCount: 3642
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 4766,
                postedAt: '2023-03-02T18:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 976,
                postedAt: '2023-03-01T17:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 3380,
                postedAt: '2023-02-28T16:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 1272,
                postedAt: '2023-02-27T15:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 9295,
                postedAt: '2023-02-26T14:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 4562,
                postedAt: '2023-02-25T13:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 7639,
                postedAt: '2023-02-24T12:32:55.718Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 1253,
                postedAt: '2023-02-23T11:32:55.718Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 693,
        createdAt: '2023-02-19T07:32:55.719Z',
        category: 'Shose',
        gender: 'Men',
        colors: ['#FFFFFF', '#FFC0CB', '#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b13',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_13.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Nike Blazer Low 77 Vintage',
        code: '38BEE2712',
        sku: 'WW75K52112YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 90.69,
        priceSale: 90.69,
        totalRating: 4.8,
        totalReview: 9218,
        ratings: [
            {
                name: '1 Star',
                starCount: 127,
                reviewCount: 3338
            },
            {
                name: '2 Star',
                starCount: 8089,
                reviewCount: 5422
            },
            {
                name: '3 Star',
                starCount: 5399,
                reviewCount: 5634
            },
            {
                name: '4 Star',
                starCount: 9735,
                reviewCount: 9801
            },
            {
                name: '5 Star',
                starCount: 4483,
                reviewCount: 7967
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 8809,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 7037,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 8877,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 5920,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 8628,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 7749,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 1549,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 5181,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 79,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 90,
        createdAt: '2023-02-18T06:32:55.719Z',
        category: 'Shose',
        gender: 'Kids',
        colors: ['#FFFFFF', '#FFC0CB', '#FF4842', '#1890FF', '#94D82D']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b14',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_14.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'ASMC Winter Boot Cold.Rdy',
        code: '38BEE2713',
        sku: 'WW75K52113YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 63.61,
        priceSale: null,
        totalRating: 4,
        totalReview: 653,
        ratings: [
            {
                name: '1 Star',
                starCount: 3174,
                reviewCount: 4729
            },
            {
                name: '2 Star',
                starCount: 1926,
                reviewCount: 5035
            },
            {
                name: '3 Star',
                starCount: 8886,
                reviewCount: 2432
            },
            {
                name: '4 Star',
                starCount: 8972,
                reviewCount: 8600
            },
            {
                name: '5 Star',
                starCount: 4440,
                reviewCount: 5649
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 4510,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 5106,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 885,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 1108,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 3184,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 8439,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 7748,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 175,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'low_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 946,
        createdAt: '2023-02-17T05:32:55.719Z',
        category: 'Accessories',
        gender: 'Kids',
        colors: ['#FF4842', '#1890FF', '#94D82D']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b15',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_15.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'ZX 8000 Lego sneakers',
        code: '38BEE2714',
        sku: 'WW75K52114YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 67.55,
        priceSale: null,
        totalRating: 2,
        totalReview: 5318,
        ratings: [
            {
                name: '1 Star',
                starCount: 8619,
                reviewCount: 9754
            },
            {
                name: '2 Star',
                starCount: 4344,
                reviewCount: 5738
            },
            {
                name: '3 Star',
                starCount: 546,
                reviewCount: 7466
            },
            {
                name: '4 Star',
                starCount: 3393,
                reviewCount: 3040
            },
            {
                name: '5 Star',
                starCount: 4508,
                reviewCount: 4364
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 7231,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 681,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 7606,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 2064,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 3603,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 7277,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 1620,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 7699,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 223,
        createdAt: '2023-02-16T04:32:55.719Z',
        category: 'Shose',
        gender: 'Kids',
        colors: ['#00AB55', '#000000']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b16',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_16.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Ultraboost 21 sneakers',
        code: '38BEE2715',
        sku: 'WW75K52115YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 94.75,
        priceSale: 94.75,
        totalRating: 3.7,
        totalReview: 9013,
        ratings: [
            {
                name: '1 Star',
                starCount: 768,
                reviewCount: 2208
            },
            {
                name: '2 Star',
                starCount: 7577,
                reviewCount: 8413
            },
            {
                name: '3 Star',
                starCount: 808,
                reviewCount: 9074
            },
            {
                name: '4 Star',
                starCount: 2440,
                reviewCount: 6181
            },
            {
                name: '5 Star',
                starCount: 7019,
                reviewCount: 205
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 3485,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 1750,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 5640,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 7744,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 1262,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 234,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 4458,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 7107,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'low_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 94,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 935,
        createdAt: '2023-02-15T03:32:55.719Z',
        category: 'Accessories',
        gender: 'Kids',
        colors: ['#1890FF', '#94D82D', '#FFC107']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b17',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_17.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: '2750 Cotu Classic Sneaker',
        code: '38BEE2716',
        sku: 'WW75K52116YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 75.78,
        priceSale: null,
        totalRating: 1.4,
        totalReview: 8435,
        ratings: [
            {
                name: '1 Star',
                starCount: 7259,
                reviewCount: 417
            },
            {
                name: '2 Star',
                starCount: 1928,
                reviewCount: 9129
            },
            {
                name: '3 Star',
                starCount: 1868,
                reviewCount: 6869
            },
            {
                name: '4 Star',
                starCount: 8020,
                reviewCount: 8827
            },
            {
                name: '5 Star',
                starCount: 4205,
                reviewCount: 2859
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 5560,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 6339,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 8445,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 3295,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 4108,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 7291,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 6261,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 4094,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'out_of_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 224,
        createdAt: '2023-02-14T02:32:55.719Z',
        category: 'Apparel',
        gender: 'Men',
        colors: ['#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b18',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_18.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'ZX 9000 A-ZX Series sneakers',
        code: '38BEE2717',
        sku: 'WW75K52117YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 39.6,
        priceSale: null,
        totalRating: 2.4,
        totalReview: 4697,
        ratings: [
            {
                name: '1 Star',
                starCount: 2904,
                reviewCount: 1812
            },
            {
                name: '2 Star',
                starCount: 8513,
                reviewCount: 8202
            },
            {
                name: '3 Star',
                starCount: 4397,
                reviewCount: 2802
            },
            {
                name: '4 Star',
                starCount: 7076,
                reviewCount: 6763
            },
            {
                name: '5 Star',
                starCount: 4756,
                reviewCount: 6026
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 1621,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 1258,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 4871,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 6639,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 4348,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 2583,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 4749,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 3597,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 506,
        createdAt: '2023-02-13T01:32:55.719Z',
        category: 'Apparel',
        gender: 'Women',
        colors: ['#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b19',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_19.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Madrid Big Buckle Sandal',
        code: '38BEE2718',
        sku: 'WW75K52118YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 52.84,
        priceSale: 52.84,
        totalRating: 1.8,
        totalReview: 3874,
        ratings: [
            {
                name: '1 Star',
                starCount: 3866,
                reviewCount: 2146
            },
            {
                name: '2 Star',
                starCount: 3291,
                reviewCount: 8536
            },
            {
                name: '3 Star',
                starCount: 8162,
                reviewCount: 8497
            },
            {
                name: '4 Star',
                starCount: 4885,
                reviewCount: 9087
            },
            {
                name: '5 Star',
                starCount: 8100,
                reviewCount: 3891
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 3444,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 7116,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 6645,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 1921,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 8721,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 5933,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 4780,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 7723,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 59,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 505,
        createdAt: '2023-02-12T00:32:55.719Z',
        category: 'Apparel',
        gender: 'Women',
        colors: ['#00AB55', '#000000']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b20',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_20.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Chuck 70 Hi Sneaker',
        code: '38BEE2719',
        sku: 'WW75K52119YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 72.8,
        priceSale: null,
        totalRating: 5,
        totalReview: 891,
        ratings: [
            {
                name: '1 Star',
                starCount: 7691,
                reviewCount: 3160
            },
            {
                name: '2 Star',
                starCount: 9252,
                reviewCount: 3485
            },
            {
                name: '3 Star',
                starCount: 9377,
                reviewCount: 585
            },
            {
                name: '4 Star',
                starCount: 1838,
                reviewCount: 7743
            },
            {
                name: '5 Star',
                starCount: 3806,
                reviewCount: 181
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 9123,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 6408,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 4345,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 3091,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 907,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 1750,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 3437,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 5763,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'out_of_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 873,
        createdAt: '2023-02-10T23:32:55.719Z',
        category: 'Accessories',
        gender: 'Men',
        colors: ['#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b21',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_21.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Relaxed Adjustable Strap Slingback Sandal',
        code: '38BEE2720',
        sku: 'WW75K52120YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 83.08,
        priceSale: null,
        totalRating: 2.9,
        totalReview: 9482,
        ratings: [
            {
                name: '1 Star',
                starCount: 3926,
                reviewCount: 9190
            },
            {
                name: '2 Star',
                starCount: 6681,
                reviewCount: 2280
            },
            {
                name: '3 Star',
                starCount: 997,
                reviewCount: 6138
            },
            {
                name: '4 Star',
                starCount: 1864,
                reviewCount: 35
            },
            {
                name: '5 Star',
                starCount: 7598,
                reviewCount: 1250
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 5641,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 5932,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 83,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 1219,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 5761,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 2834,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 2112,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 7822,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 379,
        createdAt: '2023-02-09T22:32:55.719Z',
        category: 'Accessories',
        gender: 'Men',
        colors: ['#FF4842', '#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b22',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_22.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Superturf Adventure X Atmos',
        code: '38BEE2721',
        sku: 'WW75K52121YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 85.02,
        priceSale: 85.02,
        totalRating: 3.9,
        totalReview: 931,
        ratings: [
            {
                name: '1 Star',
                starCount: 7373,
                reviewCount: 260
            },
            {
                name: '2 Star',
                starCount: 2442,
                reviewCount: 665
            },
            {
                name: '3 Star',
                starCount: 8002,
                reviewCount: 4912
            },
            {
                name: '4 Star',
                starCount: 1514,
                reviewCount: 8062
            },
            {
                name: '5 Star',
                starCount: 9300,
                reviewCount: 1405
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 9434,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 9090,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 9657,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 9947,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 7140,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 1691,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 1318,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 2432,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 28,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 220,
        createdAt: '2023-02-08T21:32:55.719Z',
        category: 'Accessories',
        gender: 'Women',
        colors: ['#1890FF']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b23',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_23.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Chuck Taylor All Star Lift Sneaker',
        code: '38BEE2722',
        sku: 'WW75K52122YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 69.22,
        priceSale: null,
        totalRating: 3.9,
        totalReview: 8928,
        ratings: [
            {
                name: '1 Star',
                starCount: 4134,
                reviewCount: 632
            },
            {
                name: '2 Star',
                starCount: 4161,
                reviewCount: 7799
            },
            {
                name: '3 Star',
                starCount: 4201,
                reviewCount: 7768
            },
            {
                name: '4 Star',
                starCount: 4098,
                reviewCount: 954
            },
            {
                name: '5 Star',
                starCount: 5743,
                reviewCount: 8379
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 86,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 9196,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 8527,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 7212,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 9812,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 8175,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 5409,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 5546,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'in_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 381,
        createdAt: '2023-02-07T20:32:55.719Z',
        category: 'Apparel',
        gender: 'Kids',
        colors: ['#1890FF', '#94D82D', '#FFC107']
    },
    {
        id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b24',
        cover: 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_24.jpg',
        images: [
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_3.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_4.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_5.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_6.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_7.jpg',
            'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_8.jpg'
        ],
        name: 'Run Star Hike Platform Sneaker',
        code: '38BEE2723',
        sku: 'WW75K52123YW/SV',
        tags: ['Dangal', 'The Sting', '2001: A Space Odyssey', "Singin' in the Rain"],
        price: 60.96,
        priceSale: null,
        totalRating: 1.8,
        totalReview: 4462,
        ratings: [
            {
                name: '1 Star',
                starCount: 1050,
                reviewCount: 2130
            },
            {
                name: '2 Star',
                starCount: 8777,
                reviewCount: 5710
            },
            {
                name: '3 Star',
                starCount: 3,
                reviewCount: 5013
            },
            {
                name: '4 Star',
                starCount: 3278,
                reviewCount: 6785
            },
            {
                name: '5 Star',
                starCount: 8933,
                reviewCount: 8995
            }
        ],
        reviews: [
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b1',
                name: 'Jayvion Simon',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_1.jpg',
                comment: 'Assumenda nam repudiandae rerum fugiat vel maxime.',
                rating: 2.5,
                isPurchased: true,
                helpful: 1922,
                postedAt: '2023-03-02T18:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b2',
                name: 'Lucian Obrien',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_2.jpg',
                comment: 'Quis veniam aut saepe aliquid nulla.',
                rating: 2,
                isPurchased: true,
                helpful: 7293,
                postedAt: '2023-03-01T17:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b3',
                name: 'Deja Brady',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_3.jpg',
                comment: 'Reprehenderit ut voluptas sapiente ratione nostrum est.',
                rating: 4.9,
                isPurchased: true,
                helpful: 609,
                postedAt: '2023-02-28T16:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b4',
                name: 'Harrison Stein',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_4.jpg',
                comment: 'Error ut sit vel molestias velit.',
                rating: 2,
                isPurchased: false,
                helpful: 1223,
                postedAt: '2023-02-27T15:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b5',
                name: 'Reece Chung',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_5.jpg',
                comment: 'Quo quia sit nihil nemo doloremque et.',
                rating: 4,
                isPurchased: false,
                helpful: 4300,
                postedAt: '2023-02-26T14:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b6',
                name: 'Lainey Davidson',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_6.jpg',
                comment: 'Autem doloribus harum vero laborum.',
                rating: 5,
                isPurchased: true,
                helpful: 3835,
                postedAt: '2023-02-25T13:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b7',
                name: 'Cristopher Cardenas',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_7.jpg',
                comment: 'Tempora officiis consequuntur architecto nostrum autem nam adipisci.',
                rating: 4.9,
                isPurchased: false,
                helpful: 8573,
                postedAt: '2023-02-24T12:32:55.719Z'
            },
            {
                id: 'e99f09a7-dd88-49d5-b1c8-1daf80c2d7b8',
                name: 'Melanie Noble',
                avatarUrl: 'https://api-prod-minimal-v4.vercel.app/assets/images/avatars/avatar_8.jpg',
                comment: 'Voluptas sunt magni adipisci praesentium saepe.',
                rating: 5,
                isPurchased: false,
                helpful: 6445,
                postedAt: '2023-02-23T11:32:55.719Z'
            }
        ],
        vendor: 'Abraham Group Pvt Ltd',
        inventoryType: 'low_stock',
        sizes: ['6', '7', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '13'],
        available: 2,
        description:
            '\n<p><strong><small> SPECIFICATION</small></strong></p>\n<p>Leather panels. Laces. Rounded toe. Rubber sole.\n<br /><br />\n<p><strong><small> MATERIAL AND WASHING INSTRUCTIONS</small></strong></p>\n<p>Shoeupper: 54% bovine leather,46% polyurethane. Lining: 65% polyester,35% cotton. Insole: 100% polyurethane. Sole: 100% thermoplastic. Fixing sole: 100% glued.</p>\n',
        sold: 454,
        createdAt: '2023-02-06T19:32:55.719Z',
        category: 'Accessories',
        gender: 'Men',
        colors: ['#FF4842', '#1890FF']
    }
];
