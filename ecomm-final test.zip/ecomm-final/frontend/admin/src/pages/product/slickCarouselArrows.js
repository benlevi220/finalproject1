import { Box } from '@mui/material';
import { Icon } from '@iconify/react';

import chevronLeft from '@iconify/icons-mdi/chevron-left';
import chevronRight from '@iconify/icons-mdi/chevron-right';

const common = {
    background: (theme) => `${theme.palette.secondary.main} !important`,
    borderRadius: '50%',
    zIndex: 22,
    display: 'flex !important',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 2,
    width: '35px !important',
    height: '35px !important',

    '&:before': {
        display: 'none'
    },
    '& svg': {
        color: '#fff'
    }
};

export const SampleNextArrow = (props) => {
    const { className, onClick } = props;
    return (
        <Box
            className={className}
            sx={{
                ...common,
                right: props?.right || '1% !important'
            }}
            onClick={onClick}
        >
            <Icon icon={chevronRight} width={25} height={25} />
        </Box>
    );
};

export const SamplePrevArrow = (props) => {
    const { className, onClick } = props;
    return (
        <Box
            className={className}
            sx={{
                ...common,
                left: props?.left || '1% !important'
            }}
            onClick={onClick}
        >
            <Icon icon={chevronLeft} width={25} height={25} />
        </Box>
    );
};
