import { Box, Button, CircularProgress, TextField } from '@mui/material';
import FormField from 'components/FormField';
import MainCard from 'components/MainCard';
import { useFormik } from 'formik';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom/dist';
import * as yup from 'yup';

const CreateProd = () => {
    const { loading } = useSelector((st) => st.product);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const initialValues = {
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        phone: ''
    };

    const validationSchema = yup.object({
        email: yup.string().email().required('enter email'),
        firstName: yup.string().required('ewnter first').min(3),
        lastName: yup.string().required('enter last name').min(3),
        password: yup.string().required('Enter password').min(8, 'Password atleast 8 characters long')
    });

    const formik = useFormik({
        initialValues,
        validationSchema,
        validateOnBlur: false,
        validateOnChange: true,
        onSubmit: (values) => {}
        // dispatch(addUser(values)).then((res) => {
        //     if (res.meta.requestStatus === 'fulfilled') navigate('/users');
        // })
    });

    return (
        <Box display="flex" gap={1} flexDirection="column">
            <MainCard sx={{ mt: 2, padding: '30px' }} content={false}>
                <form id="create" onSubmit={formik.handleSubmit}>
                    <Box display="grid" gridTemplateColumns="repeat(2,1fr)" gap={2} width="100%">
                        <FormField title="Product Name">
                            <TextField
                                name="name"
                                value={formik.values.name}
                                onChange={formik.handleChange}
                                error={formik.touched.name && Boolean(formik.errors.name)}
                                helperText={formik.touched.name && formik.errors.name}
                                placeholder="Enter Product Name here"
                                variant="outlined"
                                size="medium"
                                className="textField"
                            />
                        </FormField>
                        <FormField title="Product Price">
                            <TextField
                                name="price"
                                value={formik.values.price}
                                onChange={formik.handleChange}
                                error={formik.touched.price && Boolean(formik.errors.price)}
                                helperText={formik.touched.price && formik.errors.price}
                                placeholder="Enter Product Price Here"
                                variant="outlined"
                                color="secondary"
                                className="textField"
                                size="medium"
                                type="number"
                            />
                        </FormField>
                        <FormField title="Product Description">
                            <TextField
                                name="description"
                                value={formik.values.description}
                                onChange={formik.handleChange}
                                error={formik.touched.description && Boolean(formik.errors.description)}
                                helperText={formik.touched.description && formik.errors.description}
                                placeholder="Enter Product Description Here"
                                variant="outlined"
                                color="secondary"
                                className="textField"
                                size="medium"
                                multiline
                                rows={3}
                            />
                        </FormField>
                        <FormField title="Quantity.">
                            <TextField
                                name="inventory"
                                value={formik.values.inventory}
                                onChange={formik.handleChange}
                                error={formik.touched.inventory && Boolean(formik.errors.inventory)}
                                helperText={formik.touched.inventory && formik.errors.inventory}
                                placeholder="Enter Product Stock Quantity"
                                variant="outlined"
                                size="medium"
                                className="textField"
                                type="number"
                            />
                        </FormField>
                    </Box>
                    <Box width="100%" mt={3}>
                        <Button
                            variant="contained"
                            sx={{ textTransform: 'capitalize', marginRight: '0.5rem' }}
                            color="secondary"
                            type="submit"
                            onClick={() => navigate('/users')}
                        >
                            Cancel
                        </Button>
                        <Button variant="contained" sx={{ textTransform: 'capitalize' }} type="submit">
                            {loading ? <CircularProgress size="1.5rem" color="secondary" /> : 'Create'}
                        </Button>
                    </Box>
                </form>
            </MainCard>
        </Box>
    );
};

export default CreateProd;
