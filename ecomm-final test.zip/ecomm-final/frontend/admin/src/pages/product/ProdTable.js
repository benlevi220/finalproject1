import { Icon } from '@iconify/react';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import {
    Avatar,
    Box,
    Button,
    IconButton,
    Skeleton,
    Table,
    TableBody,
    TableCell,
    TablePagination,
    TableRow,
    Typography
} from '@mui/material';

import ChipLabel from 'components/ChipLabel';
import NoData from 'components/NoData';
import TableContainer from 'components/table/TableContainer';
import TableHead from 'components/table/TableHead';
import TablePaginationActions from 'components/table/TablePagination';

import { remoteUrl } from 'api';

import ProductFormDialog from 'dialogs/ProductForm';
import Search from 'layout/MainLayout/Header/HeaderContent/Search';
import { useDispatch, useSelector } from 'react-redux';
import { deleteProduct, getProducts } from 'store/reducers/product/extraReducers';
import { getFormatDate } from 'utils/misc';

import deleteOutline from '@iconify/icons-mdi/delete-outline';
import pencilOutline from '@iconify/icons-mdi/pencil-outline';
import ActionConfirmation from 'dialogs/ActionConfrmation';

function getChipColor(stock) {
    if (stock === 0) return 'error';
    else return 'success';
}

const headCells = [
    {
        id: 'cover',
        align: 'left',
        disablePadding: false,
        label: 'Image'
    },
    {
        id: 'name',
        align: 'left',
        disablePadding: true,
        label: 'Name'
    },
    {
        id: 'description',
        align: 'left',
        disablePadding: true,
        label: 'Description'
    },
    {
        id: 'inventory',
        align: 'center',
        disablePadding: false,
        label: 'Inventory'
    },
    {
        id: 'status',
        align: 'center',
        disablePadding: false,
        label: 'Stock Status'
    },
    {
        id: 'price',
        align: 'right',
        disablePadding: false,
        label: 'Price'
    },
    {
        id: 'createdAt',
        align: 'center',
        disablePadding: false,
        label: 'Created At'
    },
    {
        id: 'actions',
        align: 'center',
        disablePadding: false,
        label: ''
    }
];

const ProductForm = () => {
    const [open, setOpen] = useState(false);
    return (
        <>
            <Button variant="contained" sx={{ textTransform: 'capitalize' }} onClick={() => setOpen(true)}>
                Add New
            </Button>
            {open && <ProductFormDialog slug="Creating" open={open} handleClose={() => setOpen(false)} />}
        </>
    );
};

export default function ProdTable() {
    const [page, setPage] = React.useState(0);
    const [rowsPerPage] = React.useState(10);

    const [filter, setFilter] = useState('');
    const { products, loading, fetching } = useSelector((st) => st.product);

    const dispatch = useDispatch();

    useEffect(() => {
        if (fetching) dispatch(getProducts());
    }, [fetching, dispatch]);

    const handleChange = (e) => setFilter(e.target.value);

    let filterProd =
        filter !== '' && products?.length > 0 && !fetching
            ? products.filter((el) => el.name.toLowerCase().indexOf(filter.toLowerCase()) !== -1)
            : products;

    const handleChangePage = (_, newPage) => setPage(newPage);

    return (
        <>
            <Box sx={{ display: 'flex', gap: '1rem', justifyContent: 'space-between', paddingInline: '16px', paddingBlock: '20px' }}>
                <Search handleChange={handleChange} />
                <ProductForm />
            </Box>
            <TableContainer>
                <Table
                    aria-labelledby="tableTitle"
                    sx={{
                        '& .MuiTableCell-root:first-of-type': {
                            pl: 2
                        },
                        '& .MuiTableCell-root:last-of-type': {
                            pr: 3
                        }
                    }}
                >
                    <TableHead headCells={headCells} />
                    <TableBody>
                        {loading ? (
                            Array(9)
                                .fill()
                                .map((_, idx) => (
                                    <TableRow key={idx}>
                                        {Array(7)
                                            .fill()
                                            .map((_, idx) => (
                                                <TableCell key={idx * 2}>
                                                    <Skeleton />
                                                </TableCell>
                                            ))}
                                    </TableRow>
                                ))
                        ) : filterProd?.length > 0 ? (
                            filterProd.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => {
                                const labelId = `enhanced-table-checkbox-${index}`;
                                return (
                                    <TableRow
                                        hover
                                        role="checkbox"
                                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                        tabIndex={-1}
                                        key={row.id}
                                    >
                                        <TableCell component="th" id={labelId} scope="row" align="left">
                                            <Avatar
                                                src={`${remoteUrl}${row.images[0]}`}
                                                sx={{ width: '40px', height: '40px', '& img': { objectFit: 'contain' } }}
                                                variant="rounded"
                                            />
                                        </TableCell>
                                        <TableCell align="left">{row.name}</TableCell>
                                        <TableCell align="left">
                                            <p
                                                style={{
                                                    display: '-webkit-box',
                                                    maxWidth: 500,
                                                    WebkitLineClamp: 3,
                                                    WebkitBoxOrient: 'vertical',
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis'
                                                }}
                                            >
                                                {row.description}
                                            </p>
                                        </TableCell>
                                        <TableCell align="right">{row.inventory}</TableCell>
                                        <TableCell align="center">
                                            <ChipLabel color={getChipColor(row.quantity)}>
                                                {row.quantity === 0 ? 'Out Of Stock' : 'In Stock'}
                                            </ChipLabel>
                                        </TableCell>
                                        <TableCell align="right" sx={{ fontWeight: 600 }}>
                                            ${row.price}
                                        </TableCell>
                                        <TableCell align="right" sx={{ fontWeight: 600 }}>
                                            {getFormatDate(row.createdAt)}
                                        </TableCell>
                                        <TableCell align="right">
                                            <ProdModifyMenu row={row} />
                                            {/* <IconButton
                                                sx={{ borderRadius: '50%' }}
                                                color="primary"
                                                onClick={() => navigate(`/products/${row.id}`)}
                                            >
                                                <Icon icon={eyeOutline} width="24px" height="24px" />
                                            </IconButton> */}
                                        </TableCell>
                                    </TableRow>
                                );
                            })
                        ) : (
                            <TableRow>
                                <TableCell align="center" colSpan={7}>
                                    <NoData />
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
                <TablePagination
                    labelDisplayedRows={({ page }) => {
                        return (
                            <Typography variant="subtitle2" component="span">
                                Page {page + 1} of {Math.ceil(products?.length / rowsPerPage) || 1}
                            </Typography>
                        );
                    }}
                    count={products?.length || 0}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    labelRowsPerPage={''}
                    rowsPerPageOptions={-1}
                    ActionsComponent={TablePaginationActions}
                    SelectProps={{
                        inputProps: {
                            'aria-label': 'rows per page'
                        },
                        native: false
                    }}
                />
            </TableContainer>
        </>
    );
}

const ProdModifyMenu = ({ row }) => {
    const [openDialog, setOpenDialog] = useState({
        editDialog: false,
        deleteDialog: false
    });

    const [selected, setSelected] = useState();
    const dispatch = useDispatch();

    const { loading } = useSelector((st) => st.product);

    const handleDelete = (e) => {
        const { id } = e.currentTarget.dataset;
        setOpenDialog((st) => ({ ...st, deleteDialog: true }));
        setSelected(id);
    };

    const confirmDelete = () => dispatch(deleteProduct(selected)).then(() => setOpenDialog((st) => ({ ...st, deleteDialog: false })));

    const closeDialog = (dia) =>
        setOpenDialog((st) =>
            dia === 'edit'
                ? {
                      ...st,
                      editDialog: false
                  }
                : {
                      ...st,
                      deleteDialog: false
                  }
        );

    return (
        <>
            <IconButton
                sx={{ borderRadius: '50%' }}
                color="warning"
                onClick={() => {
                    setSelected(row);
                    setOpenDialog((st) => ({ ...st, editDialog: true }));
                }}
            >
                <Icon icon={pencilOutline} width="24px" height="24px" color="inherit" />
            </IconButton>
            <IconButton sx={{ borderRadius: '50%' }} color="error" onClick={handleDelete} data-id={row.id}>
                <Icon icon={deleteOutline} width="24px" height="24px" color="inherit" />
            </IconButton>
            {openDialog.editDialog && (
                <ProductFormDialog open={openDialog.editDialog} handleClose={closeDialog} update={true} slug="Editing" product={selected} />
            )}
            {openDialog.deleteDialog && (
                <ActionConfirmation open={openDialog.deleteDialog} handleClose={closeDialog} submit={confirmDelete} loading={loading} />
            )}
        </>
    );
};
