import React from 'react';

import { useSearchParams } from '../../../node_modules/react-router-dom/dist/index';
import { Box } from '../../../node_modules/@mui/material/index';

const QueryFilter = () => {
    const [searchParams, setSearchParams] = useSearchParams();
    const filteredQueryParams = Object.fromEntries(searchParams.entries());


    return (
        <Box display="flex" gap={1} alignItems="center" flexWrap="wrap">
            {/* {Object.keys(filteredQueryParams)
        .map((param) =>{
 <Button
     key={`${param}-${value}`}
     sx={{
         py: 0.5,
         px: 2,
         //   marginBottom: '2%',
         border: '1px solid #000',
         borderRadius: '20px'
     }}
    //  startIcon={<CloseIcon />}
    //  onClick={() => removeQueryParam(param, value)}
 >
     <Typography variant="body1">{value}</Typography>
 </Button>;
        })} */}
        </Box>
    );
};

export default QueryFilter;
