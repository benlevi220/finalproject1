import React from 'react';
import Slider from 'react-slick';

import { Card, CardMedia } from '@mui/material';

import { SampleNextArrow, SamplePrevArrow } from './slickCarouselArrows';

import { remoteUrl } from 'api';

const ProdImagesSlider = ({ prodImages }) => {
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />
    };
    return (
        <Slider {...settings}>
            {prodImages.map((el) => (
                <Card sx={{ borderRadius: 1, boxShadow: 'none' }}>
                    <CardMedia
                        key={el}
                        image={`${remoteUrl}${el}`}
                        data-image={`${remoteUrl}${el}`}
                        style={{ cursor: 'pointer', backgroundSize: 'contain', height: '400px', borderRadius: '15px' }}
                    />
                </Card>
            ))}
        </Slider>
    );
};

export default ProdImagesSlider;
