import React from 'react';

import MainCard from 'components/MainCard';
import ProdTable from './ProdTable';

const Product = () => {
    return (
        <MainCard sx={{ mt: 2 }} content={false}>
            <ProdTable />
        </MainCard>
    );
};

export default Product;
