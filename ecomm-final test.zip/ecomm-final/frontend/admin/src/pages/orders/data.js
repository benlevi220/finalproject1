import { faker } from '@faker-js/faker';

// Order No, Product, Buyer, Paid Amount, Order Date, Status

export const Orders = [...Array(25)].map((_, index) => ({
    _id: faker.datatype.uuid(),
    orderID: faker.datatype.number({
        min: 110000,
        max: 400000
    }),
    seller: { name: faker.name.fullName(), img: faker.image.people(40, 40) },
    buyer: { name: faker.name.fullName(), img: faker.image.people(40, 40) },
    product: faker.commerce.productName(),
    amount: faker.commerce.price(100, 600),
    purchasedOn: faker.date.recent(10),
    status: index % 2 !== 0 ? 'Delivered' : 'In Progress'
}));

export const OrderProdData = {
    _id: faker.datatype.uuid(),
    orderID: faker.datatype.number({
        min: 110000,
        max: 400000
    }),
    buyer: { name: 'John Doe', img: faker.image.people(40, 40), email: 'ab@mail.com' },
    products: [...Array(2)].map((el, ind) => ({
        _id: faker.datatype.uuid(),
        name: faker.commerce.productName(),
        image:
            ind === 0
                ? 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_1.jpg'
                : 'https://api-prod-minimal-v4.vercel.app/assets/images/products/product_2.jpg',
        rating: faker.datatype.number({
            min: 1,
            max: 5
        }),
        price: faker.commerce.price(100, 600),
        quantity: faker.datatype.number({
            min: 1,
            max: 4
        }),
        total:
            faker.commerce.price(100, 600) +
            faker.datatype.number({
                min: 1,
                max: 4
            })
    })),
    amount: faker.commerce.price(100, 600),
    purchasedOn: faker.date.recent(10),
    status: 'INPROGRESS',

    shippingDetails: {
        name: 'John Doe',
        phone: '+(256) 245451 451',
        email: 'ab@mail.com',
        address: '2186 Joyce Street Rocky Mount, California - 24567, United States'
    }
};
