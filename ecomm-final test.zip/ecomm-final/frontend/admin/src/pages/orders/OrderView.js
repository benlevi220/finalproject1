import React, { useEffect, useState } from 'react';

import {
    Avatar,
    Box,
    CircularProgress,
    Grid,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableFooter,
    TableHead,
    TableRow,
    Typography,
    styled
} from '@mui/material';
import { useParams } from 'react-router';

import { remoteUrl } from 'api';

import axiosInstance, { errorResponse } from 'api/index';
import ChipLabel from 'components/ChipLabel';
import MainCard from 'components/MainCard';
import { toast } from 'react-toastify';
import userImg from '../../assets/images/users/user.png';

const headCells = [
    {
        id: 'product',
        align: 'left',
        disablePadding: false,
        label: 'Product'
    },
    {
        id: 'price',
        align: 'right',
        disablePadding: false,
        label: 'Item Price'
    },
    {
        id: 'quantity',
        align: 'right',
        disablePadding: false,
        label: 'Quantity'
    },
    {
        id: 'total',
        align: 'right',
        disablePadding: false,
        label: 'Total Amount'
    }
];

const OrderView = () => {
    const [orderDetails, setOrderDetails] = useState(null);
    const [fetching, setFetching] = useState(true);

    const { id } = useParams();

    useEffect(() => {
        (async () => {
            axiosInstance
                .get(`/orders/${id}`)
                .then((res) => {
                    setOrderDetails(res.data.order);
                })
                .catch((er) => toast.error(errorResponse(er).message))
                .finally(() => setFetching(false));
        })();
    }, [id]);

    console.log('orderDetails', orderDetails);

    return (
        <MainCard sx={{ mt: 2, padding: '30px' }} content={false}>
            {fetching ? (
                <Stack width="100%" minHeight={'300px'}>
                    <CircularProgress size={20} />
                </Stack>
            ) : (
                <>
                    <Box display="flex" justifyContent="space-between">
                        <Typography variant="subtitle1">Order # {orderDetails?.id}</Typography>
                        <Box display="flex" gap={2} alignItems="center">
                            <Typography variant="subtitle1">{new Date(orderDetails?.createdAt).toLocaleString()}</Typography>
                            <ChipLabel color={orderDetails?.status === 'pending' ? 'error' : 'success'}>{orderDetails?.status}</ChipLabel>
                        </Box>
                    </Box>
                    <TableContainer
                        sx={{
                            overflowX: 'auto',
                            mt: 2,
                            '& td, & th': { whiteSpace: 'nowrap' },
                            border: (theme) => `1px solid ${theme.palette.divider}`,
                            borderRadius: '10px'
                        }}
                    >
                        <Table
                            aria-labelledby="tableTitle"
                            sx={{
                                '& .MuiTableCell-root:first-of-type': {
                                    pl: 2
                                },
                                '& .MuiTableCell-root:last-of-type': {
                                    pr: 3
                                }
                            }}
                        >
                            <TableHead sx={{ backgroundColor: (theme) => theme.palette.primary.lighter }}>
                                <TableRow>
                                    {headCells.map((headCell) => (
                                        <TableCell
                                            key={headCell.id}
                                            align={headCell.align}
                                            padding={headCell.disablePadding ? 'none' : 'normal'}
                                        >
                                            {headCell.label}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {orderDetails?.orderItems?.map((prod) => (
                                    <TableRow
                                        role="checkbox"
                                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                        tabIndex={-1}
                                        key={prod?.id}
                                    >
                                        <TableCell scope="row" align="left">
                                            <Box display="flex" gap={2} alignItems="center">
                                                <Avatar
                                                    src={`${remoteUrl}${prod.image}`}
                                                    alt={prod.name}
                                                    width="70px"
                                                    height="70px"
                                                    variant="rounded"
                                                    sx={{ '& img': { objectFit: 'contain' } }}
                                                />
                                                <Typography variant="body1">{prod.name}</Typography>
                                            </Box>
                                        </TableCell>
                                        <TableCell align="right">${Math.floor(prod.price)}</TableCell>
                                        <TableCell align="right">{prod.quantity}</TableCell>
                                        <TableCell align="right" sx={{ fontWeight: 600 }}>
                                            ${prod.price * prod.quantity}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                            <TableFooter>
                                <TableRow sx={{ borderTop: (theme) => `1px solid ${theme.palette.divider}`, borderBottom: 'none' }}>
                                    <TableCell colSpan={3} />
                                    <TableCell colSpan={2}>
                                        <Box mt={1} display="flex" gap={1} justifyContent="space-between">
                                            <Typography variant="h5" color="textPrimary">
                                                Grand Total
                                            </Typography>
                                            <Typography variant="h5" color="textPrimary">
                                                $ {orderDetails.total}
                                            </Typography>
                                        </Box>
                                    </TableCell>
                                </TableRow>
                            </TableFooter>
                        </Table>
                    </TableContainer>
                    <Grid mt={2} container spacing={2}>
                        <Grid item xs={12} sm={4}>
                            <SmallCard>
                                <Typography variant="h5" align="center">
                                    Customer Details
                                </Typography>
                                <Box display="flex" gap={2}>
                                    <Avatar
                                        src={orderDetails?.user?.image ? `${remoteUrl}${orderDetails?.user?.image}` : userImg}
                                        width="40px"
                                        height="40px"
                                        variant="rounded"
                                    />
                                    <Box
                                        sx={{
                                            overflowWrap: 'anywhere'
                                        }}
                                    >
                                        <Typography variant="subtitle1" color="textSecondary">
                                            {orderDetails?.user?.name}
                                        </Typography>
                                        <Typography variant="body1"> {orderDetails?.user?.email}</Typography>
                                    </Box>
                                </Box>
                            </SmallCard>
                        </Grid>
                    </Grid>
                </>
            )}
        </MainCard>
    );
};

const SmallCard = styled(Box)(({ theme }) => ({
    padding: '15px',
    borderRadius: '10px',
    border: `1px solid ${theme.palette.divider}`,
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    height: '100%'
}));

export default OrderView;
