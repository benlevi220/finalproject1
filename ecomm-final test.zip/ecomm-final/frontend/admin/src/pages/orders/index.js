import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import MainCard from 'components/MainCard';
import { getOrders } from 'store/reducers/orders/extraReducers';
import OrdersTable from './OrdersTable';

const Orders = () => {
    const { orders, fetching } = useSelector((st) => st.order);
    const dispatch = useDispatch();

    useEffect(() => {
        if (fetching) dispatch(getOrders({ page: 1, limit: 12 }));
    }, [fetching, dispatch]);

    return (
        <MainCard sx={{ mt: 2 }} content={false}>
            <OrdersTable orders={orders} loading={fetching} />
        </MainCard>
    );
};

export default Orders;
