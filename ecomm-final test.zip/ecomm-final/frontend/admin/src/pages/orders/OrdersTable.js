import { Icon } from '@iconify/react';
import React from 'react';
import { useNavigate } from 'react-router-dom';

import { IconButton, Skeleton, Table, TableBody, TableCell, TablePagination, TableRow, Typography } from '@mui/material';

import ChipLabel from 'components/ChipLabel';
import NoData from 'components/NoData';
import TablePaginationActions from 'components/table/TablePagination';
import { getFormatDate, getTotalOfOrder } from 'utils/misc';

import eyeOutline from '@iconify/icons-mdi/eye-outline';
import { getAllOrders } from 'api/order';
import TableContainer from 'components/table/TableContainer';
import TableHead from 'components/table/TableHead';
import { dispatch } from 'store/index';

function getChipColor(type) {
    if (type === 'pending' || type === 'paid') return 'warning';
    if (type === 'delivered') return 'success';
    else return 'error';
}

const headCells = [
    {
        id: 'buyerInfo',
        align: 'left',
        disablePadding: false,
        label: 'Buyer'
    },
    {
        id: 'buyer_email',
        align: 'left',
        disablePadding: false,
        label: 'Email'
    },
    {
        id: 'order_items',
        align: 'left',
        disablePadding: false,
        label: 'Ordered Items'
    },
    {
        id: 'final_price',
        align: 'right',
        disablePadding: false,
        label: 'Paid Amount'
    },
    {
        id: 'purchasedOn',
        align: 'center',
        disablePadding: false,
        label: 'Purchased On'
    },
    {
        id: 'status',
        align: 'center',
        disablePadding: false,
        label: 'Status'
    },
    {
        id: 'actions',
        align: 'right',
        disablePadding: false,
        label: ''
    }
];

export default function OrdersTable({ orders, loading }) {
    const [page, setPage] = React.useState(0);
    const [rowsPerPage] = React.useState(10);

    const navigate = useNavigate();

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
        dispatch(getAllOrders({ page, limit: 12 }));
    };

    return (
        <TableContainer>
            <Table
                aria-labelledby="tableTitle"
                sx={{
                    '& .MuiTableCell-root:first-of-type': {
                        pl: 2
                    },
                    '& .MuiTableCell-root:last-of-type': {
                        pr: 3
                    }
                }}
            >
                <TableHead headCells={headCells} />
                <TableBody>
                    {loading ? (
                        Array(9)
                            .fill()
                            .map((_, idx) => (
                                <TableRow key={idx}>
                                    {Array(headCells.length)
                                        .fill()
                                        .map((_, idx) => (
                                            <TableCell key={idx * 2}>
                                                <Skeleton />
                                            </TableCell>
                                        ))}
                                </TableRow>
                            ))
                    ) : orders?.length > 0 ? (
                        [...orders]
                            ?.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                            ?.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            ?.map((row) => {
                                return (
                                    <TableRow
                                        hover
                                        role="checkbox"
                                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                        tabIndex={-1}
                                        key={row.id}
                                    >
                                        <TableCell scope="row" align="left">
                                            {row.user.name}
                                        </TableCell>
                                        <TableCell scope="row" align="left">
                                            {row.user.email}
                                        </TableCell>
                                        <TableCell align="left">{row.orderItems.length}</TableCell>
                                        <TableCell align="right" sx={{ fontWeight: 600 }}>
                                            ${row.total}
                                        </TableCell>
                                        <TableCell align="center">{getFormatDate(row.createdAt)}</TableCell>
                                        <TableCell align="center">
                                            <ChipLabel color={getChipColor(row.status)}>{row.status}</ChipLabel>
                                        </TableCell>
                                        <TableCell align="right">
                                            <IconButton
                                                sx={{ borderRadius: '50%' }}
                                                color="primary"
                                                onClick={() => navigate(`/orders/${row._id}`)}
                                            >
                                                <Icon icon={eyeOutline} width="24px" height="24px" />
                                            </IconButton>
                                        </TableCell>
                                    </TableRow>
                                );
                            })
                    ) : (
                        <TableRow>
                            <TableCell align="center" colSpan={6}>
                                <NoData />
                            </TableCell>
                        </TableRow>
                    )}
                </TableBody>
            </Table>
            <TablePagination
                labelDisplayedRows={({ page }) => {
                    return (
                        <Typography variant="subtitle2" component="span">
                            Page {page + 1} of {Math.ceil(orders?.length / rowsPerPage) || 1}
                        </Typography>
                    );
                }}
                count={orders?.length || 0}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                labelRowsPerPage={''}
                rowsPerPageOptions={-1}
                ActionsComponent={TablePaginationActions}
                SelectProps={{
                    inputProps: {
                        'aria-label': 'rows per page'
                    },
                    native: false
                }}
            />
        </TableContainer>
    );
}
