import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';

import { Box } from '@mui/material';
import { Typography } from '@mui/material';

import MainCard from 'components/MainCard';

import { getUsers } from 'store/reducers/users/extraReducers';

const ViewUser = () => {
    const [user, setUser] = useState(null);
    const { fetching, users } = useSelector((st) => st.users);
    const dispatch = useDispatch();

    const { id } = useParams();

    useEffect(() => {
        if (!users) {
            dispatch(getUsers());
        }
    }, [users, dispatch]);

    useEffect(() => {
        if (id && users) setUser(...users.filter((el) => el.id === +id));
    }, [id]);

    if (fetching) return;

    return (
        <Box display="flex" gap={1} flexDirection="column">
            <MainCard sx={{ mt: 2, padding: '30px' }} content={false}>
                <Box display="flex" flexDirection="column" gap={4}>
                    <Box>
                        <Box
                            width="140px"
                            height="140px"
                            borderRadius="50%"
                            sx={{
                                backgroundSize: 'contain',
                                backgroundRepeat: 'no-repeat',
                                backgroundPosition: 'center',
                                ...(user?.image && {
                                    backgroundImage: `url('/assets/images/users/avatar-1.png')`,
                                    backgroundSize: 'contain',
                                    backgroundRepeat: 'no-repeat',
                                    backgroundPosition: 'center'
                                }),
                                ...(!user?.image && {
                                    backgroundColor: (theme) => theme.palette.divider,
                                    backgroundImage: `url(https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=${user?.firstName}${user?.lastName})`,
                                    backgroundSize: 'contain'
                                })
                            }}
                        />
                    </Box>
                    <Box display="flex" flexDirection="column" gap={4} sx={{ width: '60%' }}>
                        <Box display="flex" gap={1}>
                            <Box display="flex" flex={1} flexDirection="column" gap={0.5}>
                                <Typography variant="subtitle1">Full Name</Typography>
                                <Typography variant="body1">
                                    {user?.firstName} {user?.lastName}
                                </Typography>
                            </Box>
                            <Box display="flex" flex={1} flexDirection="column" gap={0.5}>
                                <Typography variant="subtitle1">Email</Typography>
                                <Typography variant="body1">{user?.email}</Typography>
                            </Box>
                        </Box>
                        <Box display="flex" gap={1}>
                            <Box display="flex" flex={1} flexDirection="column" gap={0.5}>
                                <Typography variant="subtitle1">Role</Typography>
                                <Typography variant="body1">{user?.role}</Typography>
                            </Box>
                            <Box display="flex" flex={1} flexDirection="column" gap={0.5}>
                                <Typography variant="subtitle1">Phone No.</Typography>
                                <Typography variant="body1">{user?.phone || '-'}</Typography>
                            </Box>
                        </Box>
                        <Box display="flex" gap={1}>
                            <Box display="flex" flex={1} flexDirection="column" gap={0.5}>
                                <Typography variant="subtitle1">Address</Typography>
                                <Typography variant="body1">{user?.address || '-'}</Typography>
                            </Box>
                        </Box>
                    </Box>
                </Box>
            </MainCard>
        </Box>
    );
};

export default ViewUser;
