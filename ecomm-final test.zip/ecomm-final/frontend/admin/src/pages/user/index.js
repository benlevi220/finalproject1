import MainCard from 'components/MainCard';
import UserTable from './UsersTable';

const Users = () => (
    <MainCard sx={{ mt: 2 }} content={false}>
        <UserTable />
    </MainCard>
);

export default Users;
