import { Icon } from '@iconify/react';
import React, { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

// material-ui
import { Box, Table, TableBody, TableCell, TableRow, Typography } from '@mui/material';

import eyeOutline from '@iconify/icons-mdi/eye-outline';

import { Button, IconButton, Skeleton, TablePagination } from '@mui/material';

import NoData from 'components/NoData';
import UserBlock from 'components/UserBlockMenu';
import Label from 'components/label';
import TableContainer from 'components/table/TableContainer';
import TableHead from 'components/table/TableHead';
import TablePaginationActions from 'components/table/TablePagination';
import Search from 'layout/MainLayout/Header/HeaderContent/Search';

import { getComparator, stableSort } from 'components/table/tableSortFunc';
import { getUsers } from 'store/reducers/users/extraReducers';
import { getFormatDate } from 'utils/misc';

const headCells = [
    {
        id: 'Name',
        align: 'left',
        disablePadding: true,
        label: 'Name'
    },
    {
        id: 'email',
        align: 'left',
        disablePadding: false,
        label: 'Email'
    },
    {
        id: 'role',
        align: 'left',
        disablePadding: false,
        label: 'Role'
    },
    {
        id: 'createdAt',
        align: 'center',
        disablePadding: false,
        label: 'Registered On',
        allowSort: true
    },
    {
        id: 'actions',
        align: 'center',
        disablePadding: false,
        label: ''
    }
];

export default function UserTable() {
    const [selected] = useState([]);
    const [filter, setFilter] = useState('');

    const [page, setPage] = React.useState(0);
    const [rowsPerPage] = React.useState(10);

    const [order, setOrder] = useState('desc');
    const [orderBy, setOrderBy] = useState('createdAt');

    const { users, fetching, totalUsers } = useSelector((st) => st.users);
    const { user } = useSelector((st) => st.auth);
    const dispatch = useDispatch();

    useEffect(() => {
        if (fetching) dispatch(getUsers());
    }, [fetching, dispatch]);

    const navigate = useNavigate();

    const isSelected = (trackingNo) => selected.indexOf(trackingNo) !== -1;

    const handleChangePage = (_, newPage) => setPage(newPage);
    const handleChange = (e) => setFilter(e.target.value);

    let filteredUsers =
        filter !== ''
            ? users
                  ?.filter((el) => el.email !== user.email)
                  ?.filter((el) => el.firstName.toLowerCase().indexOf(filter.toLowerCase()) !== -1)
            : users?.filter((el) => el.email !== user.email);

    const handleSortBy = (property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const visibleRows = useMemo(
        () =>
            filteredUsers?.length > 0
                ? stableSort(
                      [...filteredUsers]?.map((el) => ({
                          id: el._id,
                          name: el.name || '',
                          email: el.email,
                          createdAt: el?.createdAt,
                          role: el.role
                      })),
                      getComparator(order, orderBy)
                  )
                : [],
        [order, orderBy, filteredUsers]
    );

    return (
        <Box>
            <Box sx={{ display: 'flex', gap: '1rem', justifyContent: 'space-between', paddingInline: '16px', paddingBlock: '20px' }}>
                <Search handleChange={handleChange} />
                {/* <Button variant="contained" sx={{ textTransform: 'capitalize' }} onClick={() => navigate('/users/create')}>
                    Add New
                </Button> */}
            </Box>
            <TableContainer>
                <Table
                    aria-labelledby="tableTitle"
                    sx={{
                        '& .MuiTableCell-root:first-of-type': {
                            pl: 2
                        },
                        '& .MuiTableCell-root:last-of-type': {
                            pr: 3
                        }
                    }}
                >
                    <TableHead headCells={headCells} orderBy={orderBy} order={order} handleOrderBy={handleSortBy} />
                    <TableBody>
                        {fetching ? (
                            Array(9)
                                .fill()
                                .map((_, idx) => (
                                    <TableRow key={idx}>
                                        <TableCell>
                                            <Skeleton />
                                        </TableCell>
                                        {Array(6)
                                            .fill()
                                            .map((_, idx) => (
                                                <TableCell key={idx * 2}>
                                                    <Skeleton />
                                                </TableCell>
                                            ))}
                                    </TableRow>
                                ))
                        ) : visibleRows?.length > 0 ? (
                            [...visibleRows]
                                .slice(Math.ceil(page / rowsPerPage) * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((row, index) => {
                                    const isItemSelected = isSelected(row.id);
                                    return (
                                        <TableRow
                                            hover
                                            role="checkbox"
                                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                            aria-checked={isItemSelected}
                                            tabIndex={-1}
                                            key={row.id}
                                            selected={isItemSelected}
                                        >
                                            <TableCell align="left" scope="row">
                                                {row.name}
                                            </TableCell>
                                            <TableCell align="left">{row.email}</TableCell>
                                            <TableCell align="left">{row.role}</TableCell>
                                            <TableCell align="center">{getFormatDate(row.createdAt)}</TableCell>
                                        </TableRow>
                                    );
                                })
                        ) : (
                            <TableRow>
                                <TableCell align="center" colSpan={6}>
                                    <NoData />
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
                <TablePagination
                    labelDisplayedRows={({ page }) => {
                        return (
                            <Typography variant="subtitle2" component="span">
                                Page {page + 1} of {Math.ceil(totalUsers / rowsPerPage) || 1}
                            </Typography>
                        );
                    }}
                    count={totalUsers || 0}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    labelRowsPerPage={''}
                    rowsPerPageOptions={-1}
                    ActionsComponent={TablePaginationActions}
                    SelectProps={{
                        inputProps: {
                            'aria-label': 'rows per page'
                        },
                        native: false
                    }}
                />
            </TableContainer>
        </Box>
    );
}
