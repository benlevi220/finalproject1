import React from 'react';
import UserForm from 'components/forms/UserForm';
import MainCard from 'components/MainCard';
import { Box } from '@mui/material';

const CreateUser = () => {
    return (
        <Box display="flex" gap={1} flexDirection="column">
            <MainCard sx={{ mt: 2, padding: '30px' }} content={false}>
                <UserForm />
            </MainCard>
        </Box>
    );
};

export default CreateUser;
