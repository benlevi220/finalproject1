import MainCard from 'components/MainCard';
import { Skeleton, Stack } from '@mui/material';

export const SmallheaderCards = () => {
    return (
        <MainCard contentSX={{ p: 2.25 }}>
            <Stack spacing={0.5}>
                <Skeleton width="100%" height="30px" />
                <Skeleton width="60%" height="30px" />
                <Skeleton width="30%" height="30px" />
            </Stack>
        </MainCard>
    );
};
