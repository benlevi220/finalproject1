import MainCard from 'components/MainCard';
import CategoryTable from './CategoryTable';

const Categories = () => {
    return (
        <MainCard sx={{ mt: 2 }} content={false}>
            <CategoryTable />
        </MainCard>
    );
};

export default Categories;
