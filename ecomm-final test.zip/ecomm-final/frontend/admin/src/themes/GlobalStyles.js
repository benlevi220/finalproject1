// @mui
import { GlobalStyles as MUIGlobalStyles } from '@mui/material';

// ----------------------------------------------------------------------

export default function GlobalStyles() {
    const inputGlobalStyles = (
        <MUIGlobalStyles
            styles={{
                '*': {
                    boxSizing: 'border-box'
                },
                html: {
                    margin: 0,
                    padding: 0,
                    width: '100%',
                    height: '100%',
                    WebkitOverflowScrolling: 'touch'
                },
                'html::-webkit-scrollbar': {
                    width: '0.75vw',
                    borderRadius: 10
                },
                'html::-webkit-scrollbar-thumb': {
                    backgroundColor: '#9fa2aa'
                },
                'html::-webkit-scrollbar-track': {
                    backgroundColor: 'transparent'
                },
                body: {
                    margin: 0,
                    padding: 0,
                    width: '100%',
                    height: '100%'
                },
                '#root': {
                    width: '100%',
                    height: '100%',
                    scrollBehavior: 'smooth',
                    overflowX: 'hidden'
                }
            }}
        />
    );

    return inputGlobalStyles;
}
