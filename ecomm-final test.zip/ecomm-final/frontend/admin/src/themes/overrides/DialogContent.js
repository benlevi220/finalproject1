export default function DialogContent(theme) {
    return {
        MuiDialogContent: {
            styleOverrides: {
                root: {
                    paddingInline: 40,
                    paddingBottom: 0
                }
            }
        }
    };
}
