// ==============================|| OVERRIDES - BUTTON ||============================== //

export default function Popover(theme) {
    const disabledStyle = {
        '&.Mui-disabled': {
            backgroundColor: theme.palette.grey[200]
        }
    };

    return {
        MuiPopover: {
            styleOverrides: {
                paper: {
                    backgroundColor: theme.palette.primary.main,
                    color: '#fff',
                    '& ul': {
                        paddingBlock: 0
                    },
                    '& li': {
                        justifyContent: 'center',
                        minWidth: '100px',
                        paddingBlock: '8px',
                        '&:hover': {
                            backgroundColor: theme.palette.primary.dark
                        }
                    },
                    '& li:not(:last-of-type)': {
                        borderBottom: '1px solid #fff'
                    }
                }
            }
        }
    };
}
