export default function Dialog(theme) {
    return {
        MuiDialog: {
            styleOverrides: {
                paper: {
                    maxWidth: 500,
                    width: 500
                }
            }
        }
    };
}
