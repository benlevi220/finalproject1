export default function DialogActions(theme) {
    return {
        MuiDialogActions: {
            styleOverrides: {
                root: {
                    paddingBlock: '20px',
                    justifyContent: 'center'
                }
            }
        }
    };
}
