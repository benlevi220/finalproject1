/* eslint-disable react-hooks/exhaustive-deps */
import React from 'react';
import * as yup from 'yup';
import { Icon } from '@iconify/react/dist/iconify';
import { useFormik } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import { Box } from '@mui/material';
import { TextField } from '@mui/material';
import { Button } from '@mui/material';
import { CircularProgress } from '@mui/material';
import { IconButton, InputAdornment, OutlinedInput } from '@mui/material';

import FormField from 'components/FormField';

import { addUser } from 'store/reducers/users/extraReducers';

import eyeOutline from '@iconify/icons-mdi/eye-outline';
import eyeOffOutline from '@iconify/icons-mdi/eye-off-outline';

const phoneRegExp = /^((\+?[1-9][0-9]{0,3}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;

const UserForm = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const { loading } = useSelector((st) => st.users);
    const [showPassword, setShowPassword] = React.useState(false);

    const initialValues = {
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        phone: ''
    };

    const validationSchema = yup.object({
        email: yup.string().email().required('enter email'),
        firstName: yup.string().required('ewnter first').min(3),
        lastName: yup.string().required('enter last name').min(3),
        phone: yup.string().matches(phoneRegExp, 'Phone number is not valid').required('Enter phone number'),
        password: yup.string().required('Enter password').min(8, 'Password atleast 8 characters long')
    });

    const formik = useFormik({
        initialValues,
        validationSchema,
        validateOnBlur: false,
        validateOnChange: true,
        onSubmit: (values) =>
            dispatch(addUser(values)).then((res) => {
                if (res.meta.requestStatus === 'fulfilled') navigate('/users');
            })
    });

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    return (
        <form id="create" onSubmit={formik.handleSubmit}>
            <Box display="grid" gridTemplateColumns="repeat(2,1fr)" gap={2} width="80%">
                <FormField title="First Name">
                    <TextField
                        name="firstName"
                        value={formik.values.firstName}
                        onChange={formik.handleChange}
                        error={formik.touched.firstName && Boolean(formik.errors.firstName)}
                        helperText={formik.touched.firstName && formik.errors.firstName}
                        placeholder="First Name"
                        variant="outlined"
                        size="medium"
                        className="textField"
                    />
                </FormField>
                <FormField title="Last Name">
                    <TextField
                        name="lastName"
                        value={formik.values.lastName}
                        onChange={formik.handleChange}
                        error={formik.touched.lastName && Boolean(formik.errors.lastName)}
                        helperText={formik.touched.lastName && formik.errors.lastName}
                        placeholder="Last Name"
                        variant="outlined"
                        color="secondary"
                        className="textField"
                        size="medium"
                    />
                </FormField>
                <FormField title="Email">
                    <TextField
                        name="email"
                        type="email"
                        value={formik.values.email}
                        onChange={formik.handleChange}
                        error={formik.touched.email && Boolean(formik.errors.email)}
                        helperText={formik.touched.email && formik.errors.email}
                        placeholder="Email"
                        variant="outlined"
                        color="secondary"
                        className="textField"
                        size="medium"
                    />
                </FormField>
                <FormField title="Password">
                    <OutlinedInput
                        name="password"
                        value={formik.values.password}
                        onChange={formik.handleChange}
                        error={formik.touched.password && Boolean(formik.errors.password)}
                        helperText={formik.touched.password && formik.errors.password}
                        placeholder="Passworn (min 8 characters)"
                        variant="outlined"
                        size="medium"
                        className="textField"
                        type={showPassword ? 'text' : 'password'}
                        endAdornment={
                            <InputAdornment position="end">
                                <IconButton aria-label="toggle password visibility" onClick={handleClickShowPassword} edge="end">
                                    <Icon icon={showPassword ? eyeOutline : eyeOffOutline} width={30} height={30} />
                                </IconButton>
                            </InputAdornment>
                        }
                    />
                </FormField>
                <FormField title="Phone No.">
                    <TextField
                        name="phone"
                        value={formik.values.phone}
                        onChange={formik.handleChange}
                        error={formik.touched.phone && Boolean(formik.errors.phone)}
                        helperText={formik.touched.phone && formik.errors.phone}
                        placeholder="Phone with country code (e.g. 913123113232)"
                        variant="outlined"
                        size="medium"
                        className="textField"
                    />
                </FormField>
            </Box>
            <Box width="100%" mt={3}>
                <Button
                    variant="contained"
                    sx={{ textTransform: 'capitalize', marginRight: '0.5rem' }}
                    color="secondary"
                    type="submit"
                    onClick={() => navigate('/users')}
                >
                    Cancel
                </Button>
                <Button variant="contained" sx={{ textTransform: 'capitalize' }} type="submit">
                    {loading ? <CircularProgress size="1.5rem" color="secondary" /> : 'Create'}
                </Button>
            </Box>
        </form>
    );
};

export default UserForm;
