import React from 'react';
import { TableContainer as TableContainerExt, styled } from '@mui/material';

const TableContainer = (props) => {
    return <TableExt>{props.children}</TableExt>;
};

const TableExt = styled(TableContainerExt)(() => ({
    width: '100%',
    overflowX: 'auto',
    position: 'relative',
    display: 'block',
    maxWidth: '100%',
    '& td, & th': { whiteSpace: 'nowrap' }
}));

export default TableContainer;
