import * as React from 'react';
import PropTypes from 'prop-types';
import { Box, IconButton, Typography, useTheme } from '@mui/material';
import { Icon } from '@iconify/react';
import chevronRight from '@iconify/icons-mdi/chevron-right';
import chevronLeft from '@iconify/icons-mdi/chevron-left';

export default function TablePaginationActions(props) {
    const theme = useTheme();
    const { count, page, rowsPerPage, onPageChange } = props;

    const handleBackButtonClick = (event) => {
        onPageChange(event, page - 1);
    };

    const handleNextButtonClick = (event) => {
        onPageChange(event, page + 1);
    };

    return (
        <>
            <Box display="flex" alignItems="center" sx={{ flexShrink: 0, marginRight: '0.5rem' }}>
                <IconButton
                    onClick={handleBackButtonClick}
                    disabled={page === 0}
                    aria-label="previous page"
                    size="small"
                    // color="text.primary"
                    disableRipple
                    sx={{ paddingInline: 0 }}
                >
                    {theme.direction === 'rtl' ? (
                        <Icon width="24px" height="24px" color="inherit" icon={chevronRight} />
                    ) : (
                        <Icon width="24px" height="24px" color="inherit" icon={chevronLeft} />
                    )}
                </IconButton>
                <Typography variant="subtitle2" component="span">
                    {page + 1}
                </Typography>
                <IconButton
                    onClick={handleNextButtonClick}
                    disabled={page >= Math.ceil(count / rowsPerPage) - 1}
                    aria-label="next page"
                    // color="text.primary"
                    sx={{ paddingInline: 0 }}
                    disableRipple
                >
                    {theme.direction === 'rtl' ? (
                        <Icon width="24px" height="24px" color="inherit" icon={chevronLeft} />
                    ) : (
                        <Icon width="24px" height="24px" color="inherit" icon={chevronRight} />
                    )}
                </IconButton>
            </Box>
        </>
    );
}

TablePaginationActions.propTypes = {
    count: PropTypes.number.isRequired,
    onPageChange: PropTypes.func.isRequired,
    page: PropTypes.number.isRequired,
    rowsPerPage: PropTypes.number.isRequired
};
