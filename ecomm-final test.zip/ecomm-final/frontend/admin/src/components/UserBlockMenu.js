import { IconButton, Menu, MenuItem } from '@mui/material';
import React from 'react';

import accountCancel from '@iconify/icons-mdi/account-cancel';
import { Icon } from '@iconify/react/dist/iconify';

import { useState } from 'react';
import { blockUser } from 'store/reducers/users/extraReducers';

import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';

const UserBlock = ({ rowInfo }) => {
    const [anchorElUser, setAnchorElUser] = React.useState(null);
    const [selected, setSelected] = useState(null);
    const dispatch = useDispatch();
    const { loading } = useSelector((st) => st.users);

    const handleOpenUserMenu = (event) => {
        setAnchorElUser(event.currentTarget);
        setSelected(rowInfo);
    };
    const handleCloseUserMenu = () => {
        setAnchorElUser(null);
    };

    return (
        <>
            <IconButton
                color={rowInfo.blocked_till === null ? 'warning' : 'error'}
                sx={{ borderRadius: '50%' }}
                onClick={handleOpenUserMenu}
                disabled={loading}
            >
                <Icon icon={accountCancel} width="24px" height="24px" color="info" />
            </IconButton>
            <Menu
                sx={{
                    mt: '30px'
                }}
                id="menu-blogTable"
                anchorEl={anchorElUser}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right'
                }}
                keepMounted
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right'
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
            >
                <MenuItem
                    onClick={() => {
                        dispatch(blockUser({ userId: selected.id, block: '15d' })).then((res) => {
                            if (res.meta.requestStatus === 'fulfilled') toast.success('User blocked successfully');
                        });
                        handleCloseUserMenu();
                    }}
                >
                    Block
                </MenuItem>
                <MenuItem
                    onClick={() => {
                        dispatch(blockUser({ userId: selected.id, block: false })).then((res) => {
                            if (res.meta.requestStatus === 'fulfilled') toast.success('User unblocked successfully');
                        });
                        handleCloseUserMenu();
                    }}
                >
                    Un-Block
                </MenuItem>
            </Menu>
        </>
    );
};

export default UserBlock;
