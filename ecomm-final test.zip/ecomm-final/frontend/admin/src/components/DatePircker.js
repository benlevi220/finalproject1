import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DesktopDatePicker } from '@mui/x-date-pickers/DesktopDatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { parse } from 'date-fns';

export default function CustomDatePicker({ value, onDateChange, disablePast = true }) {
    const referenceDate = new Date(1970, 0, 1, 0, 0, 0);
    const datefnsDate = parse(value, 'MM/dd/yyyy', referenceDate);

    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DesktopDatePicker
                value={datefnsDate}
                onChange={onDateChange}
                disablePast={disablePast}
                slotProps={{
                    textField: {
                        helperText: 'MM/dd/yyyy'
                    }
                }}
            />
        </LocalizationProvider>
    );
}
