import React from 'react';
import { Box, Typography } from '@mui/material';

const FormField = ({ title, children }) => {
    return (
        <Box display="flex" gap="0.5rem" flexDirection="column">
            <Typography variant="subtitle1">{title}</Typography>
            {children}
        </Box>
    );
};

export default FormField;
