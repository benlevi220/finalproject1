import { styled } from '@mui/material';
import { Chip as MuiChip } from '@mui/material/index';

export const Chip = styled(MuiChip)(({ theme }) => ({
    borderRadius: '20px'
}));
