import React from 'react';

const WriteComment = () => {
    return <div>WriteComment</div>;
};

export default WriteComment;
