import React from 'react';
import { Box } from '@mui/material';
import { Avatar, Rating, Typography } from '@mui/material';
import { getFormatDate } from 'utils/misc';

const UserComment = ({ comment }) => {
    const { image, user, date, rating, description } = comment;
    return (
        <Box p={3} borderRadius="10px" sx={{ border: (theme) => `1px solid ${theme.palette.divider}` }}>
            <Box display="flex" gap={2}>
                <Avatar src={user.image} width="30px" height="30px" />
                <Box>
                    <Typography variant="subtitle1">{user.name}</Typography>
                    <Typography variant="body2" color="secondary">
                        {getFormatDate(date)}
                    </Typography>
                    <Rating name="read-only" precision={0.5} value={rating} readOnly />
                    <Typography variant="body2" sx={{ marginTop: '1rem' }}>
                        {description}
                    </Typography>
                </Box>
            </Box>
        </Box>
    );
};

export default UserComment;
