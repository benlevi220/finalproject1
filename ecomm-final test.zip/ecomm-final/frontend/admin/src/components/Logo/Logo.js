// material-ui
import logo from 'assets/images/logo/logo.webp';

// ==============================|| LOGO SVG ||============================== //

const Logo = () => {
    return (
        <img
            src={logo}
            alt="ShopNow"
            width="100%"
            height="100%"
            style={{
                maxWidth: '170px',
                height: 'fit-content'
            }}
        />
    );
};

export default Logo;
