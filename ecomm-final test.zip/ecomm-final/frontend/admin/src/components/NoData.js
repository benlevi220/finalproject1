import React from 'react';
import { Box } from '@mui/material';
import { ReactSVG } from 'react-svg';
import noFound from '../assets/images/icons/notFound.svg';

const NoData = () => {
    return (
        <Box
            display="flex"
            alignItems="center"
            justifyContent="center"
            minHeight="400px"
            width="100%"
            sx={{
                '& svg': {
                    maxWidth: '150px',
                    height: '100%'
                }
            }}
        >
            <ReactSVG src={noFound} />
        </Box>
    );
};

export default NoData;
