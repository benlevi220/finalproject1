import { styled } from '@mui/material';

export const IconRoot = styled('div', {
    shouldForwardProp: (props) => props !== 'width' && props !== 'height' && props !== 'color'
})(({ width, height, color, theme }) => ({
    '& div': {
        height: height ? height : 22
    },

    '& svg': {
        fontSize: 'unset',
        color: color ? color : theme.palette.text.primary,
        width: width ? width : 22,
        height: height ? height : 22
    }
}));
