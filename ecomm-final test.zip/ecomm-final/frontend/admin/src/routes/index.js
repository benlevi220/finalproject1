import React, { lazy, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Navigate, Route, Routes } from 'react-router-dom';

import FullPageLoader from 'components/FullPageLoader';
import Loadable from 'components/Loadable';

import MainLayout from 'layout/MainLayout';
import MinimalLayout from 'layout/MinimalLayout';

import { getMe } from 'store/reducers/auth/extraReducers';
import { getCategoryList } from 'store/reducers/category/extraReducers';

// const Dashboard = Loadable(lazy(() => import('pages/dashboard')));
const Categories = Loadable(lazy(() => import('pages/categories')));
const Users = Loadable(lazy(() => import('pages/user')));
const CreateProd = Loadable(lazy(() => import('pages/product/CreateProd')));
const ViewUser = Loadable(lazy(() => import('pages/user/ViewUser')));
const Product = Loadable(lazy(() => import('pages/product')));
const ViewProduct = Loadable(lazy(() => import('pages/product/ViewProduct')));
const Orders = Loadable(lazy(() => import('pages/orders')));
const OrderView = Loadable(lazy(() => import('pages/orders/OrderView')));

const Login = Loadable(lazy(() => import('pages/authentication/Login')));

const Router = () => {
    const dispatch = useDispatch();
    const { authenticating, user } = useSelector((st) => st.auth);

    useEffect(() => {
        dispatch(getMe()).then((res) => {
            if (res.meta.requestStatus === 'fulfilled') {
                dispatch(getCategoryList());
            }
        });
    }, []);

    if (authenticating) return <FullPageLoader />;

    return (
        <Routes>
            {user ? (
                <Route path="/" element={<MainLayout />}>
                    <Route path="/" element={<Navigate to="/users" />} />
                    {/* <Route path="dashboard" element={<Dashboard />} /> */}
                    <Route path="users" element={<Users />} />
                    <Route path="users/:id" element={<ViewUser />} />
                    <Route path="users/:id" element={<ViewUser />} />
                    <Route path="products" element={<Product />} />
                    <Route path="products/create" element={<CreateProd />} />
                    <Route path="products/:id" element={<ViewProduct />} />
                    <Route path="orders" element={<Orders />} />
                    <Route path="orders/:id" element={<OrderView />} />
                    <Route path="categories" element={<Categories />} />
                    <Route path="*" element={<Navigate to="/users" />} />
                </Route>
            ) : (
                <Route path="/" element={<MinimalLayout />}>
                    <Route path="/" element={<Navigate to="/login" />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="*" element={<Navigate to="/login" />} />
                </Route>
            )}
            <Route path="*" element={<Navigate to="/" />} />
        </Routes>
    );
};

export default Router;
