import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Navigate, Route, Routes } from 'react-router-dom';
import FullScreenLoader from './components/common/FullScreenLoader';
import AuthLayout from './layout/authLayout';
import LayoutMain from './layout/LayoutMain';
import HomePage from './pages';
import CheckoutPage from './pages/Checkout';
import Login from './pages/Login';
import ProductDetailPage from './pages/ProductDetail';
import ProductsPage from './pages/Products';
import Register from './pages/Register';
import { getMe } from './store/reducers/auth/extraReducers';
import { getCategoryList } from './store/reducers/category/extraReducers';
import { getFavorites } from './store/reducers/favorite/extraReducers';

const App = () => {
  const { fetching: catFetching } = useSelector((st) => st.category);
  const { authenticating } = useSelector((st) => st.auth);
  const { user } = useSelector((st) => st.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    if (catFetching) dispatch(getCategoryList());
  }, [catFetching, dispatch]);

  useEffect(() => {
    if (authenticating)
      dispatch(getMe()).then((res) => {
        if (res.meta.requestStatus === 'fulfilled') {
          dispatch(getFavorites());
        }
      });
  }, [authenticating, dispatch]);

  if (catFetching) return <FullScreenLoader />;

  return (
    <Routes>
      <Route path='/' element={<LayoutMain />}>
        <Route path='' element={<HomePage />} />
        <Route path='/products' element={<ProductsPage />} />
        <Route path='/products/:id' element={<ProductDetailPage />} />
      </Route>
      {user ? (
        <Route path='/' element={<LayoutMain />}>
          <Route path='cart/checkout' element={<CheckoutPage />} />
        </Route>
      ) : (
        <Route path='/' element={<AuthLayout />}>
          <Route path='auth/login' element={<Login />} />
          <Route path='auth/register' element={<Register />} />
          <Route path='*' element={<Navigate to='/auth/login' replace />} />
        </Route>
      )}
      <Route path='*' element={<Navigate to='/' replace />} />
    </Routes>
  );
};

export default App;
