// third-party
import { configureStore } from '@reduxjs/toolkit';

// project import
import {
  loadCartFromLocalStorage,
  saveCartToLocalStorage,
} from '../utils/cartUtils';
import reducers from './reducers';

// ==============================|| REDUX TOOLKIT - MAIN STORE ||============================== //

const store = configureStore({
  reducer: reducers,
  preloadedState: {
    cart: loadCartFromLocalStorage(),
  },
});
store.subscribe(() => {
  saveCartToLocalStorage(store.getState().cart);
});

const { dispatch } = store;

export { dispatch, store };
