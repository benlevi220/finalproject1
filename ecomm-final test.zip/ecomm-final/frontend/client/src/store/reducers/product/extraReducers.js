import { createAsyncThunk } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import axiosInstance from '../../../api';
import buildUrlWithQueryParams from '../../../utils/buildQueryParams';

export const getProducts = createAsyncThunk(
  '/getProducts',
  async (params, { rejectWithValue }) => {
    return axiosInstance
      .get(buildUrlWithQueryParams('/products', params))
      .then((res) => {
        return {
          products: res.data.products,
          total_results: res.data.total_products,
        };
      })
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);
