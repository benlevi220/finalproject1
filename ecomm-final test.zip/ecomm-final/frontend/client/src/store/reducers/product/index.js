import { createSlice } from '@reduxjs/toolkit';
import { getProducts } from './extraReducers';

const initialState = {
  products: null,
  total_results: 0,
  fetching: true,
};

const prodSlice = createSlice({
  name: 'product',
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(getProducts.pending, (state) => {
        state.fetching = true;
      })
      .addCase(getProducts.fulfilled, (state, { payload }) => {
        state.total_results = payload.total_results;
        state.products = payload.products;
        state.fetching = false;
      })
      .addCase(getProducts.rejected, (state) => {
        state.fetching = false;
      });
  },
});

export default prodSlice.reducer;
