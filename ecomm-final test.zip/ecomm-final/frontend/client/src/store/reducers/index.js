// third-party
import { combineReducers } from 'redux';

// project import
import auth from './auth';
import cart from './cart';
import categories from './category';
import favorite from './favorite';
import products from './product';

// ==============================|| COMBINE REDUCERS ||============================== //

const reducers = combineReducers({
  auth: auth,
  category: categories,
  product: products,
  cart,
  favorite,
});

export default reducers;
