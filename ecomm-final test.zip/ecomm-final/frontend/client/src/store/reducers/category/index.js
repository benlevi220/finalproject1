import { createSlice } from '@reduxjs/toolkit';
import { getCategoryList } from './extraReducers';

const initialState = {
  categories: null,
  fetching: true,
};

const categorySlice = createSlice({
  name: 'category',
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(getCategoryList.pending, (state) => {
        state.fetching = true;
      })
      .addCase(getCategoryList.fulfilled, (state, { payload }) => {
        state.categories = payload.categories;
        state.fetching = false;
      })
      .addCase(getCategoryList.rejected, (state) => {
        state.fetching = false;
      });
  },
});

export default categorySlice.reducer;
