import { createAsyncThunk } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import axiosInstance from '../../../api';

export const getCategoryList = createAsyncThunk(
  '/getCategories',
  async (_, { rejectWithValue }) => {
    return axiosInstance
      .get('/categories')
      .then((res) => ({
        categories: res.data.category,
        // total_categories: res.data.total_categories,
      }))
      .catch((err) => {
        toast.error(err);
        return rejectWithValue(err);
      });
  }
);
