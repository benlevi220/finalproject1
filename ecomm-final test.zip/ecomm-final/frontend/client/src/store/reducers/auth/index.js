import { createSlice } from '@reduxjs/toolkit';
import { getMe, login, saveShippingInfo } from './extraReducers';

const initialState = {
  authenticating: true,
  user: null,
  loading: false,
  isLoggedIn: false,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout: (state) => {
      state.user = null;
      state.loading = null;
      state.isLoggedIn = false;
      localStorage.removeItem('shopNow-token');
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getMe.pending, (state) => {
        state.authenticating = true;
      })
      .addCase(getMe.fulfilled, (state, { payload }) => {
        state.authenticating = false;
        state.user = payload.user;
        state.isLoggedIn = true;
      })
      .addCase(getMe.rejected, (state) => {
        state.authenticating = false;
      });
    builder
      .addCase(login.pending, (state) => {
        state.loading = true;
      })
      .addCase(login.fulfilled, (state, { payload }) => {
        localStorage.setItem('shopNow-token', payload.token);
        state.user = payload.user;
        state.isLoggedIn = true;
        state.loading = false;
      })
      .addCase(login.rejected, (state) => {
        state.loading = false;
      });
    builder
      .addCase(saveShippingInfo.pending, (state) => {
        state.loading = true;
      })
      .addCase(saveShippingInfo.fulfilled, (state, { payload }) => {
        state.user = {
          ...state.user,
          shippingInfo: payload.shippingAddress,
        };
        state.isLoggedIn = true;
        state.loading = false;
      })
      .addCase(saveShippingInfo.rejected, (state) => {
        state.loading = false;
      });
  },
});

export const { logout } = authSlice.actions;
export default authSlice.reducer;
