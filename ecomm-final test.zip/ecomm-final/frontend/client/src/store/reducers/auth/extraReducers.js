import { createAsyncThunk } from '@reduxjs/toolkit';
// import axiosInstance, { errorResponse } from 'api/index';
import { toast } from 'react-toastify';
import axiosInstance, { errorResponse } from '../../../api';

export const getMe = createAsyncThunk(
  '/auth/verifyMe',
  async (_, { rejectWithValue }) => {
    return axiosInstance
      .get('/auth/me')
      .then(({ data }) => ({
        user: data.user,
      }))
      .catch((err) => rejectWithValue(errorResponse(err)));
  }
);

export const login = createAsyncThunk(
  '/auth/login',
  async (values, { rejectWithValue }) => {
    return axiosInstance
      .post('/auth/login', values)
      .then((res) => {
        console.log('res', res);
        return { user: res.data.user, token: res.data.token };
      })
      .catch((err) => {
        toast.error(errorResponse(err).message);
        return rejectWithValue(errorResponse(err));
      });
  }
);

export const register = createAsyncThunk(
  '/auth/register',
  async (values, { rejectWithValue }) => {
    return axiosInstance
      .post('/auth/register', values)
      .then((res) => {
        console.log('res', res);
        return { user: res.data.user, token: res.data.token };
      })
      .catch((err) => {
        toast.error(errorResponse(err).message);
        return rejectWithValue(errorResponse(err));
      });
  }
);

export const saveShippingInfo = createAsyncThunk(
  '/auth/save-shipping',
  async (values, { rejectWithValue }) => {
    return axiosInstance
      .post('/users/shippingInfo', values)
      .then((res) => {
        return { shippingAddress: res.data.shippingAddress };
      })
      .catch((err) => {
        toast.error(errorResponse(err).message);
        return rejectWithValue(errorResponse(err));
      });
  }
);
