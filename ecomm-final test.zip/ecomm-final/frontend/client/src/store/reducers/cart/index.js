import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';

// Define the initial state of the cart
const initialState = {
  items: [],
};

// Create the cart slice
const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addItem: (state, action) => {
      const item = state.items.find((item) => item.id === action.payload.id);
      if (item) {
        item.quantity += 1;
      } else {
        state.items.push(action.payload);
      }
      toast.success('Product added to cart');
    },
    removeItem: (state, action) => {
      state.items = state.items.filter((item) => item.id !== action.payload);
      toast.success('Product removed from cart');
    },
    updateItem: (state, action) => {
      const item = state.items.find((item) => item.id === action.payload.id);
      if (item) {
        item.quantity = action.payload.quantity;
      }
    },
    clearCart: (state) => {
      state.items = [];
    },
    setCart: (state, action) => {
      state.items = action.payload;
    },
  },
});

// Export the actions
export const { addItem, removeItem, updateItem, clearCart, setCart } =
  cartSlice.actions;

// Export the reducer
export default cartSlice.reducer;
