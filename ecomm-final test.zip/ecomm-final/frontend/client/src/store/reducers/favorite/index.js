import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import {
  addToFavorite,
  getFavorites,
  removeFromFavorite,
} from './extraReducers';

const initialState = {
  fetching: true,
  loading: false,
  favorites: [],
};

const favSlice = createSlice({
  name: 'favorite',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getFavorites.pending, (state) => {
        state.fetching = true;
      })
      .addCase(getFavorites.fulfilled, (state, { payload }) => {
        state.fetching = false;
        state.favorites = payload.favorites;
      })
      .addCase(getFavorites.rejected, (state) => {
        state.fetching = false;
      });
    builder
      .addCase(addToFavorite.pending, (state) => {
        state.loading = true;
      })
      .addCase(addToFavorite.fulfilled, (state, { payload }) => {
        state.favorites = payload.favorites;
        state.loading = false;
        toast.success('Product added to favorites');
      })
      .addCase(addToFavorite.rejected, (state) => {
        state.loading = false;
      });
    builder
      .addCase(removeFromFavorite.pending, (state) => {
        state.loading = true;
      })
      .addCase(removeFromFavorite.fulfilled, (state, { payload }) => {
        state.favorites = state.favorites.filter(
          (el) => el.id !== payload.favorite
        );
        state.loading = false;
        toast.success('Product removed from favorites');
      })
      .addCase(removeFromFavorite.rejected, (state) => {
        state.loading = false;
      });
  },
});

export default favSlice.reducer;
