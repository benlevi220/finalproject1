import { createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance, { errorResponse } from '../../../api';

export const getFavorites = createAsyncThunk(
  'favorite-get',
  async (id, { rejectWithValue }) => {
    return axiosInstance
      .get(`/users/favorites`)
      .then(({ data }) => ({
        favorites: data.favorites,
      }))
      .catch((err) => rejectWithValue(errorResponse(err)));
  }
);
export const addToFavorite = createAsyncThunk(
  'favorite-new',
  async (productId, { rejectWithValue }) => {
    return axiosInstance
      .post(`/users/favorites`, { productId })
      .then(({ data }) => ({
        favorites: data.favorites,
      }))
      .catch((err) => rejectWithValue(errorResponse(err)));
  }
);
export const removeFromFavorite = createAsyncThunk(
  'favorite-remove',
  async (productId, { rejectWithValue }) => {
    return axiosInstance
      .delete(`/users/favorites/${productId}`)
      .then(() => ({
        favorite: productId,
      }))
      .catch((err) => rejectWithValue(errorResponse(err)));
  }
);
