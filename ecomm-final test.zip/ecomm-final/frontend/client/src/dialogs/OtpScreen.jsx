import { Cancel, Done, Replay } from '@mui/icons-material';
import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from '@mui/material';
import { useEffect, useState } from 'react';
import OtpInput from 'react-otp-input';

function OTPModal({
  open,
  handleClose,
  onSuccess,
  isVerifyingOTp,
  maxWidth = '510px',
  otp,
  setOTP,
  title = 'Enter the OTP to verify your email.',
  handleResend,
  isResending,
  handleCancel,
}) {
  const [allBoxesFilled, setAllBoxesFilled] = useState(false);

  useEffect(() => {
    if (otp.length === 4) setAllBoxesFilled(true);
    else setAllBoxesFilled(false);
  }, [otp]);

  const handleOTPSubmit = () => onSuccess(otp);

  return (
    <Dialog
      open={open}
      onClose={handleClose} // Change handleClose to onClose
      sx={{
        '& .MuiDialog-paper': {
          // backgroundColor: '#141721',
          backgroundImage: 'none',
          borderRadius: '20px',
          maxWidth,
          minWidth: 450,
          textAlign: 'center',
          justifyContent: 'center',
          alignItems: 'center',
        },
        '& .MuiInputBase-root': {
          color: '#000',
          '& input': {
            textAlign: 'center',
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '20px 35px !important',
          color: '#000',
        }}
      >
        {title}
      </DialogTitle>

      <DialogContent>
        <Box
          display='flex'
          sx={{
            gap: '15px',
          }}
        >
          <OtpInput
            value={otp}
            onChange={setOTP}
            numInputs={4}
            inputType='number'
            renderSeparator={<span>-</span>}
            renderInput={(props) => (
              <input
                {...props}
                style={{
                  width: '40px', // Adjust the width as needed
                  height: '40px', // Adjust the height as needed
                  fontSize: '18px', // Adjust the font size as needed
                  border: '2px solid #3498db', // Border color
                  borderRadius: '8px', // Border radius
                  backgroundColor: 'transparent', // Transparent background
                  textAlign: 'center', // Center the text
                  color: '#000',
                  outline: 'none', // Remove the default focus glow
                }}
              />
            )}
          />
        </Box>
      </DialogContent>

      <DialogActions>
        {handleResend && (
          <Button
            variant='contained'
            startIcon={<Replay />}
            color='warning'
            onClick={handleResend}
            fullWidth
            disabled={isResending}
          >
            {isResending ? (
              <>
                {'Resending'}
                <CircularProgress
                  sx={{
                    marginLeft: '10px',
                  }}
                  size={20}
                  // color='inherit'
                />
              </>
            ) : (
              'Resend'
            )}
          </Button>
        )}

        <Button
          variant='contained'
          startIcon={<Done />}
          color='success'
          onClick={handleOTPSubmit}
          fullWidth
          disabled={!allBoxesFilled || isVerifyingOTp} // Disable the button if not all boxes are filled
        >
          {isVerifyingOTp ? (
            <>
              {'Verifying'}
              <CircularProgress
                sx={{
                  marginLeft: '10px',
                }}
                size={20}
                color='inherit'
              />
            </>
          ) : (
            'Verify'
          )}
        </Button>

        <Button
          variant='contained'
          startIcon={<Cancel />}
          color='error'
          onClick={handleCancel}
          fullWidth
          text='close'
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default OTPModal;
