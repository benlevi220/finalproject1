import {
  CircularProgress,
  Container,
  Grid,
  MenuItem,
  Select,
  Stack,
  Typography,
} from '@mui/material';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { origin } from '../api';
import ProductCard from '../components/ProductCard';
import {
  addToFavorite,
  removeFromFavorite,
} from '../store/reducers/favorite/extraReducers';
import { getProducts } from '../store/reducers/product/extraReducers';

const ProductsPage = () => {
  const { fetching, products } = useSelector((st) => st.product);
  const { categories } = useSelector((st) => st.category);
  const { favorites } = useSelector((st) => st.favorite);
  const { isLoggedIn } = useSelector((st) => st.auth);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const category = queryParams.get('category');

  const [catFilter, setCatFilter] = useState(category ?? 'all');
  const handleChange = (e) => {
    setCatFilter(e.target.value);
    if (e.target.value === 'all') navigate('/products');
    else navigate('/products');
    dispatch(
      getProducts({
        page: 1,
        limit: 12,
        ...(e.target.value !== 'all' && { category: e.target.value }),
      })
    );
  };

  useEffect(() => {
    dispatch(
      getProducts({ page: 1, limit: 12, ...(category && { category }) })
    );
  }, [category, dispatch]);

  const handleProdFav = (id, isFav) => {
    if (!isLoggedIn)
      return toast.error('Login to add or remove product to favorite');
    if (isFav) dispatch(removeFromFavorite(id));
    else dispatch(addToFavorite(id));
  };

  return (
    <>
      <Container maxWidth='lg'>
        <Typography variant='h4' sx={{ mb: 4 }}>
          Our Products
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Stack direction='row-reverse' gap={'15px'}>
              <Select
                labelId='demo-simple-select-label'
                id='demo-simple-select'
                value={catFilter}
                label=''
                onChange={handleChange}
                size='small'
                displayEmpty
              >
                <MenuItem value='all'>All Categories</MenuItem>
                {categories.map((el) => (
                  <MenuItem key={el.id} value={el.id}>
                    {el.name}
                  </MenuItem>
                ))}
              </Select>
            </Stack>
          </Grid>
          {fetching ? (
            <Stack
              alignItems={'center'}
              justifyContent='center'
              height={'400px'}
              width='100%'
            >
              <CircularProgress size={25} />
            </Stack>
          ) : products.length > 0 ? (
            products?.map((el) => (
              <Grid key={el.id} item xs={12} sm={6} md={3}>
                <ProductCard
                  image={`${origin}${el.images[0]}`}
                  title={el.name}
                  price={el.price}
                  id={el.id}
                  isFav={
                    isLoggedIn
                      ? favorites?.filter((favProd) => favProd.id === el.id)
                          ?.length > 0
                      : false
                  }
                  handleFav={handleProdFav}
                />
              </Grid>
            ))
          ) : (
            <Stack
              alignItems={'center'}
              justifyContent='center'
              height={'300px'}
              width='100%'
            >
              <Typography variant='h6'>No Products Exists</Typography>
            </Stack>
          )}
        </Grid>
      </Container>
    </>
  );
};

export default ProductsPage;
