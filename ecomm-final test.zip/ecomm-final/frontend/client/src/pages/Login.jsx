import { Formik } from 'formik';
import * as Yup from 'yup';

import {
  Box,
  Button,
  CircularProgress,
  FormHelperText,
  Grid,
  IconButton,
  InputAdornment,
  Link,
  OutlinedInput,
  Stack,
  Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink, useLocation, useNavigate } from 'react-router-dom';

import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { toast } from 'react-toastify';
import axiosInstance, { errorResponse } from '../api';
import OTPModal from '../dialogs/OtpScreen';
import { login } from '../store/reducers/auth/extraReducers';
import { getFavorites } from '../store/reducers/favorite/extraReducers';
// import { toast } from 'react-toastify';
// import { verifySignupEmail } from '../api/verify';
// import OTPModal from '../dialogs/OtpScreen';
// import { loginUser } from '../store/slices/auth';
// import { getCart } from '../store/slices/cart/extraReducers';
// import { getMyFav } from '../store/slices/favourite/extraReducers';

const Login = () => {
  const [showPassword, setShowPassword] = React.useState(false);
  const [showOTPDialog, setShowOTPDialog] = useState(false);
  const [otp, setOtp] = useState('');
  const [isVerifyingOTp, setIsVerifyingOTp] = useState(false);
  const [isResending] = useState(false);

  const { user, loading: userLoading } = useSelector((st) => st.auth);

  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const toggleOTPDialog = () => setShowOTPDialog((st) => !st);
  const handleClickShowPassword = () => setShowPassword(!showPassword);
  const handleMouseDownPassword = (event) => event.preventDefault();

  useEffect(() => {
    if (user) navigate('/');
  }, [user]);

  const handleVerifyOTP = async (otp) => {
    setIsVerifyingOTp(true);
    await axiosInstance
      .post('/otp/verify-otp', { otp })
      .then((res) => {
        toast.success(res.data.message);
        toggleOTPDialog();
      })
      .catch((err) => {
        toast.error(errorResponse(err).message);
      })
      .finally(() => setIsVerifyingOTp(false));
  };

  let redirect = location.search ? location.search.split('=')[1] : '/';

  return (
    <>
      <Box display='flex' flexDirection='column' gap={2}>
        <Formik
          initialValues={{
            email: '',
            password: '',
            submit: null,
          }}
          validationSchema={Yup.object().shape({
            email: Yup.string()
              .email('Must be a valid email')
              .max(255)
              .required('Email is required'),
            password: Yup.string().max(255).required('Password is required'),
          })}
          onSubmit={async (values, { setSubmitting }) => {
            dispatch(
              login({ email: values.email, password: values.password })
            ).then((res) => {
              if (res.meta.requestStatus === 'fulfilled') {
                dispatch(getFavorites());
                location.search !== ''
                  ? navigate(`${redirect}`)
                  : navigate('/');
              }

              if (res?.payload?.message?.includes('verify your email'))
                toggleOTPDialog();
            });
            setSubmitting(true);
          }}
        >
          {({
            errors,
            handleBlur,
            handleChange,
            handleSubmit,
            isSubmitting,
            touched,
            values,
          }) => (
            <form noValidate onSubmit={handleSubmit}>
              <Grid container spacing={4}>
                <Grid item xs={12}>
                  <Stack spacing={1}>
                    <Typography variant='subtitle1'>Email Address</Typography>
                    <OutlinedInput
                      id='email-login'
                      type='email'
                      value={values.email}
                      name='email'
                      onBlur={handleBlur}
                      onChange={handleChange}
                      placeholder='Enter email address'
                      fullWidth
                      error={Boolean(touched.email && errors.email)}
                    />
                    {touched.email && errors.email && (
                      <FormHelperText
                        error
                        id='standard-weight-helper-text-email-login'
                      >
                        {errors.email}
                      </FormHelperText>
                    )}
                  </Stack>
                </Grid>
                <Grid item xs={12}>
                  <Stack spacing={1}>
                    <Typography variant='subtitle1'>Password</Typography>
                    <OutlinedInput
                      fullWidth
                      error={Boolean(touched.password && errors.password)}
                      id='-password-login'
                      type={showPassword ? 'text' : 'password'}
                      value={values.password}
                      name='password'
                      onBlur={handleBlur}
                      onChange={handleChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <IconButton
                            aria-label='toggle password visibility'
                            onClick={handleClickShowPassword}
                            onMouseDown={handleMouseDownPassword}
                            edge='end'
                            size='large'
                          >
                            {showPassword ? (
                              <VisibilityIcon />
                            ) : (
                              <VisibilityOffIcon />
                            )}
                          </IconButton>
                        </InputAdornment>
                      }
                      placeholder='Enter password'
                    />
                    {touched.password && errors.password && (
                      <FormHelperText
                        error
                        id='standard-weight-helper-text-password-login'
                      >
                        {errors.password}
                      </FormHelperText>
                    )}
                  </Stack>
                </Grid>

                <Grid item xs={12} sx={{ mt: -1 }}>
                  <Stack
                    direction='row'
                    justifyContent='end'
                    alignItems='center'
                  >
                    <Typography
                      variant='subtitle1'
                      component={Link}
                      to='/auth/forgotpassword'
                      color='text.primary'
                      sx={{ marginLeft: 'auto' }}
                    >
                      Forgot Password?
                    </Typography>
                  </Stack>
                </Grid>
                {errors.submit && (
                  <Grid item xs={12}>
                    <FormHelperText error>{errors.submit}</FormHelperText>
                  </Grid>
                )}
                <Grid item xs={12}>
                  <Button
                    disableElevation
                    disabled={isSubmitting}
                    fullWidth
                    size='large'
                    type='submit'
                    variant='contained'
                    color='primary'
                    sx={{ height: '55px' }}
                  >
                    {userLoading ? (
                      <CircularProgress
                        size={25}
                        sx={{
                          color: 'inherit',
                        }}
                      />
                    ) : (
                      'Login'
                    )}
                  </Button>
                </Grid>
                <Grid item xs={12} sx={{ mt: -1 }}>
                  <Stack
                    direction='row'
                    justifyContent='center'
                    alignItems='end'
                    spacing={2}
                  >
                    <Typography variant='subtitle1'>
                      Don&apos;t have account?
                    </Typography>
                    <Link
                      variant='subtitle1'
                      to='/auth/register'
                      component={RouterLink}
                      sx={{ textDecoration: 'none' }}
                    >
                      Register
                    </Link>
                  </Stack>
                </Grid>
              </Grid>
            </form>
          )}
        </Formik>
      </Box>
      <OTPModal
        open={showOTPDialog}
        handleClose={toggleOTPDialog}
        isVerifyingOTp={isVerifyingOTp}
        otp={otp}
        setOTP={setOtp}
        onSuccess={handleVerifyOTP}
        handleCancel={toggleOTPDialog}
        isResending={isResending}
      />
    </>
  );
};

export default Login;
