import {
  Avatar,
  Button,
  CircularProgress,
  Container,
  Divider,
  FormHelperText,
  Grid,
  OutlinedInput,
  Stack,
  Typography,
} from '@mui/material';
import { grey } from '@mui/material/colors';
import { Formik } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import { origin } from '../api';

import { useState } from 'react';
import { toast } from 'react-toastify';
import * as Yup from 'yup';
import Payment from '../components/checkout/Payment';
import { saveShippingInfo } from '../store/reducers/auth/extraReducers';

const CheckoutPage = () => {
  const { items } = useSelector((st) => st.cart);
  const { loading } = useSelector((st) => st.auth);
  const [makePayment, setMakePayment] = useState(false);

  const dispatch = useDispatch();

  const calcCartTotal = () => {
    let total = 0;
    items.forEach((item) => {
      total += item.quantity * item.price;
    });
    return total;
  };

  return (
    <>
      <Container maxWidth='lg'>
        <Typography variant='h4' sx={{ mb: 4 }}>
          Checkout
        </Typography>
        <Grid container spacing={5}>
          <Grid item xs={12} sm={6}>
            {!makePayment ? (
              <Formik
                initialValues={{
                  addressLine1: '',
                  addressLine2: '',
                  city: '',
                  state: '',
                  country: '',
                  postalCode: '',
                }}
                validationSchema={Yup.object().shape({
                  addressLine1: Yup.string()
                    .min('5', 'Address should be valid (min length 5)')
                    .required('Address is required'),
                  addressLine2: Yup.string(),
                  country: Yup.string()
                    .min('3', 'Country should be valid (min length 3)')
                    .required('Country is required'),
                  state: Yup.string()
                    .min('3', 'State should be valid (min length 3)')
                    .required('State is required'),
                  city: Yup.string()
                    .min('3', 'City should be valid (min length 3)')
                    .required('City is required'),
                  postalCode: Yup.number().required(),
                })}
                onSubmit={async (values, { setSubmitting }) => {
                  if (!import.meta.env.VITE_API_ORIGIN)
                    return toast.error('Stripe Payment Key Not found');
                  setMakePayment(true);

                  dispatch(saveShippingInfo(values)).then((res) => {
                    if (res.meta.requestStatus === 'fulfilled')
                      setMakePayment(true);
                  });
                  setSubmitting(true);
                }}
              >
                {({
                  errors,
                  handleBlur,
                  handleChange,
                  handleSubmit,
                  touched,
                  values,
                  isSubmitting,
                }) => (
                  <form noValidate onSubmit={handleSubmit}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Stack spacing={1}>
                          <Typography variant='subtitle1'>
                            Address{` `}
                            <span className='requiredField'>*</span>
                          </Typography>
                          <OutlinedInput
                            id='addressLine1-checkout'
                            value={values.addressLine1}
                            name='addressLine1'
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder='Address Line 1'
                            fullWidth
                            multiline
                            rows={3}
                            error={Boolean(
                              touched.addressLine1 && errors.addressLine1
                            )}
                          />
                          {touched.addressLine1 && errors.addressLine1 && (
                            <FormHelperText
                              error
                              id='standard-weight-helper-text-addressLine1-login'
                            >
                              {errors.addressLine1}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>
                      <Grid item xs={12}>
                        <Stack spacing={1}>
                          <Typography variant='subtitle1'>
                            Alternate Address{' '}
                          </Typography>
                          <OutlinedInput
                            id='addressLine2-checkout'
                            value={values.addressLine2}
                            name='addressLine2'
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder='Address Line 2 (optional)'
                            fullWidth
                            error={Boolean(
                              touched.addressLine2 && errors.addressLine2
                            )}
                            multiline
                            rows={3}
                          />
                          {touched.addressLine2 && errors.addressLine2 && (
                            <FormHelperText
                              error
                              id='standard-weight-helper-text-addressLine2-login'
                            >
                              {errors.addressLine2}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <Stack spacing={1}>
                          <Typography variant='subtitle1'>
                            City {` `}
                            <span className='requiredField'>*</span>
                          </Typography>
                          <OutlinedInput
                            id='city-checkout'
                            value={values.city}
                            name='city'
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder='City'
                            fullWidth
                            error={Boolean(touched.city && errors.city)}
                          />
                          {touched.city && errors.city && (
                            <FormHelperText
                              error
                              id='standard-weight-helper-text-city-login'
                            >
                              {errors.city}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <Stack spacing={1}>
                          <Typography variant='subtitle1'>
                            State {` `}
                            <span className='requiredField'>*</span>
                          </Typography>
                          <OutlinedInput
                            id='state-checkout'
                            value={values.state}
                            name='state'
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder='State'
                            fullWidth
                            error={Boolean(touched.state && errors.state)}
                          />
                          {touched.state && errors.state && (
                            <FormHelperText
                              error
                              id='standard-weight-helper-text-state-login'
                            >
                              {errors.state}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <Stack spacing={1}>
                          <Typography variant='subtitle1'>
                            Country {` `}
                            <span className='requiredField'>*</span>
                          </Typography>
                          <OutlinedInput
                            id='country-checkout'
                            value={values.country}
                            name='country'
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder='Country'
                            fullWidth
                            error={Boolean(touched.country && errors.country)}
                          />
                          {touched.country && errors.country && (
                            <FormHelperText
                              error
                              id='standard-weight-helper-text-country-login'
                            >
                              {errors.country}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <Stack spacing={1}>
                          <Typography variant='subtitle1'>
                            Postal Code {` `}
                            <span className='requiredField'>*</span>
                          </Typography>
                          <OutlinedInput
                            id='postalCode-checkout'
                            value={values.postalCode}
                            name='postalCode'
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder='Postal Code'
                            fullWidth
                            type={'number'}
                            error={Boolean(
                              touched.postalCode && errors.postalCode
                            )}
                          />
                          {touched.postalCode && errors.postalCode && (
                            <FormHelperText
                              error
                              id='standard-weight-helper-text-postalCode-login'
                            >
                              {errors.postalCode}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>
                      <Grid item xs={12}>
                        <Button
                          disableElevation
                          disabled={isSubmitting}
                          fullWidth
                          size='large'
                          type='submit'
                          variant='contained'
                          color='primary'
                          sx={{ height: '55px', mt: 2 }}
                        >
                          {loading ? (
                            <CircularProgress
                              size={25}
                              sx={{
                                color: 'inherit',
                              }}
                            />
                          ) : (
                            'Proceed to Payment'
                          )}
                        </Button>
                      </Grid>
                    </Grid>
                  </form>
                )}
              </Formik>
            ) : (
              <Payment products={items} />
            )}
          </Grid>
          <Grid item xs={12} sm={6}>
            <Stack spacing={4} mt={2} mb={5}>
              {items?.map((el) => (
                <Stack
                  key={el.id}
                  direction='row'
                  spacing={4}
                  alignItems={'stretch'}
                  justifyContent={'space-between'}
                >
                  <Avatar
                    variant='rounded'
                    src={`${origin}${el?.image}`}
                    alt={el.name}
                    sx={{
                      width: 80,
                      height: 80,
                      '& img': {
                        objectFit: 'contain',
                      },
                    }}
                  />
                  <Stack justifyContent={'space-between'} flex={1}>
                    <Typography variant='h6' color='action'>
                      {el.name}
                    </Typography>
                    <Typography variant='subtitle2'>
                      Quantity : {el.quantity}
                    </Typography>
                  </Stack>
                  <Typography variant='h4'>${el.price}</Typography>
                </Stack>
              ))}
            </Stack>
            <Stack
              p={2}
              border={`1px solid ${grey[300]}`}
              borderRadius={'12px'}
            >
              <Typography variant='h5'>Shipping Details</Typography>
              <Stack mt={4} spacing={1.5}>
                <Stack
                  direction={'row'}
                  justifyContent={'space-between'}
                  alignItems={'center'}
                >
                  <Typography variant='body1'>Sub Total</Typography>
                  <Typography variant='subtitle1'>
                    ${calcCartTotal()}
                  </Typography>
                </Stack>
                <Stack
                  direction={'row'}
                  justifyContent={'space-between'}
                  alignItems={'center'}
                >
                  <Typography variant='body1'>Shipping Fee</Typography>
                  <Typography variant='subtitle1'>$10</Typography>
                </Stack>
                <Divider />
                <Stack
                  direction={'row'}
                  justifyContent={'space-between'}
                  alignItems={'center'}
                >
                  <Typography variant='body1'>Total</Typography>
                  <Typography variant='subtitle1'>
                    ${calcCartTotal() + 10}
                  </Typography>
                </Stack>
                <Stack mt={6}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} sm={6}></Grid>
                  </Grid>
                </Stack>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Container>
    </>
  );
};

export default CheckoutPage;
