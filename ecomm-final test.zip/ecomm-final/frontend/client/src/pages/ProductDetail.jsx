import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import {
  Button,
  CircularProgress,
  Container,
  Grid,
  Stack,
  Typography,
} from '@mui/material';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import axiosInstance, { errorResponse } from '../api';
import ProductGallery from '../components/ProductGallery';
import { addItem } from '../store/reducers/cart';

const ProductDetailPage = () => {
  const { id } = useParams();

  const [fetching, setFetching] = useState(true);
  const [product, setProduct] = useState(null);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    if (!id) return navigate('/products');
    (async () => {
      setFetching(true);
      try {
        const resp = await axiosInstance.get(`/products/${id}`);
        setProduct(resp.data.product);
      } catch (er) {
        toast.error(errorResponse(er).message);
      } finally {
        setFetching(false);
      }
    })();
  }, [id, navigate]);

  const handleAddToCart = () => {
    dispatch(
      addItem({
        id: product.id,
        name: product.name,
        image: product.images?.[0] || '',
        quantity: 1,
        price: product.price,
      })
    );
  };

  return (
    <>
      <Container maxWidth='lg'>
        <Typography variant='h4' sx={{ mb: 4 }}>
          Product Detail
        </Typography>
        {fetching ? (
          <Stack
            alignItems={'center'}
            justifyContent={'center'}
            sx={{ height: { xs: '300px', md: '500px' } }}
          >
            <CircularProgress size={25} />
          </Stack>
        ) : (
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <ProductGallery name={product.name} images={product.images} />
            </Grid>
            <Grid item xs={12} md={6}>
              <Stack spacing={'50px'} alignItems={'flex-start'}>
                <Stack
                  direction={'row'}
                  alignItems={'flex-start'}
                  justifyContent={'space-between'}
                  gap={'20px'}
                  width='100%'
                >
                  <Stack spacing={'7px'}>
                    <Typography variant='h3'>{product.name}</Typography>
                    <Typography
                      variant='h5'
                      color='textSecondary'
                      sx={{ textTransform: 'uppercase' }}
                    >
                      {product.category.name}
                    </Typography>
                  </Stack>
                  <Typography variant='h3'>${product.price}</Typography>
                </Stack>
                <Stack spacing={'10px'}>
                  <Typography variant='subtitle1'>Description</Typography>
                  <Typography variant='body1'>{product.description}</Typography>
                </Stack>
                <Stack spacing={'10px'}>
                  <Typography variant='subtitle1'>Quantity</Typography>
                  <Typography variant='body1'>{product.inventory}</Typography>
                </Stack>
                <Button
                  variant='contained'
                  size='large'
                  onClick={handleAddToCart}
                  fullWidth
                  startIcon={<ShoppingCartIcon sx={{ mr: 2 }} />}
                >
                  Add to Cart
                </Button>
              </Stack>
            </Grid>
          </Grid>
        )}
      </Container>
    </>
  );
};

export default ProductDetailPage;
