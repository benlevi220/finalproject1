import InventoryIcon from '@mui/icons-material/Inventory';
import { Box, Button, Container, Grid, Stack, Typography } from '@mui/material';
import bannerImg from '../assets/banner2.jpg';
import HomeFeaturedCats from '../components/home/featuredCats';
import HomeProducts from '../components/home/products';

const HomePage = () => {
  return (
    <>
      <header>
        <Box
          sx={{
            backgroundPosition: 'center right',
            backgroundRepeat: 'no-repeat',
            backgroundImage: `url(${bannerImg})`,
            backgroundSize: 'cover',
            height: { xs: '500px', sm: '600px', md: '700px' },
          }}
        >
          <Container maxWidth='lg' sx={{ height: '100%' }}>
            <Stack
              spacing={'24px'}
              height='-webkit-fill-available'
              justifyContent={'center'}
              py={'1.5rem'}
              maxWidth='590px'
              alignItems={'flex-start'}
            >
              <Typography variant='h1'>
                Discover the Latest Products and Promotions
              </Typography>
              <Typography variant='h5' sx={{ fontWeight: 400 }}>
                Shop our wide range of high-quality products and enjoy exclusive
                deals.
              </Typography>
              <Button variant='contained' size='large'>
                Shop Now
              </Button>
            </Stack>
          </Container>
        </Box>
      </header>
      <Container maxWidth='lg'>
        <Box component={'main'} mt={10}>
          <Typography variant='h3' sx={{ mb: 4, maxWidth: '30ch' }}>
            Discover the benefits of Shopping with Us
          </Typography>
          <Grid container spacing={7}>
            <Grid item xs={12} sm={6} md={4}>
              <Stack spacing={2}>
                <Stack alignItems={'center'} direction={'row'} gap={1.5}>
                  <InventoryIcon fontSize='large' />
                  <Typography variant='h5'>Easy Returns</Typography>
                </Stack>
                <Typography variant='body1'>
                  Enjoy free shipping on all orders and get your items delivered
                  right to your doorstep.
                </Typography>
              </Stack>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Stack spacing={2}>
                <Stack alignItems={'center'} direction={'row'} gap={1.5}>
                  <InventoryIcon fontSize='large' />
                  <Typography variant='h5'>Shop with Confidence</Typography>
                </Stack>
                <Typography variant='body1'>
                  We offer a variety of secure payment options to ensure your
                  personal and financial information is protected.
                </Typography>
              </Stack>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Stack spacing={2}>
                <Stack alignItems={'center'} direction={'row'} gap={1.5}>
                  <InventoryIcon fontSize='large' />
                  <Typography variant='h5'>24/7 Customer Support</Typography>
                </Stack>
                <Typography variant='body1'>
                  Our dedicated customer support team is always ready to assist
                  you with any questions or concerns.
                </Typography>
              </Stack>
            </Grid>
          </Grid>
        </Box>
        <HomeProducts />
        <HomeFeaturedCats />
      </Container>
    </>
  );
};

export default HomePage;
