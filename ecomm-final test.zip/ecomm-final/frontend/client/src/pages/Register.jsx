/* eslint-disable no-unused-vars */
import { Formik } from 'formik';
import * as Yup from 'yup';

import {
  Box,
  Button,
  CircularProgress,
  FormHelperText,
  Grid,
  IconButton,
  InputAdornment,
  Link,
  OutlinedInput,
  Stack,
  Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink, useLocation, useNavigate } from 'react-router-dom';

// import CustomTypo from '../components/common/CustomTypo';
// import InlineLink from '../components/common/Link';

import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { toast } from 'react-toastify';
import axiosInstance, { errorResponse } from '../api';
import OTPModal from '../dialogs/OtpScreen';
import { register } from '../store/reducers/auth/extraReducers';
// import { toast } from 'react-toastify';
// import { verifySignupEmail } from '../api/verify';
// import OTPModal from '../dialogs/OtpScreen';
// import { loginUser } from '../store/slices/auth';
// import { getCart } from '../store/slices/cart/extraReducers';
// import { getMyFav } from '../store/slices/favourite/extraReducers';

const Register = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [isOtpModalOpen, setIsOtpModalOpen] = useState(false);
  const [otp, setOtp] = useState('');

  const [isVerifyingOTp, setIsVerifyingOTp] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [email, setEmail] = useState('');
  const { user } = useSelector((st) => st.auth);

  const handleClose = () => {
    setIsOtpModalOpen(false);
  };

  // const handleSubmitOtp = async (otp) => {
  //   try {
  //     setIsVerifyingOTp(true);

  //     const { data } = await verifySignupEmail(otp, email);
  //     localStorage.setItem('userData', JSON.stringify(data));
  //     dispatch(loginUser(data));
  //     dispatch(getMyFav());
  //     dispatch(getCart());
  //     dispatch(getShippingDetails());
  //     location.search !== ''
  //       ? navigate(`${redirect}`)
  //       : navigate('/listing/create');
  //     toast.success('Email verified successfully');
  //     ReactGA.event({
  //       category: 'User',
  //       action: 'Created an Account',
  //     });
  //   } catch (error) {
  //     toast.error(
  //       error?.response?.data?.message ||
  //         error.message ||
  //         typeof error === 'string'
  //         ? error
  //         : 'Something went wrong'
  //     );
  //   } finally {
  //     setIsVerifyingOTp(false);
  //   }
  // };

  const handleVerifyOTP = async (otp) => {
    setIsVerifyingOTp(true);
    await axiosInstance
      .post('/otp/verify-otp', { otp })
      .then((res) => {
        toast.success(res.data.message);
        handleClose();
        navigate('/auth/login');
      })
      .catch((err) => {
        toast.error(errorResponse(err).message);
      })
      .finally(() => setIsVerifyingOTp(false));
  };

  useEffect(() => {
    if (user) navigate('/');
  }, [user]);

  const [showPassword, setShowPassword] = React.useState({
    password: false,
    passwordConfirm: false,
  });
  const [loading, setLoading] = React.useState(false);
  const handleClickShowPassword = (e) => {
    const { fieldname } = e.currentTarget.dataset;

    setShowPassword((st) => ({
      ...st,
      [fieldname]: !st[fieldname],
    }));
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  return (
    <>
      <Formik
        initialValues={{
          email: '',
          firstName: '',
          lastName: '',
          password: '',
          submit: null,
        }}
        validationSchema={Yup.object().shape({
          email: Yup.string()
            .email('Must be a valid email')
            .max(255)
            .required('Email is required'),
          name: Yup.string().max(80).min(3).required('Full Name is required'),
          password: Yup.string().max(255).required('Password is required'),
          passwordConfirm: Yup.string()
            .required('Enter confirm password')
            .oneOf([Yup.ref('password'), null], 'Passwords must match'),
        })}
        onSubmit={async (values, { setErrors, setStatus, setSubmitting }) => {
          setSubmitting(true);
          setLoading(true);
          const { passwordConfirm, ...newObj } = values;
          setEmail(newObj.email);
          dispatch(register(newObj)).then((res) => {
            setLoading(false);
            if (res.meta.requestStatus === 'fulfilled') {
              setSubmitting(false);
              toast.success('Email sent, please verify your email');
              setIsOtpModalOpen(true);
              // navigate('/login');
            }
          });
          try {
            setStatus({ success: false });
            setSubmitting(false);
          } catch (err) {
            setStatus({ success: false });
            setErrors({ submit: err.message });
            setSubmitting(false);
          }
        }}
      >
        {({
          errors,
          handleBlur,
          handleChange,
          handleSubmit,
          isSubmitting,
          touched,
          values,
        }) => (
          <form noValidate onSubmit={handleSubmit}>
            <Grid container spacing={4}>
              <Grid item xs={12}>
                <Stack spacing={1}>
                  <Typography variant='subtitle1'>Full Name</Typography>
                  <OutlinedInput
                    id='name-login'
                    value={values.name}
                    name='name'
                    onBlur={handleBlur}
                    onChange={handleChange}
                    placeholder='enter name'
                    fullWidth
                    error={Boolean(touched.name && errors.name)}
                  />
                  {touched.name && errors.name && (
                    <FormHelperText
                      error
                      id='standard-weight-helper-text-name-login'
                    >
                      {errors.name}
                    </FormHelperText>
                  )}
                </Stack>
              </Grid>
              <Grid item xs={12}>
                <Stack spacing={1}>
                  <Typography variant='subtitle1'>Email Address</Typography>
                  <OutlinedInput
                    id='email-login'
                    type='email'
                    value={values.email}
                    name='email'
                    onBlur={handleBlur}
                    onChange={handleChange}
                    placeholder='Enter email address'
                    fullWidth
                    error={Boolean(touched.email && errors.email)}
                  />
                  {touched.email && errors.email && (
                    <FormHelperText
                      error
                      id='standard-weight-helper-text-email-login'
                    >
                      {errors.email}
                    </FormHelperText>
                  )}
                </Stack>
              </Grid>

              <Grid item xs={12}>
                <Stack spacing={1}>
                  <Typography variant='subtitle1'>Password</Typography>
                  <OutlinedInput
                    fullWidth
                    error={Boolean(touched.password && errors.password)}
                    id='-password-login'
                    type={showPassword.password ? 'text' : 'password'}
                    value={values.password}
                    name='password'
                    onBlur={handleBlur}
                    onChange={handleChange}
                    endAdornment={
                      <InputAdornment position='end'>
                        <IconButton
                          data-fieldname='password'
                          aria-label='toggle password visibility'
                          onClick={handleClickShowPassword}
                          onMouseDown={handleMouseDownPassword}
                          edge='end'
                          size='large'
                        >
                          {showPassword ? (
                            <VisibilityIcon />
                          ) : (
                            <VisibilityOffIcon />
                          )}
                        </IconButton>
                      </InputAdornment>
                    }
                    placeholder='Enter password'
                  />
                  {touched.password && errors.password && (
                    <FormHelperText
                      error
                      id='standard-weight-helper-text-password-login'
                    >
                      {errors.password}
                    </FormHelperText>
                  )}
                </Stack>
              </Grid>
              <Grid item xs={12}>
                <Stack spacing={1}>
                  <Typography variant='subtitle1'>Confirm Password</Typography>
                  <OutlinedInput
                    fullWidth
                    error={Boolean(
                      touched.passwordConfirm && errors.passwordConfirm
                    )}
                    id='passwordConfirm-register'
                    type={showPassword.passwordConfirm ? 'text' : 'password'}
                    value={values.passwordConfirm}
                    name='passwordConfirm'
                    onBlur={handleBlur}
                    onChange={handleChange}
                    endAdornment={
                      <InputAdornment position='end'>
                        <IconButton
                          aria-label='toggle passwordConfirm visibility'
                          data-fieldname='passwordConfirm'
                          onClick={handleClickShowPassword}
                          onMouseDown={handleMouseDownPassword}
                          edge='end'
                          size='large'
                        >
                          {showPassword ? (
                            <VisibilityIcon />
                          ) : (
                            <VisibilityOffIcon />
                          )}
                        </IconButton>
                      </InputAdornment>
                    }
                    placeholder='Enter passwordConfirm'
                  />
                  {touched.passwordConfirm && errors.passwordConfirm && (
                    <FormHelperText
                      error
                      id='standard-weight-helper-text-passwordConfirm-register'
                    >
                      {errors.passwordConfirm}
                    </FormHelperText>
                  )}
                </Stack>
              </Grid>
              {errors.submit && (
                <Grid item xs={12}>
                  <FormHelperText error>{errors.submit}</FormHelperText>
                </Grid>
              )}
              <Grid item xs={12}>
                <Button
                  disableElevation
                  disabled={isSubmitting}
                  fullWidth
                  size='large'
                  type='submit'
                  variant='contained'
                  color='primary'
                >
                  {loading ? (
                    <CircularProgress size={25} sx={{ color: 'inherit' }} />
                  ) : (
                    'Register'
                  )}
                </Button>
              </Grid>
              <Grid item xs={12} sx={{ mt: -1 }}>
                <Stack
                  direction='row'
                  justifyContent='center'
                  alignItems='end'
                  spacing={2}
                >
                  <Typography variant='body1'>Already have account?</Typography>
                  <Link
                    variant='subtitle1'
                    component={RouterLink}
                    to='/auth/login'
                  >
                    Login
                  </Link>
                </Stack>
              </Grid>
            </Grid>
          </form>
        )}
      </Formik>
      <OTPModal
        open={isOtpModalOpen}
        handleClose={handleClose}
        isVerifyingOTp={isVerifyingOTp}
        otp={otp}
        setOTP={setOtp}
        onSuccess={handleVerifyOTP}
        handleCancel={handleClose}
        isResending={isResending}
      />
    </>
  );
};
export default Register;
