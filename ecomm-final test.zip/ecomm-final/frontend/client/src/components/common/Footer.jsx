import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import XIcon from '@mui/icons-material/X';
import { Container, Divider, Stack, Typography } from '@mui/material';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <>
      <Divider />
      <Container maxWidth='lg' sx={{ py: 3 }}>
        <Stack
          sx={{
            flexDirection: { xs: 'column', md: 'row' },
          }}
          gap={'20px'}
          alignItems={'flex-start'}
          justifyContent={'space-between'}
        >
          <Stack spacing={'15px'}>
            <Typography
              variant='h4'
              noWrap
              sx={{
                letterSpacing: '.2rem',
                color: 'inherit',
              }}
            >
              SHOPNOW
            </Typography>
            <Typography variant='body1' sx={{ maxWidth: '60ch' }}>
              Discover a curated selection of top-quality products at unbeatable
              prices. Our commitment to customer satisfaction drives us to offer
              an exceptional shopping experience, backed by secure payments and
              fast shipping. Join our community and stay updated with the latest
              arrivals and exclusive offers.
            </Typography>
          </Stack>
          <Stack spacing={3}>
            <Typography variant='h6'>Menu</Typography>
            {footerLinks.map((el) => (
              <Typography
                variant='body1'
                component={Link}
                href={el.url}
                key={el.id}
              >
                {el.label}
              </Typography>
            ))}
          </Stack>
          <Stack spacing={2}>
            <Typography variant='h6'>Follow Us</Typography>
            <Stack gap={'20px'} alignItems={'stretch'} justifyContent={'flex'}>
              <Stack direction={'row'} alignItems={'center'} gap={'10px'}>
                <FacebookIcon />
                <Typography variant='body1'>Facebook</Typography>
              </Stack>
              <Stack direction={'row'} alignItems={'center'} gap={'10px'}>
                <InstagramIcon />
                <Typography variant='body1'>Instagram</Typography>
              </Stack>
              <Stack direction={'row'} alignItems={'center'} gap={'10px'}>
                <XIcon />
                <Typography variant='body1'>Twitter</Typography>
              </Stack>
            </Stack>
          </Stack>
        </Stack>
      </Container>
      <Divider />
      <Container maxWidth='lg' sx={{ py: 3 }}>
        <Typography variant='body2'>
          © 2024 Relume. All rights reserved.
        </Typography>
      </Container>
    </>
  );
};

const footerLinks = [
  { id: 'products', label: 'Products', url: '/products' },
  { id: 'about', label: 'About Us', url: '/about-us' },
  { id: 'contact', label: 'Contact Us', url: '/contact-us' },
];

export default Footer;
