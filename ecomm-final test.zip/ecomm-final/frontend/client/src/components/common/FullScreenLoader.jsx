import { CircularProgress, Stack, Typography } from '@mui/material';

const FullScreenLoader = () => {
  return (
    <Stack
      gap={'10px'}
      alignItems={'center'}
      justifyContent={'center'}
      height={'100%'}
      width='100%'
      zIndex={999}
    >
      <Typography
        variant='h5'
        noWrap
        sx={{
          letterSpacing: '.2rem',
        }}
      >
        SHOPNOW
      </Typography>
      <CircularProgress size={20} />
    </Stack>
  );
};

export default FullScreenLoader;
