import MenuIcon from '@mui/icons-material/Menu';
import { Stack } from '@mui/material';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import { grey } from '@mui/material/colors';
import Container from '@mui/material/Container';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import * as React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import CartDrawer from '../CartDrawer';
import FavDrawer from '../FavoriteDrawer';
import UserAvatarMenu from '../UserAvatarMenu';

const pages = ['Products', 'Pricing', 'Blog'];

function Navbar() {
  const { user } = useSelector((st) => st.auth);
  const [anchorElNav, setAnchorElNav] = React.useState(null);

  const handleOpenNavMenu = (event) => setAnchorElNav(event.currentTarget);
  const handleCloseNavMenu = () => setAnchorElNav(null);

  return (
    <AppBar
      position='static'
      color='transparent'
      elevation={0}
      sx={{ borderBottom: `1px solid ${grey[300]}` }}
    >
      <Container maxWidth='lg'>
        <Toolbar disableGutters>
          <Typography
            variant='h4'
            noWrap
            component='a'
            href='/'
            sx={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontWeight: 700,
              letterSpacing: '.2rem',
            }}
          >
            SHOPNOW
          </Typography>
          {/* Mobile Menu */}
          {/* Sidebar */}
          <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
            <IconButton
              size='large'
              aria-label='account of current user'
              aria-controls='menu-appbar'
              aria-haspopup='true'
              onClick={handleOpenNavMenu}
              color='inherit'
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id='menu-appbar'
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: 'block', md: 'none' },
              }}
            >
              {pages.map((page) => (
                <MenuItem key={page} onClick={handleCloseNavMenu}>
                  <Typography textAlign='center'>{page}</Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>
          {/* logo */}
          <Typography
            variant='h5'
            noWrap
            component='a'
            href='/'
            sx={{
              mr: 2,
              display: { xs: 'flex', md: 'none' },
              flexGrow: 1,
              letterSpacing: '.2rem',
            }}
          >
            SHOPNOW
          </Typography>
          {/* pages */}
          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {pages.map((page) => (
              <Button
                key={page}
                onClick={handleCloseNavMenu}
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                {page}
              </Button>
            ))}
          </Box>
          <Stack
            direction='row'
            alignItems={'center'}
            gap={'5px'}
            sx={{ flexGrow: 0 }}
          >
            {user && <FavDrawer />}
            <CartDrawer />
            {!user ? (
              <Stack direction={'row'} gap={1}>
                <Button variant='contained' component={Link} to={'/auth/login'}>
                  Login
                </Button>
                <Button
                  variant='contained'
                  component={Link}
                  to={'/auth/register'}
                >
                  Register
                </Button>
              </Stack>
            ) : (
              <UserAvatarMenu />
            )}
          </Stack>
        </Toolbar>
      </Container>
    </AppBar>
  );
}
export default Navbar;
