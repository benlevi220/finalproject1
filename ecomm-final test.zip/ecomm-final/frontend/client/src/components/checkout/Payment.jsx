import { Stack, Typography } from '@mui/material';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import axiosInstance, { errorResponse, origin } from '../../api';
import { dispatch } from '../../store';
import { clearCart } from '../../store/reducers/cart';
import CheckoutForm from './checkoutForm';

const Payment = ({ products }) => {
  const [stripePromise, setStripePromise] = useState(null);
  const [clientSecret, setClientSecret] = useState('');
  const currency = 'USD';
  const navigate = useNavigate();

  const calcCartTotal = () => {
    let total = 0;
    products.forEach((item) => {
      total += item.quantity * item.price;
    });
    return total;
  };

  useEffect(() => {
    fetch(`${origin}/config`).then(async (r) => {
      const { publishableKey } = await r.json();
      setStripePromise(loadStripe(publishableKey));
    });
  }, []);

  useEffect(() => {
    fetch(`${origin}/create-payment-intents`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: (products.length > 0 ? calcCartTotal() : 0).toFixed(0),
        currency: currency,
      }),
    }).then(async (r) => {
      const { clientSecret } = await r.json();
      setClientSecret(clientSecret);
    });
  }, []);

  const handleCreateOrder = async (paymentId) => {
    await axiosInstance
      .post('/orders', {
        orderItems: products,
        paymentId,
        total: calcCartTotal(),
      })
      .then(() => {
        dispatch(clearCart());
        toast.success('Order created successfully');
        navigate('/');
      })
      .catch((er) => {
        toast.error(errorResponse(er).message);
      });
  };
  return (
    <>
      <Typography variant='h6' sx={{ fontWeight: 500 }}>
        Payment Method
      </Typography>
      <Typography variant='body2' sx={{ mb: 3 }}>
        All transactions are secure and encrypted.
      </Typography>
      <Stack mb={3}>
        {clientSecret && stripePromise && (
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <CheckoutForm handleNext={handleCreateOrder} />
          </Elements>
        )}
      </Stack>
    </>
  );
};

export default Payment;
