import { Box, CircularProgress, Typography } from '@mui/material';
import {
  PaymentElement,
  useElements,
  useStripe,
} from '@stripe/react-stripe-js';
import { useState } from 'react';
import { toast } from 'react-toastify';
// import SpiralLoader from '../common/SpiralLoader';
export default function CheckoutForm({ handleNext }) {
  const [message, setMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(true);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) {
      return;
    }
    setIsProcessing(true);
    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/products`,
      },
      redirect: 'if_required',
    });

    if (paymentIntent?.status == 'succeeded') {
      console.log('paymentIntent', paymentIntent);
      toast.success('Payment Successfull');
      setMessage('Payment Status: Payment Successfull');
      return handleNext(paymentIntent?.id);
    } else if (
      error?.type == 'card_error' ||
      error?.type == 'validation_error'
    ) {
      toast.error('Error Occured During Payment:' + error.message);
      setMessage(error.message);
    } else {
      setMessage('Unexpected Error Occured' + paymentIntent.status);
    }
    setIsProcessing(false);
  };
  setTimeout(() => {
    setIsLoading(false);
  }, 2000);

  return (
    <>
      {isLoading ? (
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            minHeight: '300px',
          }}
        >
          <CircularProgress size={25} />
        </div>
      ) : (
        <Box marginTop={5}>
          <form onSubmit={handleSubmit} id='payment-form'>
            <PaymentElement />
            <button
              style={{
                padding: '12px 75px',
                marginTop: '20px',
                backgroundColor: '#0F172A',
                color: '#fff',
                borderRadius: '10px',
              }}
              disabled={isProcessing || !stripe || !elements}
              id='submit'
            >
              <span
                id='button-text'
                style={{ fontSize: '15px', cursor: 'pointer' }}
              >
                {isProcessing ? 'Processing ...' : 'Pay & Continue'}
              </span>
            </button>
            {message && (
              <Box>
                <Typography>{message}</Typography>{' '}
              </Box>
            )}
          </form>
        </Box>
      )}
    </>
  );
}
