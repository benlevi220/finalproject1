import { Close } from '@mui/icons-material';
import FavoriteIcon from '@mui/icons-material/Favorite';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import {
  Avatar,
  Badge,
  CircularProgress,
  IconButton,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import { grey } from '@mui/material/colors';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import * as React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { origin } from '../api';
import { removeFromFavorite } from '../store/reducers/favorite/extraReducers';

export default function FavDrawer() {
  const { favorites, fetching } = useSelector((st) => st.favorite);
  const dispatch = useDispatch();

  const [open, setOpen] = React.useState(false);

  const toggleDrawer = (newOpen) => () => setOpen(newOpen);

  const handleRemoveFromFav = (id) => () =>
    dispatch(removeFromFavorite(id));

  return (
    <div>
      <Tooltip title='Cart'>
        <IconButton onClick={toggleDrawer(true)}>
          <Badge badgeContent={`${favorites?.length}`} color='primary'>
            <FavoriteIcon color='action' />
          </Badge>
        </IconButton>
      </Tooltip>
      <Drawer open={open} anchor='right' onClose={toggleDrawer(false)}>
        <Stack sx={{ width: 370, height: '100%' }} role='presentation'>
          <List>
            <ListItem>
              <Stack
                direction='row'
                alignItems={'center'}
                justifyContent={'space-between'}
                width='100%'
              >
                <Typography variant='h4'>My Favorites</Typography>
                <IconButton size='small' onClick={toggleDrawer(false)}>
                  <Close />
                </IconButton>
              </Stack>
            </ListItem>
          </List>
          <Divider />
          <List sx={{ mt: 2, flex: 1 }}>
            {fetching ? (
              <Stack
                height={'300px'}
                alignItems={'center'}
                justifyContent={'center'}
              >
                <CircularProgress size={20} />
              </Stack>
            ) : favorites.length > 0 ? (
              favorites.map((item) => (
                <ListItem key={item.id} sx={{ mb: 2 }}>
                  <Stack
                    direction='row'
                    alignItems={'stretch'}
                    gap={'15px'}
                    justifyContent={'space-between'}
                    width='100%'
                  >
                    <Avatar
                      variant='square'
                      src={`${origin}${item.images[0]}`}
                      alt={item.name}
                      sx={{
                        width: 70,
                        height: 70,
                        border: `1px solid ${grey[300]}`,
                        flexShrink: 0,
                        flexgrow: 0,
                        '& img': {
                          objectFit: 'contain',
                        },
                      }}
                    />
                    <Stack flex={1} justifyContent={'space-between'}>
                      <Typography variant='h6'>{item.name}</Typography>
                      <Typography variant='h6'>${item.price}</Typography>
                    </Stack>
                    <IconButton
                      size='small'
                      onClick={handleRemoveFromFav(item.id)}
                      sx={{ height: 'fit-content', width: 'fit-content' }}
                    >
                      <HighlightOffIcon />
                    </IconButton>
                  </Stack>
                </ListItem>
              ))
            ) : (
              <Stack
                height={'300px'}
                alignItems={'center'}
                justifyContent={'center'}
              >
                <Typography variant='h6'>No Items in a Favorites</Typography>
              </Stack>
            )}
          </List>
        </Stack>
      </Drawer>
    </div>
  );
}
