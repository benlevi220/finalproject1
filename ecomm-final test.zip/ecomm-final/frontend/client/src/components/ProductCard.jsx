import FavoriteIcon from '@mui/icons-material/Favorite';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import { Box, IconButton, Stack, Typography } from '@mui/material';
import { Link } from 'react-router-dom';

const ProductCard = ({
  image,
  title,
  price,
  isFav = false,
  isReadOnly = false,
  id,
  handleFav,
}) => {
  return (
    <>
      <Stack
        borderRadius={'12px'}
        spacing={'15px'}
        className='cursorPointer'
        maxWidth={'280px'}
        p={1.5}
        sx={{
          border: (theme) => `1px solid ${theme.palette.divider}`,
        }}
      >
        <Box
          sx={{
            overflow: 'hidden',
            position: 'relative',
            aspectRatio: 0.84,
            width: '100%',
            maxWidth: '280px',
            borderRadius: '15px',
          }}
        >
          <img
            src={image}
            alt='image'
            width={'100%'}
            height={'100%'}
            style={{
              inset: 0,
              objectFit: 'contain',
              objectPosition: 'center',
            }}
          />
          <IconButton
            sx={{
              position: 'absolute',
              top: 0,
              right: 0,
              '&, &:hover': {
                backgroundColor: (theme) => theme.palette.grey[300],
              },
              '& img': {
                width: { xs: '13px', sm: '17px' },
                height: { xs: '13px', sm: '17px' },
              },
            }}
            disabled={isReadOnly}
            onClick={(e) => {
              e.stopPropagation();
              handleFav(id, isFav);
            }}
          >
            {isFav ? <FavoriteIcon /> : <FavoriteBorderIcon />}
          </IconButton>
        </Box>
        <Link to={`/products/${id}`}>
          <Stack
            direction='row'
            spacing={'8px'}
            alignItems={'flex-start'}
            justifyContent={'space-between'}
          >
            <Typography variant='subtitle1'>{title}</Typography>
            <Typography variant='subtitle1' color={'primary'}>
              ${price}
            </Typography>
          </Stack>
        </Link>
      </Stack>
    </>
  );
};

export default ProductCard;
