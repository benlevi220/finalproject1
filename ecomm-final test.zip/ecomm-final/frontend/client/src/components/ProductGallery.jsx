import { Avatar, Stack } from '@mui/material';
import { grey } from '@mui/material/colors';
import { useState } from 'react';
import { origin } from '../api';

const ProductGallery = ({ images, name }) => {
  const [selectedImage, setSelectedImage] = useState(0);
  const handleImgSelect = (idx) => () => setSelectedImage(idx);

  return (
    <Stack
      alignItems={'flex-start'}
      gap={'15px'}
      sx={{
        flexDirection: { xs: 'column-reverse', sm: 'row' },
        height: { xs: '100%', sm: '400px', md: '550px' },
      }}
    >
      <Stack
        gap={'15px'}
        height='100%'
        sx={{
          overflowY: 'auto',
          overflowX: 'hidden',
          flexDirection: { xs: 'row', sm: 'column' },
        }}
      >
        {images.map((img, idx) => (
          <Avatar
            onClick={handleImgSelect(idx)}
            key={`${origin}${img}`}
            src={`${origin}${img}`}
            alt={`${name}-${idx}`}
            variant='rounded'
            sx={{
              width: 80,
              height: 80,
              border: (theme) => `1px solid ${theme.palette.grey[300]}`,
              cursor: 'pointer',
            }}
          />
        ))}
      </Stack>
      <Stack
        flex={1}
        height='100%'
        border={`1px solid ${grey[300]}`}
        borderRadius={'8px'}
        width='100%'
        sx={{ maxHeight: { xs: '300px', sm: '100%' } }}
      >
        <img
          src={`${origin}${images[selectedImage]}`}
          alt={`${name}-img-${selectedImage}`}
          width={'100%'}
          height={'100%'}
          style={{
            objectFit: 'contain',
          }}
        />
      </Stack>
    </Stack>
  );
};

export default ProductGallery;
