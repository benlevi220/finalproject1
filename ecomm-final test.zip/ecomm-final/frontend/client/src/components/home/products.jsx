import { CircularProgress, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import axiosInstance, { origin } from '../../api';
import {
  addToFavorite,
  removeFromFavorite,
} from '../../store/reducers/favorite/extraReducers';
import ProductCard from '../ProductCard';

const HomeProducts = () => {
  const { favorites } = useSelector((st) => st.favorite);
  const { isLoggedIn } = useSelector((st) => st.auth);

  const dispatch = useDispatch();

  const [featuredProds, setFeaturedProds] = useState([]);
  const [fetching, setFetching] = useState(true);

  const handleProdFav = (id, isFav) => {
    if (!isLoggedIn) toast.error('Login to add or remove product to favorite');
    if (isFav) dispatch(removeFromFavorite(id));
    else dispatch(addToFavorite(id));
  };

  useEffect(() => {
    if (fetching)
      (async () => {
        try {
          const { data } = await axiosInstance.get('/products/top-5');
          setFeaturedProds(data.product);
        } catch (er) {
          console.log('er', er);
        } finally {
          setFetching(false);
        }
      })();
  }, [fetching]);

  return (
    <Stack mt={10} gap={3}>
      <Stack
        direction='row'
        alignItems={'center'}
        justifyContent={'space-between'}
      >
        <Typography variant='h3'>Top Products</Typography>
        <Typography variant='h5' component={Link} to={'/products'}>
          View All{' '}
        </Typography>
      </Stack>
      <Stack direction='row' gap={'20px'} overflowX={'auto'}>
        {fetching ? (
          <Stack
            alignItems={'center'}
            justifyContent={'center'}
            height={'300px'}
          >
            <CircularProgress size={20} />
          </Stack>
        ) : featuredProds.length > 0 ? (
          featuredProds.map((prod) => (
            <ProductCard
              key={prod.id}
              image={`${origin}${prod.images[0]}`}
              title={prod.name}
              price={prod.price}
              id={prod.id}
              isFav={
                favorites?.filter((favProd) => favProd.id === prod.id)?.length >
                0
              }
              handleFav={handleProdFav}
            />
          ))
        ) : (
          <Stack
            alignItems={'center'}
            justifyContent={'center'}
            height={'200px'}
            width='100%'
          >
            <Typography variant='subtitle1' align='center'>
              No Products Found
            </Typography>
          </Stack>
        )}
      </Stack>
    </Stack>
  );
};

export default HomeProducts;
