import { CircularProgress, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import axiosInstance, { origin } from '../../api';
import {
  addToFavorite,
  removeFromFavorite,
} from '../../store/reducers/favorite/extraReducers';
import ProductCard from '../ProductCard';

const HomeFeaturedCats = () => {
  const { favorites } = useSelector((st) => st.favorite);
  const { isLoggedIn } = useSelector((st) => st.auth);

  const dispatch = useDispatch();

  const [featuredProds, setFeaturedProds] = useState([]);
  const [fetching, setFetching] = useState(true);

  const handleProdFav = (id, isFav) => {
    if (!isLoggedIn) toast.error('Login to add or remove product to favorite');
    if (isFav) dispatch(removeFromFavorite(id));
    else dispatch(addToFavorite(id));
  };

  useEffect(() => {
    if (fetching)
      (async () => {
        try {
          const { data } = await axiosInstance.get('/getHomeFeaturedCats');
          setFeaturedProds(data.topCategories);
        } catch (er) {
          console.log('er', er);
        } finally {
          setFetching(false);
        }
      })();
  }, [fetching]);

  return (
    <Stack mt={10} gap={3}>
      {fetching ? (
        <Stack height={'400px'} alignItems={'center'} justifyContent={'center'}>
          <CircularProgress size={20} />
        </Stack>
      ) : (
        featuredProds.length > 0 &&
        featuredProds.map((el) => (
          <Stack key={el.id} gap={1.5}>
            <Stack
              direction='row'
              alignItems={'center'}
              justifyContent={'space-between'}
            >
              <Typography variant='h3'>
                Featured {` ${el.categoryName}`}
              </Typography>
              <Typography
                variant='h5'
                component={Link}
                to={`/products?category=${el.categoryId}`}
              >
                View All{' '}
              </Typography>
            </Stack>
            <Stack direction='row' gap={'20px'} overflowX={'auto'}>
              {el.products.length > 0 ? (
                el.products.map((prod) => (
                  <ProductCard
                    key={prod.id}
                    image={`${origin}${prod.images[0]}`}
                    title={prod.name}
                    price={prod.price}
                    id={prod.id}
                    isFav={
                      favorites?.filter((favProd) => favProd.id === prod.id)
                        ?.length > 0
                    }
                    handleFav={handleProdFav}
                  />
                ))
              ) : (
                <Stack
                  alignItems={'center'}
                  justifyContent={'center'}
                  height={'300px'}
                >
                  <CircularProgress size={20} />
                </Stack>
              )}
            </Stack>
          </Stack>
        ))
      )}
    </Stack>
  );
};

export default HomeFeaturedCats;
