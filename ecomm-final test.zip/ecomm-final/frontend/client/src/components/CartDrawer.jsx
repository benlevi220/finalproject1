import { Add, Close, Remove, ShoppingCart } from '@mui/icons-material';
import {
  Avatar,
  Badge,
  Button,
  IconButton,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import { grey } from '@mui/material/colors';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import * as React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { origin } from '../api';
import { dispatch } from '../store';
import { clearCart, removeItem, updateItem } from '../store/reducers/cart';

export default function CartDrawer() {
  const { items } = useSelector((st) => st.cart);
  const [open, setOpen] = React.useState(false);

  const navigate = useNavigate();

  const toggleDrawer = (newOpen) => () => {
    setOpen(newOpen);
  };

  const updateCartItem = (id, type) => () => {
    let item = items.find((el) => el.id === id);
    if (item.quantity === 1 && type === 'reduceQuan') dispatch(removeItem(id));
    else {
      dispatch(
        updateItem({
          id,
          quantity:
            type === 'reduceQuan' ? item.quantity - 1 : item.quantity + 1,
        })
      );
    }
  };

  const handleCartClear = () => dispatch(clearCart());

  const calcCartTotal = () => {
    let total = 0;
    items.forEach((item) => {
      total += item.quantity * item.price;
    });
    return total;
  };

  const handleProceedToCheckout = () => {
    {
      setOpen(false);
      navigate('/cart/checkout');
    }
  };
  return (
    <div>
      <Tooltip title='Cart'>
        <IconButton onClick={toggleDrawer(true)}>
          <Badge badgeContent={`${items.length}`} color='primary'>
            <ShoppingCart color='action' />
          </Badge>
        </IconButton>
      </Tooltip>
      <Drawer open={open} anchor='right' onClose={toggleDrawer(false)}>
        <Stack sx={{ width: 370, height: '100%' }} role='presentation'>
          <List>
            <ListItem>
              <Stack
                direction='row'
                alignItems={'center'}
                justifyContent={'space-between'}
                width='100%'
              >
                <Typography variant='h4'>Shopping Cart</Typography>
                <IconButton size='small' onClick={toggleDrawer(false)}>
                  <Close />
                </IconButton>
              </Stack>
            </ListItem>
          </List>
          <Divider />
          <List sx={{ mt: 2, flex: 1 }}>
            {items.length > 0 ? (
              items.map((item) => (
                <ListItem key={item.id}>
                  <Stack
                    direction='row'
                    alignItems={'stretch'}
                    gap={'15px'}
                    justifyContent={'space-between'}
                    width='100%'
                  >
                    <Avatar
                      variant='square'
                      src={`${origin}${item.image}`}
                      alt={item.name}
                      sx={{
                        width: 70,
                        height: 70,
                        border: `1px solid ${grey[300]}`,
                        flexShrink: 0,
                        flexgrow: 0,
                        '& img': {
                          objectFit: 'contain',
                        },
                      }}
                    />
                    <Stack flex={1} justifyContent={'space-between'}>
                      <Stack
                        direction='row'
                        alignItems={'flex-start'}
                        gap={'10px'}
                        justifyContent={'space-between'}
                      >
                        <Typography variant='h6'>{item.name}</Typography>
                        <Typography variant='h6'>${item.price}</Typography>
                      </Stack>
                      <Stack direction='row' gap={'5px'} alignItems={'center'}>
                        <IconButton
                          size='small'
                          onClick={updateCartItem(item.id, 'reduceQuan')}
                        >
                          <Remove />
                        </IconButton>
                        {item.quantity}
                        <IconButton
                          size='small'
                          onClick={updateCartItem(item.id, 'incQuan')}
                        >
                          <Add />
                        </IconButton>
                      </Stack>
                    </Stack>
                  </Stack>
                </ListItem>
              ))
            ) : (
              <Stack
                height={'300px'}
                alignItems={'center'}
                justifyContent={'center'}
              >
                <Typography variant='h6'>No Items in a Cart</Typography>
              </Stack>
            )}
          </List>
          <Stack p={2} spacing={1} width='100%' flexShrink={0}>
            <Stack py={3} spacing={1.5}>
              <Stack
                direction='row'
                justifyContent={'space-between'}
                alignItems={'center'}
                gap={'10px'}
              >
                <Typography variant='subtitle1'>Sub-Total</Typography>
                <Typography variant='subtitle1'>${calcCartTotal()}</Typography>
              </Stack>
              <Stack
                direction='row'
                justifyContent={'space-between'}
                alignItems={'center'}
                gap={'10px'}
              >
                <Typography variant='subtitle1'>Shipping Fee</Typography>
                <Typography variant='subtitle1'>$10</Typography>
              </Stack>
              <Divider />
              <Stack
                direction='row'
                justifyContent={'space-between'}
                alignItems={'center'}
                gap={'10px'}
              >
                <Typography variant='subtitle1'>Total</Typography>
                <Typography variant='subtitle1'>
                  ${calcCartTotal() + 10}
                </Typography>
              </Stack>
            </Stack>
            <Button
              variant='outlined'
              onClick={handleCartClear}
              disabled={items.length === 0}
            >
              Clear Cart
            </Button>
            <Button
              variant='contained'
              // LinkComponent={Link}
              // to='/cart/checkout'
              disabled={items.length === 0}
              onClick={handleProceedToCheckout}
            >
              Proceed to Checkout
            </Button>
          </Stack>
        </Stack>
      </Drawer>
    </div>
  );
}
