import { Box, Button, Container, Stack, Typography } from '@mui/material';
import React, { useEffect } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import Footer from '../components/common/Footer';
import Navbar from '../components/common/Navbar';
import ScrollToTop from '../components/common/ScrollToTop';

const LayoutMain = () => {
  const location = useLocation();
  useEffect(() => {
    document.getElementById('root').scroll({
      top: 0,
      behavior: 'smooth',
    });
  }, [location.pathname]);

  return (
    <React.Fragment>
      <Navbar />
      <Box flex={1} mt={location.pathname !== '/' ? 6 : 0} mb={6}>
        <Outlet />
        {!location.pathname.includes('cart') && (
          <Container maxWidth='lg'>
            <Stack
              mt={10}
              sx={{ flexDirection: { xs: 'column', md: 'row' } }}
              justifyContent={'space-between'}
              alignItems={'center'}
            >
              <Stack gap={2}>
                <Typography variant='h4'>
                  Unalock Exclusive Deals and Offers
                </Typography>
              </Stack>
              <Button
                variant='contained'
                size='large'
                LinkComponent={Link}
                href={'/auth/signup'}
              >
                SignUp
              </Button>
            </Stack>
          </Container>
        )}
      </Box>
      <ScrollToTop />
      <Footer />
    </React.Fragment>
  );
};

export default LayoutMain;
