import HomeIcon from '@mui/icons-material/Home';
import { Container, Stack, Typography } from '@mui/material';
import { Link, Outlet } from 'react-router-dom';

const AuthLayout = () => {
  return (
    <Container
      maxWidth='lg'
      sx={{ height: '100%', overflowY: 'auto', overflowX: 'hidden' }}
    >
      <Stack
        mx={'auto'}
        maxWidth='400px'
        width='100%'
        height='100%'
        py={3}
        alignItems={'center'}
        justifyContent={'center'}
      >
        <Typography
          variant='h4'
          noWrap
          sx={{
            fontWeight: 700,
            letterSpacing: '.2rem',
            mb: 8,
          }}
        >
          SHOPNOW
        </Typography>
        <Outlet />
        <Link to='/'>
          <Stack mt={2} direction={'row'} alignItems={'center'} gap={'10px'}>
            <HomeIcon fontSize='medium' />
            <Typography variant='subtitle1'>Back to Home</Typography>
          </Stack>
        </Link>
      </Stack>
    </Container>
  );
};

export default AuthLayout;
