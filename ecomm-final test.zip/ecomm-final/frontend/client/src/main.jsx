import { createRoot } from 'react-dom/client';
import { Provider as StoreProvider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import App from './App.jsx';
import { store } from './store';
import ThemeProvider from './theme/index.jsx';

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <StoreProvider store={store}>
      <ThemeProvider>
        <App />
      </ThemeProvider>
      <ToastContainer
        position='top-right'
        autoClose={2000}
        hideProgressBar
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable
        pauseOnHover={false}
        theme='light'
      />
    </StoreProvider>
  </BrowserRouter>
);
