// Utility function to load cart from local storage
export const loadCartFromLocalStorage = () => {
  try {
    const serializedCart = localStorage.getItem('cart');
    return serializedCart ? JSON.parse(serializedCart) : undefined;
  } catch (err) {
    console.error('Could not load cart', err);
    return undefined;
  }
};

// Utility function to save cart to local storage
export const saveCartToLocalStorage = (cart) => {
  try {
    const serializedCart = JSON.stringify(cart);
    localStorage.setItem('cart', serializedCart);
  } catch (err) {
    console.error('Could not save cart', err);
  }
};
