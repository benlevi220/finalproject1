require('dotenv').config();
require('express-async-errors');

const express = require('express');
const app = express();

// Rest of the packages
const morgan = require('morgan'); //HTTP request logger middleware
const cookieParser = require('cookie-parser');
const fileUpload = require('express-fileupload');

// Require Database
const connectDB = require('./db/connect');
// Require Routers
const homeRouter = require('./routes/homeRoutes');
const authRouter = require('./routes/authRoutes');
const userRouter = require('./routes/userRoutes');
const productRouter = require('./routes/productRoutes');
const categoryRouter = require('./routes/categoryRoutes');
const reviewRouter = require('./routes/reviewRoutes');
const orderRouter = require('./routes/orderRoutes');
const otpRoutes = require('./routes/otpRoutes');

// Require Middleware
const notFoundMiddleware = require('./middleware/not-found');
const errorHandlerMiddleware = require('./middleware/error-handler');
const cors = require('cors');
// Stripe Payment
const { default: Stripe } = require('stripe');
const { StatusCodes } = require('http-status-codes');
const stripe = Stripe(process.env.STRIPE_SECRET);

// Invoke Extra packages
app.use(morgan('dev'));
app.use(express.json());
app.use(cookieParser(process.env.JWT_SECRET));
app.use(express.static('./public'));
app.use(fileUpload());

// Configure CORS
app.use(cors()); // Use default settings to allow all origins

// Home get
app.get('/', (req, res) => {
  res.send('<h1> E-Commerce API</h1>');
});
// Route to create payment intent
app.get('/config', (req, res) => {
  res.send({
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
  });
});

app.post('/create-payment-intents', async (req, res) => {
  const { amount, currency } = req.body;
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      currency: currency,
      amount: amount,
      automatic_payment_methods: { enabled: true },
    });

    // Send publishable key and PaymentIntent details to client
    res.status(StatusCodes.OK).send({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (e) {
    return res.status(StatusCodes.BAD_REQUEST).send({
      error: {
        message: e.message,
      },
    });
  }
});

// Testing route
app.get('/api/v1/', (req, res) => {
  // console.log(req.cookies)
  // console.log(req.signedCookies)
  res.send('E-commerce API');
});

// Invoke Routers

app.use('/api/v1/getHomeFeaturedCats', homeRouter);
app.use('/api/v1/auth', authRouter);
app.use('/api/v1/users', userRouter);
app.use('/api/v1/products', productRouter);
app.use('/api/v1/categories', categoryRouter);
app.use('/api/v1/reviews', reviewRouter);
app.use('/api/v1/orders', orderRouter);
app.use('/api/v1/otp', otpRoutes);

// Invoke Middleware
app.use(notFoundMiddleware);
app.use(errorHandlerMiddleware);

const port = process.env.PORT || 5000;
const start = async () => {
  try {
    // Connect database
    await connectDB(process.env.MONGO_URL);
    app.listen(port, () =>
      console.log(`🚀 Server is listening on port ${port}...`)
    );
  } catch (error) {
    console.log(error);
  }
};

start();
