const { CustomAPIError } = require('../errors');
const OTP = require('../models/otpModel');
const otpGenerator = require('otp-generator');

async function generateOTP(email) {
  try {
    let otp;
    let result;

    do {
      otp = otpGenerator.generate(4, {
        upperCaseAlphabets: false,
        lowerCaseAlphabets: false,
        specialChars: false,
      });
      result = await OTP.findOne({ otp });
    } while (result);

    const existingOTP = await OTP.findOne({ email });

    if (existingOTP) {
      existingOTP.otp = otp;
      await existingOTP.save();
    } else {
      const otpPayload = { email, otp };
      await OTP.create(otpPayload);
    }
  } catch (er) {
    throw new CustomAPIError('Something went wrong, try again');
  }
}

module.exports = generateOTP;
