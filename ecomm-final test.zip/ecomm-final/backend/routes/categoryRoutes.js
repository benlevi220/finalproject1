const express = require('express');
const router = express.Router();

const {
  createCategory,
  getAllCategories,
  getSingleCategory,
  updateCategory,
  deleteCategory,
  uploadImage,
} = require('../controllers/categoryController');
const {
  authenticateUser,
  authorizePermissions,
} = require('../middleware/authentication');

const { getSingleProductReviews } = require('../controllers/reviewController');

router
  .route('/')
  .post([authenticateUser, authorizePermissions('admin')], createCategory)
  .get(getAllCategories);

// router
//   .route('/uploadImage')
//   .post([authenticateUser, authorizePermissions('admin')], uploadImage);

router
  .route('/:id')
  .get(getSingleCategory)
  .patch([authenticateUser, authorizePermissions('admin')], updateCategory)
  .delete([authenticateUser, authorizePermissions('admin')], deleteCategory);

module.exports = router;
