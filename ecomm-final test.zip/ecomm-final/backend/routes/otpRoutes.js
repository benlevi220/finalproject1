const express = require('express');
const { verifyOTP } = require('../controllers/otpController');
// const { verifyOTP } = require('../controller/otpController');
const router = express.Router();

router.post('/verify-otp', verifyOTP);

module.exports = router;
