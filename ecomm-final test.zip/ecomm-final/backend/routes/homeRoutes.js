const express = require('express');
const {
  getTopCategories,
  getProductsForCategories,
} = require('../controllers/homeController');
const { StatusCodes } = require('http-status-codes');
const router = express.Router();

router.route('/').get(async (req, res) => {
  // Get top 3 categories
  const topCategories = await getTopCategories();

  // Extract category IDs
  const categoryIds = topCategories.map((cat) => cat.categoryId);

  // Get all products for these categories
  const products = await getProductsForCategories(categoryIds);

  // Prepare the data
  const topCategoriesWithProducts = topCategories.map((category) => ({
    ...category,
    products: products.filter(
      (product) =>
        product.category.toString() === category.categoryId.toString()
    ),
  }));
  res.status(StatusCodes.OK).json({ topCategories: topCategoriesWithProducts });
});

module.exports = router;
