const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      minLength: [3, 'Category name should ne atleast 3 characters long'],
    },
    description: {
      type: String,
      required: false,
      default: '',
    },
    image: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
    },
    toObject: {
      virtuals: true,
    },
  }
);

const Category = mongoose.model('Category', categorySchema);

module.exports = Category;
