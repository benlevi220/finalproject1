const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide product name'],
      trim: true,
      maxlength: [100, 'Name cannot be more than 100 characters'],
    },

    price: {
      type: Number,
      required: [true, 'Please provide price value'],
      default: 0,
    },
    description: {
      type: String,
      required: [true, 'Please provide description'],
      maxlength: [1000, 'Description can not be more than 1000 characters'],
    },
    images: {
      type: [String],
      required: true,
      // default: '/uploads/example.jpeg',
    },
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },

    inventory: {
      type: Number,
      required: true,
      default: 15,
    },
  },
  { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } }
);

// ProductSchema.virtual('category', {
//   ref: 'Category',
//   localField: '_id',
//   foreignField: 'product',
// });

module.exports = new mongoose.model('Product', ProductSchema);
