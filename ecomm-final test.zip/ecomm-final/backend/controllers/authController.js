const User = require('../models/userModel');
const { StatusCodes } = require('http-status-codes');
const CustomError = require('../errors');
const {
  createTokenUser,
  attachCookiesToResponse,
  createJWT,
} = require('../utils');
const generateOTP = require('../utils/generateOTP');

// Register User
const register = async (req, res) => {
  const { name, email, password, role } = req.body;
  const emailAlreadyExists = await User.findOne({ email });
  if (emailAlreadyExists) {
    throw new CustomError.BadRequestError('Email already exists');
  }
  // Add first registered user as admin
  const isFirstAccount = (await User.countDocuments({})) === 0;
  const userRole = role || 'user';
  const user = await User.create({
    name,
    email,
    password,
    role: userRole,
    isVerified: role === 'admin' ? true : false,
  });
  await generateOTP(email);
  // Create token user
  // const tokenUser = createTokenUser(user);
  // attachCookiesToResponse({ res, user: tokenUser });
  res
    .status(StatusCodes.CREATED)
    .json({ message: 'User registered & OtP sent to email' });
};

// Login User
const login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    throw new CustomError.BadRequestError('Please provide email and password');
  }
  const user = await User.findOne({ email }).populate('shippingInfo');
  if (!user) {
    throw new CustomError.UnauthorizedError('No user found');
  }
  const isPasswordCorrect = await user.comparePassword(password);
  if (!isPasswordCorrect) {
    throw new CustomError.UnauthenticatedError('Invalid Credentials');
  }
  if (!user.isVerified) {
    await generateOTP(email);
    throw new CustomError.UnauthorizedError(
      'Please verify your email to login'
    );
  }

  const tokenUser = createTokenUser(user);
  const token = createJWT({ payload: tokenUser });

  if (!user) throw new CustomError.UnauthorizedError('No user found');
  const defaultShippingInfo = user.shippingInfo.find((info) => info.isDefault);

  res.status(StatusCodes.OK).json({
    user: {
      ...tokenUser,
      email: user.email,
      shippingInfo: defaultShippingInfo ?? null,
    },
    token,
  });
};

// Logout User
const logout = async (req, res) => {
  res.cookie('token', null, {
    httpOnly: true,
    expires: new Date(Date.now()),
  });
  //   res.send() ==== this is for production
  res.status(StatusCodes.OK).json({ msg: 'user logged out!' }); // this is for testing during development
};

// Get User
const getUser = async (req, res) => {
  const { userId } = req.user;
  if (!userId) throw new CustomError.UnauthorizedError('No user found');
  const user = await User.findOne({ id: userId }).populate('shippingInfo');

  if (!user) throw new CustomError.UnauthorizedError('No user found');
  const defaultShippingInfo = user.shippingInfo.find((info) => info.isDefault);

  res.status(StatusCodes.OK).json({
    user: {
      id: user.id,
      role: user.role,
      email: user.email,
      name: user.name,
      shippingInfo: defaultShippingInfo ?? null,
    },
  });
};

module.exports = {
  register,
  login,
  logout,
  getUser,
};
