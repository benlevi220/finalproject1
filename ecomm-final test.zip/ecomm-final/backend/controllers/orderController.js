const { StatusCodes } = require('http-status-codes');
const Order = require('../models/orderModel');

// ** ===================  GET ALL ORDERS  ===================
const getAllOrders = async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const skip = (page - 1) * limit;

  const orders = await Order.find()
    .skip(skip)
    .limit(limit)
    .populate('user')
    .populate({
      path: 'orderItems',
      populate: {
        path: 'product',
      },
    });
  const totalOrders = await Order.countDocuments();

  res.status(StatusCodes.OK).json({ total_orders: totalOrders, orders });
};

// ** ===================  GET SINGLE ORDERS  ===================
const getSingleOrder = async (req, res) => {
  const { id } = req.params;
  const order = await Order.findOne({ _id: id })
    .populate('user')
    .populate({
      path: 'orderItems',
      populate: {
        path: 'product',
      },
    });
  res.status(StatusCodes.OK).json({ order });
};

// ** ===================  GET CURRENT USER ORDERS ORDERS  ===================
const getCurrentUserOrder = async (req, res) => {
  res.send('Get current user order');
};

// ** ===================  CREATE ORDER  ===================
const createOrder = async (req, res) => {
  const { orderItems, paymentId, total } = req.body;
  const { userId } = req.user;
  const order = await Order.create({
    user: userId,
    orderItems,
    total,
    paymentIntentID: paymentId,
  });
  res.status(StatusCodes.CREATED).json({ order });
};

// ** ===================  UPDATE ORDER  ===================
const updateOrder = async (req, res) => {
  res.send('Update order');
};

module.exports = {
  getAllOrders,
  getSingleOrder,
  getCurrentUserOrder,
  createOrder,
  updateOrder,
};
