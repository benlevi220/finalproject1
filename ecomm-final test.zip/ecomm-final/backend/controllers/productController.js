const Product = require('../models/productModel');
const CustomError = require('../errors');
const { StatusCodes } = require('http-status-codes');
const path = require('path');

// ** ===================  CREATE PRODUCT  ===================
const createProduct = async (req, res) => {
  req.body.user = req.user.userId;
  const { images: img, ...bodyData } = req.body;
  const images = await uploadImages(req);
  const product = await Product.create({ ...bodyData, images });
  res.status(StatusCodes.CREATED).json({ product });
};

// ** ===================  GET ALL PRODUCTS  ===================
const getAllProducts = async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const skip = (page - 1) * limit;

  // Extract category from query parameters
  const category = req.query.category;

  // Build the query object
  const query = {};
  if (category) {
    query.category = category; // Assuming 'category' is the field name in the Product schema
  }

  // Query the products with pagination
  const products = await Product.find(query).skip(skip).limit(limit);
  const totalProducts = await Product.countDocuments();

  res.status(StatusCodes.OK).json({ total_products: totalProducts, products });
};

// ** ===================  GET ALL PRODUCTS  ===================
const getFeaturedProducts = async (req, res) => {
  const product = await Product.find().limit(4);
  res.status(StatusCodes.OK).json({ product });
};

// ** ===================  GET SINGLE PRODUCT  ===================
const getSingleProduct = async (req, res) => {
  const { id: productId } = req.params;
  const product = await Product.findOne({ _id: productId }).populate(
    'category'
  );
  // const product = await Product.findOne({ _id: productId }).populate('reviews');
  if (!product) {
    throw new CustomError.BadRequestError(
      `No product with the id ${productId}`
    );
  }
  res.status(StatusCodes.OK).json({ product });
};

// ** ===================  UPDATE PRODUCT  ===================
const updateProduct = async (req, res) => {
  const { id: productId } = req.params;
  const { images: imgList, ...bodyData } = req.body;
  let newImages = '';
  if (req.files) newImages = await uploadImages(req);
  const updateData = bodyData;
  if (newImages)
    updateData.images =
      imgList?.length > 0 ? newImages.concat(imgList) : newImages;
  console.log('updateData', updateData);
  const product = await Product.findOneAndUpdate(
    { _id: productId },
    updateData,
    {
      new: true,
      runValidators: true,
    }
  );
  if (!product)
    throw new CustomError.BadRequestError(
      `No product with the id ${productId}`
    );
  res.status(StatusCodes.CREATED).json({ product });
};

// ** ===================  DELETE PRODUCT  ===================
const deleteProduct = async (req, res) => {
  const { id: productId } = req.params;
  const product = await Product.findOneAndDelete({ _id: productId });
  if (!product) {
    throw new CustomError.BadRequestError(
      `No product with the id ${productId}`
    );
  }
  await product.remove(); // this will trigger the pre remove hook
  res.status(StatusCodes.OK).json({ msg: 'Success! Product removed' });
};

// ** ===================  UPLOAD IMAGE PRODUCT  ===================
const uploadImages = async (req, res) => {
  // Check if files are present
  console.log('req.files', req.files);
  if (!req.files || !req.files.attachments) {
    throw new CustomError.BadRequestError('No Files Uploaded');
  }

  const files = req.files.attachments;

  // Ensure `files` is an array (it might be a single file object if only one file is uploaded)
  const fileArray = Array.isArray(files) ? files : [files];

  const maxSize = 1024 * 1024; // 1MB size limit
  const uploadedPaths = [];

  // Iterate through each file and handle the upload
  for (const file of fileArray) {
    if (!file.mimetype.startsWith('image')) {
      throw new CustomError.BadRequestError('Please Upload Images Only');
    }
    if (file.size > maxSize) {
      throw new CustomError.BadRequestError(
        'Please upload images smaller than 1MB'
      );
    }

    const imagePath = path.join(
      __dirname,
      '../public/uploads/' + `${file.name}`
    );
    await file.mv(imagePath);
    uploadedPaths.push(`/uploads/${file.name}`);
  }

  // Return array of paths
  return uploadedPaths;
  // res.status(StatusCodes.OK).json({ images: uploadedPaths });
};

module.exports = {
  createProduct,
  getAllProducts,
  getSingleProduct,
  updateProduct,
  deleteProduct,
  getFeaturedProducts,
};
