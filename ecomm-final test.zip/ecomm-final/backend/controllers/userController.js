const User = require('../models/userModel');
const { StatusCodes } = require('http-status-codes');
const CustomError = require('../errors');
const {
  createTokenUser,
  attachCookiesToResponse,
  checkPermissions,
} = require('../utils');
const Product = require('../models/productModel');

//** ======================== Get all users ========================
const getAllUsers = async (req, res) => {
  // console.log(req.user) //check if I am getting req.user from authentication.js or not
  const user = await User.find({ role: 'user' }).select('-password');
  console.log('user', user);
  res.status(StatusCodes.OK).json({ total_users: user.length, user });
};

//** ======================== Get single user ========================
const getSingleUser = async (req, res) => {
  const { id: userId } = req.params;
  const user = await User.findOne({ _id: userId }).select('-password');
  if (!user) {
    throw CustomError.NotFoundError('User does not exist');
  }
  checkPermissions(req.user, user._id);
  res.status(StatusCodes.OK).json({ user });
};

//** ======================== Show current user ========================
const showCurrentUser = async (req, res) => {
  res.status(StatusCodes.OK).json({ user: req.user });
};

//** ======================== Update user ========================
const updateUser = async (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) {
    throw new CustomError.BadRequestError('Please provide value');
  }
  const user = await User.findOne({ _id: req.user.userId });

  user.name = name;
  user.email = email;
  await user.save();
  const tokenUser = createTokenUser(user);
  attachCookiesToResponse({ res, user: tokenUser });
  res.status(StatusCodes.OK).json({ user: tokenUser });
};

//** ======================== Update user password ========================
const updateUserPassword = async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) {
    throw new CustomError.BadRequestError('Please provide both values');
  }
  const user = await User.findOne({ _id: req.user.userId });
  const isPasswordCorrect = await user.comparePassword(oldPassword);
  if (!isPasswordCorrect) {
    throw new CustomError.UnauthenticatedError('Wrong password provided');
  }
  user.password = newPassword;
  await user.save();
  res.status(StatusCodes.OK).json({ msg: 'Success! Password Updated' });
};

//** ======================== Get User Favorites ========================
const getFavorites = async (req, res) => {
  const user = await User.findOne({ id: req.user.userId }).populate(
    'favorites'
  );
  if (!user) throw new CustomError.NotFoundError('User does not exist');

  res.status(StatusCodes.OK).json({ favorites: user.favorites });
};

//** ======================== Add to Favorites ========================
const addToFavorites = async (req, res) => {
  const user = await User.findOne({ id: req.user.userId });
  const product = await Product.findById(req.body.productId);
  if (!user || !product) {
    throw new CustomError.NotFoundError('User or product does not exist');
  }

  if (!user.favorites.includes(product._id)) {
    user.favorites.push(product._id);
    await user.save();
  } else
    return res
      .status(StatusCodes.BAD_REQUEST)
      .json({ msg: 'Product already exists in favorite' });

  const updatedUser = await User.findOne({
    username: req.params.username,
  }).populate('favorites');

  return res
    .status(StatusCodes.CREATED)
    .json({ favorites: updatedUser.favorites });
};

//** ======================== Remove From Favorites ========================
const removeFromFavorites = async (req, res) => {
  const user = await User.findOne({ username: req.user.userId });
  if (!user) throw new CustomError.NotFoundError('User does not exist');

  const productIndex = user.favorites.indexOf(req.params.productId);
  if (productIndex !== -1) {
    user.favorites.splice(productIndex, 1);
    await user.save();
    return res.status(StatusCodes.OK).json({ favorites: user.favorites });
  } else throw new CustomError.NotFoundError('Product not found in favorites');
};

//** ======================== Save Shipping Address ========================
const saveUserShippingAddress = async (req, res) => {
  const user = await User.findById(req.user.userId);
  if (!user) throw new CustomError.NotFoundError('User does not exist');

  const newAddress = req.body;
  newAddress.isDefault = true;

  user.shippingInfo.forEach((address) => {
    address.isDefault = false;
  });

  user.shippingInfo.push(newAddress);
  await user.save();

  const defaultAddress = user.shippingInfo.find((address) => address.isDefault);
  return res.status(StatusCodes.OK).json({ shippingAddress: defaultAddress });
};

module.exports = {
  getAllUsers,
  getSingleUser,
  showCurrentUser,
  updateUser,
  updateUserPassword,
  getFavorites,
  addToFavorites,
  removeFromFavorites,
  saveUserShippingAddress,
};
