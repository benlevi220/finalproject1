const Product = require('../models/productModel');

const getProductsForCategories = async (categoryIds) => {
  // Find products for given category IDs
  const products = await Product.find({ category: { $in: categoryIds } });
  return products;
};

const getTopCategories = async () => {
  // Aggregate to count the number of products in each category
  const categories = await Product.aggregate([
    { $group: { _id: '$category', count: { $sum: 1 } } },
    { $sort: { count: -1 } },
    { $limit: 3 },
    {
      $lookup: {
        from: 'categories', // Name of the categories collection
        localField: '_id',
        foreignField: '_id',
        as: 'categoryDetails',
      },
    },
    { $unwind: '$categoryDetails' },
    {
      $project: {
        _id: 0,
        categoryId: '$_id',
        count: 1,
        categoryName: '$categoryDetails.name',
        categoryImage: '$categoryDetails.image',
      },
    },
  ]);

  return categories;
};

module.exports = {
  getProductsForCategories,
  getTopCategories,
};
