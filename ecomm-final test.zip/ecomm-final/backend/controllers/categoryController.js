const Category = require('../models/categoryModel');
const CustomError = require('../errors');
const { StatusCodes } = require('http-status-codes');
const path = require('path');

// ** ===================  CREATE CATEGORY  ===================
const createCategory = async (req, res) => {
  req.body.user = req.user.userId;
  const { name, description } = req.body;
  const image = await uploadImage(req);
  const category = await Category.create({ name, description, image });
  res.status(StatusCodes.CREATED).json({ category });
};

// ** ===================  GET ALL Categories  ===================
const getAllCategories = async (req, res) => {
  const category = await Category.find({});
  res
    .status(StatusCodes.OK)
    .json({ total_categories: category.length, category });
};

// ** ===================  GET SINGLE CATEGORY  ===================
const getSingleCategory = async (req, res) => {
  const { id: categoryId } = req.params;
  const category = await Category.findOne({ _id: categoryId });
  if (!category) {
    throw new CustomError.BadRequestError(
      `No category with the id ${categoryId}`
    );
  }
  res.status(StatusCodes.OK).json({ category });
};

// ** ===================  UPDATE CATEGORY  ===================
const updateCategory = async (req, res) => {
  const { id: categoryId } = req.params;
  const { name, description } = req.body;
  let image = '';
  if (req.files) image = await uploadImage(req);

  const updateData = { name, description };
  if (image) updateData.image = image; // Explicitly add the image to the update object

  const category = await Category.findOneAndUpdate(
    { _id: categoryId },
    updateData,
    {
      new: true,
      runValidators: true,
    }
  );
  if (!category) {
    throw new CustomError.BadRequestError(
      `No category with the id ${categoryId}`
    );
  }
  res.status(StatusCodes.OK).json({ category });
};

// ** ===================  DELETE CATEGORY  ===================
const deleteCategory = async (req, res) => {
  const { id: categoryId } = req.params;
  const category = await Category.findOneAndDelete({ _id: categoryId });
  if (!category) {
    throw new CustomError.BadRequestError(
      `No category with the id ${categoryId}`
    );
  }
  await category.remove(); // this will trigger the pre remove hook
  res.status(StatusCodes.OK).json({ msg: 'Success! Category removed' });
};

// ** ===================  UPLOAD IMAGE CATEGORY  ===================
const uploadImage = async (req) => {
  //console.log(req.files)
  if (!req.files) {
    throw new CustomError.BadRequestError('No File Uploaded');
  }
  const productImage = req.files.image;
  if (!productImage.mimetype.startsWith('image')) {
    throw new CustomError.BadRequestError('Please Upload Image');
  }
  const maxSize = 1024 * 1024;
  if (productImage.size > maxSize) {
    throw new CustomError.BadRequestError('Please upload image smaller 1MB');
  }
  const imagePath = path.join(
    __dirname,
    '../public/uploads/' + `${productImage.name}`
  );
  await productImage.mv(imagePath);
  return `/uploads/${productImage.name}`;
  // res.status(StatusCodes.OK).json({ image: `/uploads/${productImage.name}` });
};

module.exports = {
  createCategory,
  getAllCategories,
  getSingleCategory,
  updateCategory,
  deleteCategory,
  uploadImage,
};
