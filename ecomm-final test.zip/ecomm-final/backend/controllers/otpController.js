const OTPModel = require('../models/otpModel');
const UserModel = require('../models/userModel');
const CustomError = require('../errors');

const { StatusCodes } = require('http-status-codes');

exports.verifyOTP = async (req, res) => {
  try {
    const { otp } = req.body;
    const otpValue = await OTPModel.find({
      otp,
    });
    if (!otpValue || otpValue.length === 0) {
      throw new CustomError.NotFoundError('OTP does not exists or expired');
    }
    if (otpValue[0].expiredAt > Date.now()) {
      throw new CustomError.NotFoundError('OTP does not exists or expired');
    }

    const userUpd = await UserModel.findOneAndUpdate(
      { email: otpValue[0].email },
      { isVerified: true },
      {
        new: true,
      }
    );
    await OTPModel.findOneAndDelete({ email: otpValue[0].email, otp });
    return res.status(200).json({
      message: 'OTP verified successfully, you can now login with this email',
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};
